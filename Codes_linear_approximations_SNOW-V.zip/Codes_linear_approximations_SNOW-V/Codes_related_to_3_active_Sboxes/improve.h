#pragma once
#include<stdio.h>
#include<inttypes.h>
#include<math.h>
#include<vector>
#include<array>
#include<algorithm>
#include<iterator>
#include<math.h>
#include<omp.h>
#include<immintrin.h>
#include<string>
#include<memory>
#include<time.h>
#include"lat.h"
#include<sstream>
#include<fstream>

#define SAMPLE_CAP ((uint32_t)(1<<16))
#define CANS 27
#define ExtractLowByte(y,i) (((y)>>((i)<<3))&0xFF)
#define LeftRote(y,r) (((y)<<((r)<<3))|((y)>>(32-((r)<<3))))
#define Position(u,wx,wy) (((int32_t)(u)<<18)^((int32_t)(wx)<<10)^((int32_t)(wy)<<2))

#define STATIC_CACHE_ALIGN_AVX2 __declspec(align(32))
//#define STATIC_CACHE_ALIGN_AVX2 __attribute__((aligned(32)))
//store all the connection matrices column by column
//These matrices are used for algorithm 2 X + sigma(Y+Z)

//double p1[CANS] = {
//0.00157924653858628,0.00155568472464062,0.00282054568138764,0.00487620148712946,
//0.00803835740403950,0.01263543911413890,0.01893873206820459,0.02706756269230710,
//0.03688801049082491,0.04793572113821799,0.05939793564956400,0.07018132702291199,
//0.07906968409811199,0.08494477730423000,0.08701650567134106,0.08499725195550401,
//0.07916740493948093,0.07031147112553404,0.05954484438320296,0.04808396622082700,
//0.03702494799537004,0.02718482762571894,0.01903253081685607,0.01270586370579996,
//0.00808815338299096,0.00490943964196000,0.00284152603097010,0.00156822477192597,
//0.00159381631822297,
//};
__m256d A[16][4] = {
	//A[0]
	0.500000,0.250000,0.250000,0.000000,
	0.125000,0.625000,0.125000,0.125000,
	0.125000,0.125000,0.625000,0.125000,
	0.000000,0.250000,0.250000,0.500000,
	//A[1]
	0.250000,0.000000,-0.250000,0.000000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[2]
	0.250000,0.000000,-0.250000,0.000000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[3]
	0.000000,-0.250000,0.250000,0.000000,
	0.125000,-0.375000,0.125000,0.125000,
	0.125000,0.125000,-0.375000,0.125000,
	0.000000,0.250000,-0.250000,0.000000,
	//A[4]
	0.250000,-0.250000,0.000000,0.000000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.250000,-0.250000,
	//A[5]
	0.000000,0.000000,0.000000,0.000000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[6]
	0.000000,0.000000,0.000000,0.000000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[7]
	-0.250000,0.250000,0.000000,0.000000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.000000,0.000000,-0.250000,0.250000,
	//A[8]
	-0.250000,0.250000,0.000000,0.000000,
	-0.125000,0.125000,-0.125000,0.125000,
	-0.125000,0.125000,-0.125000,0.125000,
	0.000000,0.000000,-0.250000,0.250000,
	//A[9]
	0.000000,0.000000,0.000000,0.000000,
	-0.125000,0.125000,0.125000,-0.125000,
	-0.125000,0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[10]
	0.000000,0.000000,0.000000,0.000000,
	-0.125000,0.125000,0.125000,-0.125000,
	-0.125000,0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[11]
	0.250000,-0.250000,0.000000,0.000000,
	-0.125000,0.125000,-0.125000,0.125000,
	-0.125000,0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.250000,-0.250000,
	//A[12]
	0.000000,-0.250000,0.250000,0.000000,
	-0.125000,0.375000,-0.125000,-0.125000,
	-0.125000,-0.125000,0.375000,-0.125000,
	0.000000,0.250000,-0.250000,0.000000,
	//A[13]
	0.250000,0.000000,-0.250000,0.000000,
	-0.125000,-0.125000,0.125000,0.125000,
	-0.125000,-0.125000,0.125000,0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[14]
	0.250000,0.000000,-0.250000,0.000000,
	-0.125000,-0.125000,0.125000,0.125000,
	-0.125000,-0.125000,0.125000,0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[15]
	0.500000,0.250000,0.250000,0.000000,
	-0.125000,-0.625000,-0.125000,-0.125000,
	-0.125000,-0.125000,-0.625000,-0.125000,
	0.000000,0.250000,0.250000,0.500000,
};
uint32_t NDBE[256] = {
0x00000000,0x2161a1e0,0x62a2e321,0x43c342c1,0xc445c643,0xe52467a3,0xa6e72562,0x87868482,
0xa9eb2d67,0x888a8c87,0xcb49ce46,0xea286fa6,0x6daeeb24,0x4ccf4ac4,0x0f0c0805,0x2e6da9e5,
0x72b6fa2e,0x53d75bce,0x1014190f,0x3175b8ef,0xb6f33c6d,0x97929d8d,0xd451df4c,0xf5307eac,
0xdb5dd749,0xfa3c76a9,0xb9ff3468,0x989e9588,0x1f18110a,0x3e79b0ea,0x7dbaf22b,0x5cdb53cb,
0xe46cf45c,0xc50d55bc,0x86ce177d,0xa7afb69d,0x2029321f,0x014893ff,0x428bd13e,0x63ea70de,
0x4d87d93b,0x6ce678db,0x2f253a1a,0x0e449bfa,0x89c21f78,0xa8a3be98,0xeb60fc59,0xca015db9,
0x96da0e72,0xb7bbaf92,0xf478ed53,0xd5194cb3,0x529fc831,0x73fe69d1,0x303d2b10,0x115c8af0,
0x3f312315,0x1e5082f5,0x5d93c034,0x7cf261d4,0xfb74e556,0xda1544b6,0x99d60677,0xb8b7a797,
0xc8d8e8b8,0xe9b94958,0xaa7a0b99,0x8b1baa79,0x0c9d2efb,0x2dfc8f1b,0x6e3fcdda,0x4f5e6c3a,
0x6133c5df,0x4052643f,0x039126fe,0x22f0871e,0xa576039c,0x8417a27c,0xc7d4e0bd,0xe6b5415d,
0xba6e1296,0x9b0fb376,0xd8ccf1b7,0xf9ad5057,0x7e2bd4d5,0x5f4a7535,0x1c8937f4,0x3de89614,
0x13853ff1,0x32e49e11,0x7127dcd0,0x50467d30,0xd7c0f9b2,0xf6a15852,0xb5621a93,0x9403bb73,
0x2cb41ce4,0x0dd5bd04,0x4e16ffc5,0x6f775e25,0xe8f1daa7,0xc9907b47,0x8a533986,0xab329866,
0x855f3183,0xa43e9063,0xe7fdd2a2,0xc69c7342,0x411af7c0,0x607b5620,0x23b814e1,0x02d9b501,
0x5e02e6ca,0x7f63472a,0x3ca005eb,0x1dc1a40b,0x9a472089,0xbb268169,0xf8e5c3a8,0xd9846248,
0xf7e9cbad,0xd6886a4d,0x954b288c,0xb42a896c,0x33ac0dee,0x12cdac0e,0x510eeecf,0x706f4f2f,
0x90b0d070,0xb1d17190,0xf2123351,0xd37392b1,0x54f51633,0x7594b7d3,0x3657f512,0x173654f2,
0x395bfd17,0x183a5cf7,0x5bf91e36,0x7a98bfd6,0xfd1e3b54,0xdc7f9ab4,0x9fbcd875,0xbedd7995,
0xe2062a5e,0xc3678bbe,0x80a4c97f,0xa1c5689f,0x2643ec1d,0x07224dfd,0x44e10f3c,0x6580aedc,
0x4bed0739,0x6a8ca6d9,0x294fe418,0x082e45f8,0x8fa8c17a,0xaec9609a,0xed0a225b,0xcc6b83bb,
0x74dc242c,0x55bd85cc,0x167ec70d,0x371f66ed,0xb099e26f,0x91f8438f,0xd23b014e,0xf35aa0ae,
0xdd37094b,0xfc56a8ab,0xbf95ea6a,0x9ef44b8a,0x1972cf08,0x38136ee8,0x7bd02c29,0x5ab18dc9,
0x066ade02,0x270b7fe2,0x64c83d23,0x45a99cc3,0xc22f1841,0xe34eb9a1,0xa08dfb60,0x81ec5a80,
0xaf81f365,0x8ee05285,0xcd231044,0xec42b1a4,0x6bc43526,0x4aa594c6,0x0966d607,0x280777e7,
0x586838c8,0x79099928,0x3acadbe9,0x1bab7a09,0x9c2dfe8b,0xbd4c5f6b,0xfe8f1daa,0xdfeebc4a,
0xf18315af,0xd0e2b44f,0x9321f68e,0xb240576e,0x35c6d3ec,0x14a7720c,0x576430cd,0x7605912d,
0x2adec2e6,0x0bbf6306,0x487c21c7,0x691d8027,0xee9b04a5,0xcffaa545,0x8c39e784,0xad584664,
0x8335ef81,0xa2544e61,0xe1970ca0,0xc0f6ad40,0x477029c2,0x66118822,0x25d2cae3,0x04b36b03,
0xbc04cc94,0x9d656d74,0xdea62fb5,0xffc78e55,0x78410ad7,0x5920ab37,0x1ae3e9f6,0x3b824816,
0x15efe1f3,0x348e4013,0x774d02d2,0x562ca332,0xd1aa27b0,0xf0cb8650,0xb308c491,0x92696571,
0xceb236ba,0xefd3975a,0xac10d59b,0x8d71747b,0x0af7f0f9,0x2b965119,0x685513d8,0x4934b238,
0x67591bdd,0x4638ba3d,0x05fbf8fc,0x249a591c,0xa31cdd9e,0x827d7c7e,0xc1be3ebf,0xe0df9f5f,
};
//input four 16 byte masks: U,WX,WY,WZ, tranform them into bitslice mask
//i.e., 16*8 U_i||WX_i||Wy_i||WZ_i
inline void SliceFourMask(uint8_t* u, uint8_t* wx, uint8_t* wy, uint8_t* wz, uint8_t edgelen, std::array<std::array<uint8_t, 8>, 16> &z)
{
	//construct w
	for (uint8_t k = 0; k < edgelen * edgelen; k++)
		for (uint8_t i = 0; i < 8; i++)//byte size
			z[k][i] = (((u[k] >> i) & 0x1) << 3) + (((wx[k] >> i) & 0x1) << 2) + (((wy[k] >> i) & 0x1) << 1) + ((wz[k] >> i) & 0x1);
}
//These functions corresponds to Algorithm 2 in the paper
//z: bitsliced masks, edgelen: the size of row or column, e.g., edgelen is 4 for AES
//AVX version
inline double ComputeThreeAdditionDistributionWithSigma_Binary(std::array<std::array<uint8_t, 8>, 16> z, uint8_t edgelen)
{

	//std::array<double, 4> C = { 0,0,0,0 };//column vector C
	__m256d C = _mm256_setzero_pd();
	//std::array<double, 4> T = { 0,0,0,0 };//temp vector
	__m256d T = _mm256_setzero_pd();

	STATIC_CACHE_ALIGN_AVX2 double M[4 * 32] = { 1,0,0,0 };
	//__m256d M[4][8] = { 1,0,0,0 };
	//std::array<std::array<double, 32>, 4> M = { { {1,0,0,0},{0},{0},{0} } };
	//std::array<double, 32> MT = { 0 };
	//(0,0)-(0,3)
	for (uint8_t r = 0; r < edgelen; r++)
	{
		for (uint8_t cr_list = 0; cr_list < (1 << r); cr_list++)//r=1:0,1;r=2:0,1,2,3
		{
			C = _mm256_castpd128_pd256(_mm_load_pd(M + (cr_list << 1)));//
			for (uint8_t s = 0; s < 8; s++)
			{
				T = _mm256_add_pd(_mm256_mul_pd(A[z[r][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[r][s]][1], _mm256_permute4x64_pd(C, 0x55)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[r][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[r][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
				C = T;
			}
			_mm256_store_pd(M + 32 + (cr_list << 2), C);
		}
		memcpy(M, M + 32, 32 * sizeof(double));//m[0]=M[1]
	}
	//the prob of row carry (c0,c1,c2,c3) =M[0][(c0,c1,c2,c3)*2+0]+M[0][(c0,c1,c2,c3)*2+1]
	//column 1 to 3
	for (uint8_t c = 1; c < edgelen; c++)
	{
		for (uint8_t cr_hst = 0; cr_hst < (1 << edgelen); cr_hst++)//all possible histories of (cr0,cr1,cr2,cr3)
		{
			//(0,c)
			//C.fill(0);
			//M[1].fill(0);
			C = _mm256_setzero_pd();
			memset(M + 32, 0, 32 * sizeof(double));
			//hst=(crp0,crp1,...,crp_edgelen-1)
			uint8_t crp = ((cr_hst >> (edgelen - 1)) & 0x1);//crp0 row carry from previous
			//the first block of each column is difference(*,0,*,0)
			//the pre cc always =0, but crp could be 0/1
			//M[0][(crp0,crp1,...,crp_ed-1,cc)]
			double tmp = M[cr_hst << 1] + M[(cr_hst << 1) + 1];
			C = _mm256_castpd128_pd256(_mm_load_pd1(&tmp));
			if (crp == 0)
				C = _mm256_permute4x64_pd(C, 0xFD);
			else
				C = _mm256_permute4x64_pd(C, 0xDF);

			for (uint8_t s = 0; s < 8; s++)//transition
			{
				T = _mm256_add_pd(_mm256_mul_pd(A[z[c * edgelen][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[c * edgelen][s]][1], _mm256_permute4x64_pd(C, 0x55)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
				C = T;
			}
			_mm256_store_pd(M + 32, C);
			//(1,c)~(3,c)
			for (uint8_t r = 1; r < edgelen; r++)
			{
				crp = ((cr_hst >> (edgelen - r - 1)) & 0x1);//crpi row carry from previous
				for (uint8_t cr_list = 0; cr_list < (1 << r); cr_list++)//r=1:0,1;r=2:0,1,2,3
				{
					//loading crp==1:(*,*,0,0,); crp=0:(0,0,*,*)
					C = _mm256_castpd128_pd256(_mm_load_pd(M + 32 + (cr_list << 1)));
					if (crp == 1)
						C = _mm256_permute4x64_pd(C, 0x4E);
					for (uint8_t s = 0; s < 8; s++)//transition
					{
						T = _mm256_add_pd(_mm256_mul_pd(A[z[c * edgelen + r][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[c * edgelen + r][s]][1], _mm256_permute4x64_pd(C, 0x55)));
						T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen + r][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
						T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen + r][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
						C = T;
					}
					_mm256_store_pd(M + 64 + (cr_list << 2), C);
				}
				memcpy(M + 32, M + 64, 32 * sizeof(double));
				memset(M + 64, 0, 32 * sizeof(double));
			}
			//for each possible cr_hst, compute one M[1], then summation
			for (uint8_t i = 0; i < 32; i++)
				M[i + 96] += M[i + 32];
		}
		//printf("F2: %f,%f,%f,%f\n", F2[0], F2[1], F2[2], F2[3]);
		//M[0] = MT;
		//MT.fill(0);
		memcpy(M, M + 96, 32 * sizeof(double));
		memset(M + 96, 0, 32 * sizeof(double));
	}
	//accumulate M[0]
	double cor = 0;
	for (uint8_t cr_list = 0; cr_list < (1 << edgelen); cr_list++)
		cor += (M[(cr_list << 1)] + M[(cr_list << 1) + 1]);
	return cor;
}
inline double EvaluateSboxAdditionCorrelation(double* AS, uint8_t u[4], uint8_t wx[4], uint8_t wy[4])
{
	//addtional 4 parallel sbxes
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	__m128d CC1 = _mm_set_pd(0, 1.0);
	//__m128d TT = _mm_load_pd(AS + Position(u[0], wx[0], wy[0]));
	//__m128d TTT = _mm_load_pd(AS + (Position(u[0], wx[0], wy[1]) ^ 2));
	__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[0], wx[0], wy[0])), CC1),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[0], wx[0], wy[0]) ^ 2)), CC1));
	__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[1], wx[1], wy[1])), CC2),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[1], wx[1], wy[1]) ^ 2)), CC2));
	__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[2], wx[2], wy[2])), CC3),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[2], wx[2], wy[2]) ^ 2)), CC3));
	__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[3], wx[3], wy[3])), CC4),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[3], wx[3], wy[3]) ^ 2)), CC4));
	_mm_store_pd(cor_vec, CC5);
	return cor_vec[0] + cor_vec[1];
}
void IPrint(uint8_t x[16])
{
	for (int i = 0; i < 16; i++)
		printf("%2.2x,", x[i]);
	printf("\n");
}
void SigmaAdditionNewtrails(FILE* ofs)
{
    double cor=0;
    //1
    //step 1 compute all sigma-addition with input output mask be in speical form, store the mask with correlatioin vaule >=35.0
    //MINV_T=block_matrix(4,4,[E.transpose(),N.transpose(),D.transpose(),B.transpose(),
    //                     B.transpose(),E.transpose(),N.transpose(),D.transpose(),
    //                     D.transpose(),B.transpose(),E.transpose(),N.transpose(),
    //                     N.transpose(),D.transpose(),B.transpose(),E.transpose()])
        uint8_t U[16]={0};
        uint8_t V[16]={0};
        uint8_t W[16]={0};
        uint8_t T[16]={0};
#pragma omp parallel for collapse(2) firstprivate(U,V,W,T)
        for(int16_t x =1; x< 256; x++)
            for(int16_t y= 1;y < 256;y++)
            {
                U[12] = W[3] =T[3] = ExtractLowByte(NDBE[x],0);
                U[13] = W[7] =T[7] = ExtractLowByte(NDBE[x],1);
                U[14] = W[11] =T[11] = ExtractLowByte(NDBE[x],2);
                U[15] = W[15] =T[15] = ExtractLowByte(NDBE[x],3);
                W[3]^=(y&0xFF);

                for(uint64_t c = 0; c <= 0xFFFFFFFF; c++ )
                //for(uint64_t c = 0x81ec5a00; c <= 0x81ec5a00; c++ )
                {
                    V[12]=(c&0xFF);
                    V[13]=((c>>8)&0xFF);
                    V[14]=((c>>16)&0xFF);
                    V[15]=((c>>24)&0xFF);

                    std::array<std::array<uint8_t, 8>, 16> z = { 0 };
                    SliceFourMask(U, V, W, T, 4, z);
                    //Algorithm 2
                    double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
                     if (log2(abs(cor)) >= -36.0)
                    {
#pragma omp critical
{
                        fprintf(ofs, "V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n", 
                        V[12],V[13],V[14],V[15], U[12],U[13],U[14],U[15], (y&0xFF), log2(abs(cor)));
                        printf("V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n", 
                        V[12],V[13],V[14],V[15], U[12],U[13],U[14],U[15], (y&0xFF), log2(abs(cor)));
}
                    }

                }

            }

}
void SigmaAdditionBinaryApproximation_0011(FILE* gptr)
{
		uint8_t U[16] = { 0 };
		uint8_t V[16] = { 0 };
		uint8_t W[16] = { 0 };
		uint8_t T[16] = { 0 };
#pragma omp parallel for collapse(4) firstprivate(U,V,W,T)
		for (int32_t x = 1; x < 256; x++)
			for (int32_t y = 1; y < 256; y++)
				for (int32_t i = 0; i < 256; i++)
					for (int32_t j = 0; j < 256; j++)
					{
						V[12] = U[12] = W[3] = T[3] = ExtractLowByte(NDBE[x], 0);
						V[13] = U[13] = W[7] = T[7] = ExtractLowByte(NDBE[x], 1);
						V[14] = U[14] = W[11] = T[11] = ExtractLowByte(NDBE[x], 2);
						V[15] = U[15] = W[15] = T[15] = ExtractLowByte(NDBE[x], 3);

						V[8] = U[8] = W[2] = T[2] = ExtractLowByte(NDBE[y], 0);
						V[9] = U[9] = W[6] = T[6] = ExtractLowByte(NDBE[y], 1);
						V[10] = U[10] = W[10] = T[10] = ExtractLowByte(NDBE[y], 2);
						V[11] = U[11] = W[14] = T[14] = ExtractLowByte(NDBE[y], 3);

						V[12] = (i & 0xFF);
						W[3] = (i & 0xFF);
						V[8] = (j & 0xFF);
						W[2] = (j & 0xFF);

						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						if (log2(abs(cor)) >= -36.0)
						{
#pragma omp critical
							{
								fprintf(gptr, "V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n",
									V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (y & 0xFF), log2(abs(cor)));
								printf("V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n",
									V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (y & 0xFF), log2(abs(cor)));
							}
						}
					}


}
void SigmaAdditionBinaryApproximation_0011a(FILE* gptr)
{
	uint8_t U[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t W[16] = { 0 };
	uint8_t T[16] = { 0 };
#pragma omp parallel for collapse(2) firstprivate(U,V,W,T)
	for (int32_t x = 1; x < 256; x++)
		for (int32_t y = 1; y < 256; y++)
		{
			V[12] = U[12] = W[3] = T[3] = ExtractLowByte(NDBE[x], 0);
			V[13] = U[13] = W[7] = T[7] = ExtractLowByte(NDBE[x], 1);
			V[14] = U[14] = W[11] = T[11] = ExtractLowByte(NDBE[x], 2);
			V[15] = U[15] = W[15] = T[15] = ExtractLowByte(NDBE[x], 3);
			V[8] = U[8] = W[2] = T[2] = ExtractLowByte(NDBE[x], 0);
			V[9] = U[9] = W[6] = T[6] = ExtractLowByte(NDBE[x], 1);
			V[10] = U[10] = W[10] = T[10] = ExtractLowByte(NDBE[x], 2);
			V[11] = U[11] = W[14] = T[14] = ExtractLowByte(NDBE[x], 3);

			V[12] = (y & 0xFF);
			W[3] = (y & 0xFF);
			V[8] = (y & 0xFF);
			W[2] = (y & 0xFF);
			uint32_t msb = 0x80;
			for (uint8_t s = 0; s < 8; s++)
			{
				if ((msb & V[15]) != 0)
					break;
				else
					msb >>= 1;
			}

			for (int32_t i = 0; i < (msb&0xFF); i++)
				for (int32_t j = 0; j < 256; j++)
				{
					V[14] = V[10] = (j&0xFF);
					V[15] = V[11] = (i&0xFF);

					std::array<std::array<uint8_t, 8>, 16> z = { 0 };
					SliceFourMask(U, V, W, T, 4, z);
					//Algorithm 2
					double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
					if (log2(abs(cor)) >= -36.0)
					{
#pragma omp critical
						{
							fprintf(gptr, "V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n",
								V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (y & 0xFF), log2(abs(cor)));
							printf("V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,%f\n",
								V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (y & 0xFF), log2(abs(cor)));
						}
					}
				}

		}
}
void SearchSigmaAddition(FILE * gptr)
{
	//1. sigma addition part
	uint8_t U[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t W[16] = { 0 };
	uint8_t T[16] = { 0 };
	for (int16_t m = 1; m < 256; m++)
		for (int16_t x = 1; x < 256; x++)
		{
			V[12] = U[12] = W[3] = T[3] = ExtractLowByte(NDBE[m], 0);
			V[13] = U[13] = W[7] = T[7] = ExtractLowByte(NDBE[m], 1);
			V[14] = U[14] = W[11] = T[11] = ExtractLowByte(NDBE[m], 2);
			V[15] = U[15] = W[15] = T[15] = ExtractLowByte(NDBE[m], 3);

			V[12] ^= (x & 0xFF);
			W[3] ^= (x & 0xFF);
			std::array<std::array<uint8_t, 8>, 16> z = { 0 };
			SliceFourMask(U, V, W, T, 4, z);
			//Algorithm 2
			double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
			if (log2(abs(cor)) >= -40.0)
			{
				fprintf(gptr, "V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,in:0x%2.2x,%f\n",
					V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (x & 0xFF), (m & 0xFF), log2(abs(cor)));
				printf("V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,in:0x%2.2x,%f\n",
					V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (x & 0xFF), (m & 0xFF), log2(abs(cor)));
			}
		}
}
void SearchSigmaAddition2(FILE* gptr)
{
	//1. sigma addition part
	uint8_t U[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t W[16] = { 0 };
	uint8_t T[16] = { 0 };
	for (int16_t m = 1; m < 256; m++)
		for (int16_t x = 1; x < 256; x++)
			for (int16_t n = 1; n < 256; n++)
				for (int16_t y = 1; y < 256; y++)
				{
					 W[3] = T[3] = ExtractLowByte(NDBE[m], 0);
					 W[7] = T[7] = ExtractLowByte(NDBE[m], 1);
					 W[11] = T[11] = ExtractLowByte(NDBE[m], 2);
					 W[15] = T[15] = ExtractLowByte(NDBE[m], 3);

					V[12] = U[12]  = ExtractLowByte(NDBE[n], 0);
					V[13] = U[13]  = ExtractLowByte(NDBE[n], 1);
					V[14] = U[14]  = ExtractLowByte(NDBE[n], 2);
					V[15] = U[15]  = ExtractLowByte(NDBE[n], 3);

					V[12] ^= (y & 0xFF);
					W[3] ^= (x & 0xFF);

					std::array<std::array<uint8_t, 8>, 16> z = { 0 };
					SliceFourMask(U, V, W, T, 4, z);
					//Algorithm 2
					double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
					if (log2(abs(cor)) >= -40.0)
					{
						fprintf(gptr, "V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,in:0x%2.2x,%f\n",
							V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (x & 0xFF), (m & 0xFF), log2(abs(cor)));
						printf("V: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,U:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,beta:0x%2.2x,in:0x%2.2x,%f\n",
							V[12], V[13], V[14], V[15], U[12], U[13], U[14], U[15], (x & 0xFF), (m & 0xFF), log2(abs(cor)));
					}
				}
}
void SearchSigmaAddition3(FILE* gptr)
{
	//1. sigma addition part
	//initializing all psi and psi'
	std::vector<uint32_t> Psi = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0};
	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1,
		 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	std::vector<std::vector<uint32_t> > Psip;
	for (int n = 0; n < Psi.size(); n++)
	{
		uint32_t mid = (Psi[n] & 0x00FFFFFF);
		std::vector<uint32_t> tmp;
		for(auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				tmp.push_back((a << 24) ^ mid ^ b);
			}
		Psip.push_back(tmp);
	}
	/*std::vector<std::vector<uint32_t> > Psip = {
		{0x81ec5a00,0x81ec5ac0,0x81ec5aa0,0x81ec5a90,0x81ec5a81,
		 0xc1ec5a00,0xc1ec5ac0,0xc1ec5aa0,0xc1ec5a90,0xc1ec5a81,  
		 0xa1ec5a00,0xa1ec5ac0,0xa1ec5aa0,0xa1ec5a90, 
		 0xe1ec5a00,0xe1ec5ac0,0xe1ec5aa0,0xe1ec5a90,
		 0x91ec5a00,0x91ec5ac0,0x91ec5aa0,
		 0xb1ec5a00,0xb1ec5ac0,0xb1ec5aa0,
		 0xd1ec5a00,0xd1ec5ac0,0xd1ec5aa0,
		 0xf1ec5a00,0xf1ec5ac0,0xf1ec5aa0,
		},
		{0x411af780,0x411af7e0,0x611af780,0x611af7e0,  0x511af780, 0x711af780},
		{0x2161a1c0,0x3161a1c0}	};*/

	uint8_t U[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t W[16] = { 0 };
	uint8_t T[16] = { 0 };

	for (int16_t m = 1; m < 256; m++)//lambda2
		//for (int16_t m = 0xb7; m < 0xb8; m++)//lambda2
		for (int16_t la = 1; la < 256; la++)//lambda
			//for (int16_t la = 0x80; la < 0x81; la++)//lambda
			for (int16_t x = 0; x < 4; x++)//rotate
				//for (int16_t x = 0; x < 1; x++)//rotate
				for (int16_t n = 0; n < Psi.size(); n++)//psi
					for (int16_t y = 0; y < Psip[n].size(); y++)
					{
						//initialize U,V
						U[12] = ExtractLowByte(Psi[n], 0);
						U[13] = ExtractLowByte(Psi[n], 1);
						U[14] = ExtractLowByte(Psi[n], 2);
						U[15] = ExtractLowByte(Psi[n], 3);

						V[12] = ExtractLowByte(Psip[n][y], 0);
						V[13] = ExtractLowByte(Psip[n][y], 1);
						V[14] = ExtractLowByte(Psip[n][y], 2);
						V[15] = ExtractLowByte(Psip[n][y], 3);

						//initialize W,T
						T[3] = ExtractLowByte(LeftRote(NDBE[m],x), 0);
						T[7] = ExtractLowByte(LeftRote(NDBE[m], x), 1);
						T[11] = ExtractLowByte(LeftRote(NDBE[m], x), 2);
						T[15] = ExtractLowByte(LeftRote(NDBE[m], x), 3);

						W[3] = (ExtractLowByte(LeftRote(NDBE[m], x), 0)^la);
						W[7] = ExtractLowByte(LeftRote(NDBE[m], x), 1);
						W[11] = ExtractLowByte(LeftRote(NDBE[m], x), 2);
						W[15] = ExtractLowByte(LeftRote(NDBE[m], x), 3);


						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						if (log2(abs(cor)) >= -40.0)
						{
							fprintf(gptr, "U:%8.8x,V:%8.8x,T:%8.8x,W:%8.8x,La:%2.2x,La2:%2.2x,rot:%d,cor:%f\n",
								Psi[n],Psip[n][y], LeftRote(NDBE[m], x), LeftRote(NDBE[m], x)^la,la,m,x, log2(abs(cor)));
							printf("U:%8.8x,V:%8.8x,T:%8.8x,W:%8.8x,La:%2.2x,La2:%2.2x,rot:%d,cor:%f\n",
								Psi[n], Psip[n][y], LeftRote(NDBE[m], x), LeftRote(NDBE[m], x) ^ la, la, m, x, log2(abs(cor)));
						}
					}
}

double SearchSboxAddition(uint8_t a[2], uint8_t b[2])
{
	double cor1 = 0, maxcor1 = -200.0, cors = 0, cor2 = 0, maxcor2 = -200.0;
	uint8_t maxlap = 0, maxgap = 0, maxga = 0;
	//1
	uint8_t umask1[4] = { 0,0,0,0 };
	uint8_t xmask1[4] = { 0,0,0,0 };
	uint8_t ymask1[4] = { 0,0,0,0 };
	umask1[0] = a[1];
	ymask1[0] = a[0];
	//2
	uint8_t umask2[4] = { 0,0,0,0 };
	uint8_t xmask2[4] = { 0,0,0,0 };
	uint8_t ymask2[4] = { 0,0,0,0 };
	ymask2[0] = b[0];

	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1
		for (uint16_t lap = 1; lap < 256; lap++)
		{
			xmask1[0] = (lap & 0xFF);
			cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
			if (log2(abs(cor1)) >= maxcor1)
			{
				maxcor1 = log2(abs(cor1));
				maxlap = xmask1[0];
			}
		}
		printf("1-Lap:0x%2.2x,cor1:%f;\n", maxlap, maxcor1);

		//2
		for (uint16_t ga = 1; ga < 256; ga++)
		{
			umask2[0] = (ga & 0xFF);
			cors = AES_SBOX_LAT[ga][b[1]];//exponents
			for (uint16_t gap = 1; gap < 256; gap++)
			{
				xmask2[0] = (gap & 0xFF);
				cor2 = EvaluateSboxAdditionCorrelation(AS, umask2, xmask2, ymask2);
				if (log2(abs(cor2)) + cors > maxcor2)
				{
					maxcor2 = log2(abs(cor2)) + cors;
					maxga= (ga & 0xFF);
					maxgap = (gap & 0xFF);
				}
			}
		}
		printf("2-gap:0x%2.2x,ga:0x%2.2x,cor2:%f,total:%f;\n", maxgap, maxga, maxcor2, maxcor2 + maxcor1);
		fclose(fptr);
		_mm_free(AS);
	}
	return maxcor2 + maxcor1;
}
inline bool SameSuffixCondition(uint8_t u[4], uint8_t x[4], uint8_t y[4], uint8_t len)
{
	if (u[len - 1] != 0 && (((x[len - 1] & 0x80) == 0x80 && (y[len - 1] & 0x80) == 0x80) || ((x[len - 1] & 0xc0) == 0x40 && (y[len - 1] & 0xc0) == 0x40) ||
		((x[len - 1] & 0xe0) == 0x20 && (y[len - 1] & 0xe0) == 0x20) || ((x[len - 1] & 0xf0) == 0x10 && (y[len - 1] & 0xf0) == 0x10) ||
		((x[len - 1] & 0xf8) == 0x08 && (y[len - 1] & 0xf8) == 0x08) || ((x[len - 1] & 0xfc) == 0x04 && (y[len - 1] & 0xfc) == 0x04) ||
		((x[len - 1] & 0xfe) == 0x02 && (y[len - 1] & 0xfe) == 0x02) || ((x[len - 1] & 0xff) == 0x01 && (y[len - 1] & 0xff) == 0x01)))
		return true;
	else
		return false;
}
inline bool ByteSameSuffixCondition(uint8_t u, uint8_t x, uint8_t y)
{
	if (u != 0 && (((x & 0x80) == 0x80 && (y & 0x80) == 0x80) || ((x & 0xc0) == 0x40 && (y & 0xc0) == 0x40) ||
		((x & 0xe0) == 0x20 && (y & 0xe0) == 0x20) || ((x & 0xf0) == 0x10 && (y & 0xf0) == 0x10) ||
		((x & 0xf8) == 0x08 && (y & 0xf8) == 0x08) || ((x & 0xfc) == 0x04 && (y & 0xfc) == 0x04) ||
		((x & 0xfe) == 0x02 && (y & 0xfe) == 0x02) || ((x & 0xff) == 0x01 && (y & 0xff) == 0x01)))
		return true;
	else
		return false;
}

void SearchOuterMask_Group1(FILE* gptr, uint8_t U[16], uint8_t T[16], uint8_t Ph2[4],uint8_t La2[4])
{
	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double));
	//uint8_t* maxlap = (uint8_t*)malloc((1 << 16) * sizeof(uint8_t));

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };

	std::vector<uint8_t> beta;
	beta.push_back(0x80);
	beta.push_back(0x40);

	
	for (uint8_t i = 0; i < 16; i++)
	{
		V[i] = U[i];
	}
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint16_t be = 1; be < 256; be++)
			for (uint16_t m = 1; m < 256; m++)
			{
				Lap[0] = (m & 0xFF);
				La[0] = (be & 0xFF);
				double cor1 = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2);
				maxcor1[(be << 8) + m] = cor1;

			}
		//--------------------------------------------
#pragma omp parallel for collapse(3) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		//for (int32_t be = 1; be < 256; be++)
		for (int32_t be = 1; be < beta.size(); be++)
			//for (int32_t l = 1; l < 256; l++)
			//	for (int32_t al = 1; al < 256; al++)
					for (int32_t l = 0x0d; l < 0x0e; l++)
						for (int32_t al = 0x0d; al < 0x0e; al++)
				{
					Gap[0] = (l & 0xFF);
					Ga[0] = (al & 0xFF);

					double cors = AES_SBOX_LAT[al][La2[0]];//here lat table should be modified to value
					bsum = 0;
					//for (int32_t b = 1; b < 256; b++)//run over indeterminate
					for (int32_t b = 0xb7; b < 0xb8; b++)//run over indeterminate
					{
						//comput cor2
						Ga2[0] = (b & 0xFF);
						double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

						W[3] = ExtractLowByte(NDBE[b], 0);
						W[7] = ExtractLowByte(NDBE[b], 1);
						W[11] = ExtractLowByte(NDBE[b], 2);
						W[15] = ExtractLowByte(NDBE[b], 3);
						V[12] = U[12];

						W[3] ^= (beta[be] & 0xFF);
						V[12] ^= (beta[be] & 0xFF);

						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						bsum += (cora * cor2);
						//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
						if (b == 0xb7)
						{
							IPrint(U);
							IPrint(V);
							IPrint(W);
							IPrint(T);
						}
					}
					printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

					//for (uint16_t m = 1; m < 256; m++)
					for (uint16_t m = 0x40; m < 0x41; m++)
					{
						double currentcor = maxcor1[(beta[be] << 8) + m] * bsum * cors;
						printf("m:%2.2x,%f,%f,%f\n", m, log2(abs(maxcor1[(beta[be] << 8) + m])), log2(abs(bsum * cors)), log2(abs(currentcor)));

						if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
						{
							cor50++;
						}
						else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
						{
							cor49++;
						}
						else if (log2(abs(currentcor)) > -48)
						{
							cor48++;
#pragma omp critical
							{
								fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0],Ga[0],Lap[0],beta[be],V[12],V[13],V[14],V[15], log2(abs(currentcor)));
								printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0], Ga[0], Lap[0], beta[be],  V[12], V[13], V[14], V[15], log2(abs(currentcor)));
							}
						}
					}

				}
		fprintf(gptr,"cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group2(FILE* gptr, uint8_t U[16], uint8_t T[16], uint8_t Ph2[4], uint8_t La2[4])
{
	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double));
	//uint8_t* maxlap = (uint8_t*)malloc((1 << 16) * sizeof(uint8_t));

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };

	std::vector<uint8_t> beta;
	beta.push_back(0x40);
	beta.push_back(0x20);


	for (uint8_t i = 0; i < 16; i++)
	{
		V[i] = U[i];
	}
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint16_t be = 1; be < 256; be++)
			for (uint16_t m = 1; m < 256; m++)
			{
				Lap[0] = (m & 0xFF);
				La[0] = (be & 0xFF);
				double cor1 = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2);
				maxcor1[(be << 8) + m] = cor1;

			}
		//--------------------------------------------
#pragma omp parallel for collapse(3) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		//for (int32_t be = 1; be < 256; be++)
		for (int32_t be = 0; be < beta.size(); be++)
			for (int32_t l = 1; l < 256; l++)
				for (int32_t al = 1; al < 256; al++)
				{
					Gap[0] = (l & 0xFF);
					Ga[0] = (al & 0xFF);

					double cors = AES_SBOX_LAT[al][La2[0]];//here lat table should be modified to value
					bsum = 0;
					for (int32_t b = 0; b < 256; b++)//run over indeterminate
					//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
					{
						//comput cor2
						Ga2[0] = (b & 0xFF);
						double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

						W[3] = ExtractLowByte(NDBE[b], 0);
						W[7] = ExtractLowByte(NDBE[b], 1);
						W[11] = ExtractLowByte(NDBE[b], 2);
						W[15] = ExtractLowByte(NDBE[b], 3);
						V[12] = U[12];

						W[3] ^= (beta[be] & 0xFF);
						V[12] ^= (beta[be] & 0xFF);

						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						bsum += (cora * cor2);
						//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
					}
					for (uint16_t m = 1; m < 256; m++)
					{
						double currentcor = maxcor1[(beta[be] << 8) + m] * bsum * cors;
						if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
						{
							cor50++;
						}
						else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
						{
							cor49++;
						}
						else if (log2(abs(currentcor)) > -48)
						{
							cor48++;
#pragma omp critical
							{
								fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0], Ga[0], Lap[0], beta[be], V[12], V[13], V[14], V[15], log2(abs(currentcor)));
								printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0], Ga[0], Lap[0], beta[be], V[12], V[13], V[14], V[15], log2(abs(currentcor)));
							}
						}
					}

				}
		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group3(FILE* gptr, uint8_t U[16], uint8_t T[16], uint8_t Ph2[4], uint8_t La2[4])
{
	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double));
	//uint8_t* maxlap = (uint8_t*)malloc((1 << 16) * sizeof(uint8_t));

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };

	std::vector<uint8_t> beta;
	beta.push_back(0x20);


	for (uint8_t i = 0; i < 16; i++)
	{
		V[i] = U[i];
	}
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint16_t be = 1; be < 256; be++)
			for (uint16_t m = 1; m < 256; m++)
			{
				Lap[0] = (m & 0xFF);
				La[0] = (be & 0xFF);
				double cor1 = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2);
				maxcor1[(be << 8) + m] = cor1;

			}
		//--------------------------------------------
#pragma omp parallel for collapse(3) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		//for (int32_t be = 1; be < 256; be++)
		for (int32_t be = 0; be < beta.size(); be++)
			for (int32_t l = 1; l < 256; l++)
				for (int32_t al = 1; al < 256; al++)
				{
					Gap[0] = (l & 0xFF);
					Ga[0] = (al & 0xFF);

					double cors = AES_SBOX_LAT[al][La2[0]];//here lat table should be modified to value
					bsum = 0;
					for (int32_t b = 0; b < 256; b++)//run over indeterminate
					//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
					{
						//comput cor2
						Ga2[0] = (b & 0xFF);
						double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

						W[3] = ExtractLowByte(NDBE[b], 0);
						W[7] = ExtractLowByte(NDBE[b], 1);
						W[11] = ExtractLowByte(NDBE[b], 2);
						W[15] = ExtractLowByte(NDBE[b], 3);
						V[12] = U[12];

						W[3] ^= (beta[be] & 0xFF);
						V[12] ^= (beta[be] & 0xFF);

						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						bsum += (cora * cor2);
						//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
					}
					for (uint16_t m = 1; m < 256; m++)
					{
						double currentcor = maxcor1[(beta[be] << 8) + m] * bsum * cors;
						if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
						{
							cor50++;
						}
						else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
						{
							cor49++;
						}
						else if (log2(abs(currentcor)) > -48)
						{
							cor48++;
#pragma omp critical
							{
								fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0], Ga[0], Lap[0], beta[be], V[12], V[13], V[14], V[15], log2(abs(currentcor)));
								printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor:%f\n",
									Gap[0], Ga[0], Lap[0], beta[be], V[12], V[13], V[14], V[15], log2(abs(currentcor)));
							}
						}
					}

				}
		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group4(FILE* gptr)
{
	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double)*3);
	//uint8_t* maxlap = (uint8_t*)malloc((1 << 16) * sizeof(uint8_t));

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	//uint8_t T[16] = { 0 };

	uint8_t Ph2[3][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0} };
	uint8_t La2[4][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0,0,0x08,0} };

	//all possible beta
	uint8_t U[3][16] = { 
		{0,0,0,0,0,0,0,0,0,0,0,0,0x80,0x5a,0xec,0x81}, 
		{0,0,0,0,0,0,0,0,0,0,0,0,0xc0,0xf7,0x1a,0x41},
		{0,0,0,0,0,0,0,0,0,0,0,0,0xe0,0xa1,0x61,0x21}};
	std::vector<std::vector<uint8_t> > delta = {
		{0x80,0x40,0x20},{0x40,0x20},{0x20} };
	std::vector<std::vector<uint8_t> > beta = {
	{0x80,0x40,0x20},{0x40,0x20},{0x20},{0x08}};
	uint8_t T[4][16] = {
		0,0,0,0x80,0,0,0,0x5a,0,0,0,0xec,0,0,0,0x81,
		0,0,0,0xc0,0,0,0,0xf7,0,0,0,0x1a,0,0,0,0x41,
		0,0,0,0xe0,0,0,0,0xa1,0,0,0,0x61,0,0,0,0x21,
		0,0,0,0xa8,0,0,0,0x8f,0,0,0,0x7a,0,0,0,0xc1//(0,*,0,0)->(*,*,*,*)
	};
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
	for (uint32_t i = 0; i < 3; i++)
		for (uint16_t be = 1; be < 256; be++)
			for (uint16_t m = 1; m < 256; m++)
			{
				Lap[0] = (m & 0xFF);
				La[0] = (be & 0xFF);
				double cor1 = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2[i]);
				maxcor1[(i<<16)+(be << 8) + m] = cor1;

			}
		//--------------------------------------------
#pragma omp parallel for collapse(2) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)
		//for (int32_t l = 0x0c; l < 0x0d; l++)
			for (int32_t al = 1; al < 256; al++)
			//for (int32_t al = 0x0c; al < 0x0d; al++)
				for (int32_t uind = 0;  uind < 3; uind++)
					for (int32_t tind = 0; tind < 3; tind++)
						for (uint16_t e : delta[uind])
							for (uint16_t be : beta[tind])
						{
							Gap[0] = (l & 0xFF);
							Ga[0] = (al & 0xFF);
							for (uint8_t i = 0; i < 16; i++)
							{
								V[i] = U[uind][i];
							}
							V[12] ^= e;

							double cors = AES_SBOX_LAT[al][La2[tind][0]];//here lat table should be modified to value
							bsum = 0;
							for (int32_t b = 1; b < 256; b++)//run over indeterminate
							//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
							{
								//comput cor2
								Ga2[0] = (b & 0xFF);
								double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

								W[3] = ExtractLowByte(NDBE[b], 0);
								W[7] = ExtractLowByte(NDBE[b], 1);
								W[11] = ExtractLowByte(NDBE[b], 2);
								W[15] = ExtractLowByte(NDBE[b], 3);


								W[3] ^= be;

								std::array<std::array<uint8_t, 8>, 16> z = { 0 };
								SliceFourMask(U[uind], V, W, T[tind], 4, z);
								//Algorithm 2
								double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
								bsum += (cora * cor2);
								if (b == 0xb7)
								{
									IPrint(U[uind]);
									IPrint(V);
									IPrint(W);
									IPrint(T[tind]);
									//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
								}
							}
							//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

							for (uint16_t m = 1; m < 256; m++)
							//for (uint16_t m = 0x40; m < 0x41; m++)
							{
								double currentcor = maxcor1[(uind<<16)+(be << 8) + m] * bsum * cors;
								//printf("m:%2.2x,%f,%f,%f\n",m, log2(abs(maxcor1[(uind << 16) + (be << 8) + m])),log2(abs(bsum * cors)), log2(abs(currentcor)));
								if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
								{
									cor50++;
								}
								else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
								{
									cor49++;
									fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
										Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
									printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
										Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
								}
								else if (log2(abs(currentcor)) > -48)
								{
									cor48++;
		#pragma omp critical
									{
										fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
											Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
											Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
									}
								}
							}

						}

#pragma omp parallel for collapse(2) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)
			for (int32_t al = 1; al < 256; al++)
				for (int32_t uind = 0; uind < 3; uind++)
					for (int32_t tind = 3; tind < 4; tind++)
						for (uint16_t e : delta[uind])
							for (uint16_t be : beta[tind])
							{
								Gap[2] = (l & 0xFF);
								Ga[2] = (al & 0xFF);
								for (uint8_t i = 0; i < 16; i++)
								{
									V[i] = U[uind][i];
								}
								V[12] ^= e;

								double cors = AES_SBOX_LAT[al][La2[tind][0]];//here lat table should be modified to value
								bsum = 0;
								for (int32_t b = 1; b < 256; b++)//run over indeterminate
								//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
								{
									//comput cor2
									Ga2[2] = (b & 0xFF);
									double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

									W[3] = ExtractLowByte(LeftRote(NDBE[b], 2), 0);
									W[7] = ExtractLowByte(LeftRote(NDBE[b], 2), 1);
									W[11] = ExtractLowByte(LeftRote(NDBE[b], 2), 2);
									W[15] = ExtractLowByte(LeftRote(NDBE[b], 2), 3);


									W[3] ^= be;

									std::array<std::array<uint8_t, 8>, 16> z = { 0 };
									SliceFourMask(U[uind], V, W, T[tind], 4, z);
									//Algorithm 2
									double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
									bsum += (cora * cor2);
									//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
								}
								for (uint16_t m = 1; m < 256; m++)
								{
									double currentcor = maxcor1[(uind << 16) + (be << 8) + m] * bsum * cors;
									if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
										fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
											Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
											Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));

									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,V[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,T[12~15]:0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, be, V[12], V[13], V[14], V[15], T[tind][3], T[tind][7], T[tind][11], T[tind][15], log2(abs(maxcor1[(uind << 16) + (be << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										}
									}
								}

							}


		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group5(FILE* gptr)
{
	uint32_t Psi[4] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0 };
	uint32_t Lambdastar[5] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0, 0xc17a8fa8};
	uint8_t Lambda[6] = { 0x80,0x40,0x20,0x10,0x08,0x04};

	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1, 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	//std::vector<std::vector<uint32_t> > Psip;
	uint32_t Psip[4][96] = { 0 };
	uint32_t Psip_size[4] = { 0 };
	for (int n = 0; n < 4; n++)
	{
		for (auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				Psip[n][Psip_size[n]] = ((a << 24) ^ (Psi[n] & 0x00FFFFFF) ^ b);
				Psip_size[n]++;
			}
	}

	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double) * 4);

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t U[16] = { 0 };
	uint8_t T[16] = { 0 };

	uint8_t Ph2[4][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0} };
	uint8_t La2[5][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0},{0,0,0x9c,0} };

	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint32_t i = 0; i < 4; i++)
			for (uint16_t be = 1; be < 256; be++)
				for (uint16_t m = 1; m < 256; m++)
				{
					Lap[0] = (m & 0xFF);
					La[0] = (be & 0xFF);
					double cor1 = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2[i]);
					maxcor1[(i << 16) + (be << 8) + m] = cor1;

				}
		//--------------------------------------------
#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			//for (int32_t l = 0x08; l < 0x09; l++)
			for (int32_t al = 1; al < 256; al++)//Ga
				//for (int32_t al = 0x0c; al < 0x0d; al++)
				for (int32_t uind = 0; uind < 4; uind++)//psi
					for (int32_t lind = 0; lind < 4; lind++)//Lambda*
						for (int32_t e = 0; e < 6; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[0] = (l & 0xFF);
								Ga[0] = (al & 0xFF);

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(Lambdastar[lind], 0);
								T[7] = ExtractLowByte(Lambdastar[lind], 1);
								T[11] = ExtractLowByte(Lambdastar[lind], 2);
								T[15] = ExtractLowByte(Lambdastar[lind], 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value
								bsum = 0;
								for (int32_t b = 1; b < 256; b++)//run over indeterminate
								//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
								{
									//comput cor2
									Ga2[0] = (b & 0xFF);
									double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

									W[3] = (ExtractLowByte(NDBE[b], 0)^Lambda[e]);
									W[7] = ExtractLowByte(NDBE[b], 1);
									W[11] = ExtractLowByte(NDBE[b], 2);
									W[15] = ExtractLowByte(NDBE[b], 3);

									std::array<std::array<uint8_t, 8>, 16> z = { 0 };
									SliceFourMask(U, V, W, T, 4, z);
									//Algorithm 2
									double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
									bsum += (cora * cor2);
									//if (b == 0xb7)
									//{
									//	IPrint(U);
									//	IPrint(V);
									//	IPrint(W);
									//	IPrint(T);
									//	//printf("(%2.2x,%f,%f,%f)\n", b, log2(abs(cora)), log2(abs(cor2)), log2(abs(bsum)));
									//}
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 1; m < 256; m++)
								//for (uint16_t m = 0x40; m < 0x41; m++)
								{
									double currentcor = maxcor1[(uind << 16) + (Lambda[e] << 8) + m] * bsum * cors;
									if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
//#pragma omp critical
//										{
//											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
//												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
//											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
//												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
//										}
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										}
									
									}
								}
							}

#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			for (int32_t al = 1; al < 256; al++)//Ga
				for (int32_t uind = 0; uind < 4; uind++)//psi
					for (int32_t lind = 4; lind < 5; lind++)//Lambda*
						for (int32_t e = 0; e < 6; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[0] = (l & 0xFF);
								Ga[0] = (al & 0xFF);

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(LeftRote(Lambdastar[lind],2), 0);
								T[7] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 1);
								T[11] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 2);
								T[15] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value
								bsum = 0;
								for (int32_t b = 1; b < 256; b++)//run over indeterminate
								//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
								{
									//comput cor2
									Ga2[0] = (b & 0xFF);
									double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

									W[3] = (ExtractLowByte(LeftRote(NDBE[b],2), 0) ^ Lambda[e]);
									W[7] = ExtractLowByte(LeftRote(NDBE[b], 2), 1);
									W[11] = ExtractLowByte(LeftRote(NDBE[b], 2), 2);
									W[15] = ExtractLowByte(LeftRote(NDBE[b], 2), 3);

									std::array<std::array<uint8_t, 8>, 16> z = { 0 };
									SliceFourMask(U, V, W, T, 4, z);
									//Algorithm 2
									double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
									bsum += (cora * cor2);
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 1; m < 256; m++)
								//for (uint16_t m = 0x40; m < 0x41; m++)
								{
									double currentcor = maxcor1[(uind << 16) + (Lambda[e] << 8) + m] * bsum * cors;
									//printf("m:%2.2x,%f,%f,%f\n",m, log2(abs(maxcor1[(uind << 16) + (be << 8) + m])),log2(abs(bsum * cors)), log2(abs(currentcor)));
									if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										}

									}
								}
							}


		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}

#define PSISIZE 4
#define LASIZE 6

typedef struct {
	double c;
	uint32_t m;
} pm;
bool cmppm(pm& a, pm& b)
{
	if (abs(a.c) > abs(b.c))
		return true;
	else
		return false;
}
//la* 5:
//psi:<4
//wi <8,
//ti <8,
//vi <128
//ui <4
//[2][7][3][3][8]
#define COR_START(ui,vi,ti,wi) ((((ui)<<13)^((vi)<<6)^((ti)<<3)^(wi))<<8)
void Precompute(double* cora)
{
	//assume cora size is 2^23 double

	uint32_t Psi[PSISIZE] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0 };
	uint32_t Lambdastar[PSISIZE + 1] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0, 0xc17a8fa8 };
	uint8_t Lambda[LASIZE] = { 0x80,0x40,0x20,0x10,0x08,0x04 };

	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1, 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	//generate V
	uint32_t Psip[PSISIZE][96] = { 0 };
	uint32_t Psip_size[PSISIZE] = { 0 };
	for (int n = 0; n < PSISIZE; n++)
	{
		for (auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				Psip[n][Psip_size[n]] = ((a << 24) ^ (Psi[n] & 0x00FFFFFF) ^ b);
				Psip_size[n]++;
			}
	}
	//
	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t U[16] = { 0 };
	uint8_t T[16] = { 0 };


	for (uint32_t u = 0; u < PSISIZE; u++)//U
	{
		U[12] = ExtractLowByte(Psi[u], 0);
		U[13] = ExtractLowByte(Psi[u], 1);
		U[14] = ExtractLowByte(Psi[u], 2);
		U[15] = ExtractLowByte(Psi[u], 3);

		for (uint32_t v = 0; v < Psip_size[u]; v++)//V
		{
			V[12] = ExtractLowByte(Psip[u][v], 0);
			V[13] = ExtractLowByte(Psip[u][v], 1);
			V[14] = ExtractLowByte(Psip[u][v], 2);
			V[15] = ExtractLowByte(Psip[u][v], 3);
			for (uint32_t t = 0; t < PSISIZE + 1; t++)//T
			{
				if (t < PSISIZE)
				{
					T[3] = ExtractLowByte(Lambdastar[t], 0);
					T[7] = ExtractLowByte(Lambdastar[t], 1);
					T[11] = ExtractLowByte(Lambdastar[t], 2);
					T[15] = ExtractLowByte(Lambdastar[t], 3);
				}
				else
				{
					T[3] = ExtractLowByte(LeftRote(Lambdastar[t], 2), 0);
					T[7] = ExtractLowByte(LeftRote(Lambdastar[t], 2), 1);
					T[11] = ExtractLowByte(LeftRote(Lambdastar[t], 2), 2);
					T[15] = ExtractLowByte(LeftRote(Lambdastar[t], 2), 3);

				}
				for (uint32_t w = 0; w < LASIZE; w++)//w_l
				{
					for (uint32_t b = 0; b < 256; b++)
					{
						if (t < PSISIZE)
						{
							W[3] = (ExtractLowByte(NDBE[b], 0) ^ Lambda[w]);
							W[7] = ExtractLowByte(NDBE[b], 1);
							W[11] = ExtractLowByte(NDBE[b], 2);
							W[15] = ExtractLowByte(NDBE[b], 3);
						}
						else
						{
							W[3] = (ExtractLowByte(LeftRote(NDBE[b], 2), 0) ^ Lambda[w]);
							W[7] = ExtractLowByte(LeftRote(NDBE[b], 2), 1);
							W[11] = ExtractLowByte(LeftRote(NDBE[b], 2), 2);
							W[15] = ExtractLowByte(LeftRote(NDBE[b], 2), 3);
						}

						std::array<std::array<uint8_t, 8>, 16> z = { 0 };
						SliceFourMask(U, V, W, T, 4, z);
						//Algorithm 2
						double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
						*(cora + (COR_START(u, v, t, w) ^ b)) = cor;
						//if (b == 0xb7)
							//printf("%f,", log2(abs(* (cora + (COR_START(u, v, t, w) ^ b)))));
					}
				}
			}
		}
	}

}
void SearchOuterMask_Group6(FILE* gptr)
{
	uint32_t Psi[PSISIZE] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0 };
	uint32_t Lambdastar[PSISIZE+1] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0, 0xc17a8fa8 };
	uint8_t Lambda[LASIZE] = { 0x80,0x40,0x20,0x10,0x08,0x04 };

	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1, 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	//std::vector<std::vector<uint32_t> > Psip;
	uint32_t Psip[PSISIZE][96] = { 0 };
	uint32_t Psip_size[PSISIZE] = { 0 };
	for (int n = 0; n < PSISIZE; n++)
	{
		for (auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				Psip[n][Psip_size[n]] = ((a << 24) ^ (Psi[n] & 0x00FFFFFF) ^ b);
				Psip_size[n]++;
			}
	}

	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double) * PSISIZE);

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t U[16] = { 0 };
	uint8_t T[16] = { 0 };

	uint8_t Ph2[PSISIZE][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0} };
	uint8_t La2[PSISIZE+1][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0},{0,0,0x9c,0} };

	std::vector<std::vector<pm> > sba;

	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint32_t i = 0; i < PSISIZE; i++)
		{
			for (uint16_t be = 0; be < LASIZE; be++)
			{
				std::vector<pm> tmp;
				for (uint16_t m = 1; m < 256; m++)
				{
					Lap[0] = (m & 0xFF);
					La[0] = (be & 0xFF);
					pm curpm;
					curpm.c = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2[i]);
					curpm.m = m;
					tmp.push_back(curpm);
				}
				std::sort(tmp.begin(), tmp.end(), cmppm);
				sba.push_back(tmp);
			}
		}
		//--------------------------------------------
#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			//for (int32_t l = 0x08; l < 0x09; l++)
			for (int32_t al = 1; al < 256; al++)//Ga
				//for (int32_t al = 0x0c; al < 0x0d; al++)
				for (int32_t uind = 0; uind < PSISIZE; uind++)//psi
					for (int32_t lind = 0; lind < PSISIZE; lind++)//Lambda*
						for (int32_t e = 0; e < LASIZE; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[0] = (l & 0xFF);
								Ga[0] = (al & 0xFF);

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(Lambdastar[lind], 0);
								T[7] = ExtractLowByte(Lambdastar[lind], 1);
								T[11] = ExtractLowByte(Lambdastar[lind], 2);
								T[15] = ExtractLowByte(Lambdastar[lind], 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value
								bsum = 0;

								for (int32_t b = 1; b < 256; b++)//run over indeterminate
								//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
								{
									//comput cor2
									Ga2[0] = (b & 0xFF);
									double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

									W[3] = (ExtractLowByte(NDBE[b], 0) ^ Lambda[e]);
									W[7] = ExtractLowByte(NDBE[b], 1);
									W[11] = ExtractLowByte(NDBE[b], 2);
									W[15] = ExtractLowByte(NDBE[b], 3);

									std::array<std::array<uint8_t, 8>, 16> z = { 0 };
									SliceFourMask(U, V, W, T, 4, z);
									//Algorithm 2
									double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
									bsum += (cora * cor2);
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 0; m < 256; m++)
								{
									double currentcor = sba[uind*6+e][m].c * bsum * cors;
									if (log2(abs(currentcor)) < -50)
										break;
									else if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(cors)), log2(abs(currentcor)));
										}

									}
								}
							}

#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			for (int32_t al = 1; al < 256; al++)//Ga
				for (int32_t uind = 0; uind < PSISIZE; uind++)//psi
					for (int32_t lind = PSISIZE; lind < PSISIZE+1; lind++)//Lambda*
						for (int32_t e = 0; e < LASIZE; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[2] = (l & 0xFF);
								Ga[2] = (al & 0xFF);

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 0);
								T[7] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 1);
								T[11] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 2);
								T[15] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value
								bsum = 0;
								for (int32_t b = 1; b < 256; b++)//run over indeterminate
								//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
								{
									//comput cor2
									Ga2[2] = (b & 0xFF);
									double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

									W[3] = (ExtractLowByte(LeftRote(NDBE[b], 2), 0) ^ Lambda[e]);
									W[7] = ExtractLowByte(LeftRote(NDBE[b], 2), 1);
									W[11] = ExtractLowByte(LeftRote(NDBE[b], 2), 2);
									W[15] = ExtractLowByte(LeftRote(NDBE[b], 2), 3);

									std::array<std::array<uint8_t, 8>, 16> z = { 0 };
									SliceFourMask(U, V, W, T, 4, z);
									//Algorithm 2
									double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
									bsum += (cora * cor2);
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 1; m < 256; m++)
									//for (uint16_t m = 0x40; m < 0x41; m++)
								{
									double currentcor = sba[uind * 6 + e][m].c * bsum * cors;
									if (log2(abs(currentcor)) < -50)
										break;
									else if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
										//#pragma omp critical
										//										{
										//											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
										//												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										//											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
										//												Gap[0], Ga[0], m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(maxcor1[(uind << 16) + (Lambda[e] << 8) + m])), log2(abs(cors)), log2(abs(currentcor)));
										//										}
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(cors)), log2(abs(currentcor)));
										}

									}

								}
							}


		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group7(FILE* gptr)
{
	uint32_t Psi[PSISIZE] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0 };
	uint32_t Lambdastar[PSISIZE + 1] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0, 0xc17a8fa8 };
	uint8_t Lambda[LASIZE] = { 0x80,0x40,0x20,0x10,0x08,0x04 };

	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1, 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	//std::vector<std::vector<uint32_t> > Psip;
	uint32_t Psip[PSISIZE][96] = { 0 };
	uint32_t Psip_size[PSISIZE] = { 0 };
	for (int n = 0; n < PSISIZE; n++)
	{
		for (auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				Psip[n][Psip_size[n]] = ((a << 24) ^ (Psi[n] & 0x00FFFFFF) ^ b);
				Psip_size[n]++;
			}
	}

	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double* maxcor1 = (double*)malloc((1 << 16) * sizeof(double) * PSISIZE);

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t U[16] = { 0 };
	uint8_t T[16] = { 0 };

	uint8_t Ph2[PSISIZE][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0} };
	uint8_t La2[PSISIZE + 1][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0},{0,0,0x9c,0} };

	std::vector<std::vector<pm> > sba;

	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL && maxcor1 != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint32_t i = 0; i < PSISIZE; i++)
		{
			for (uint16_t be = 0; be < LASIZE; be++)
			{
				std::vector<pm> tmp;
				for (uint16_t m = 1; m < 256; m++)
				{
					Lap[0] = (m & 0xFF);
					La[0] = (Lambda[be] & 0xFF);
					pm curpm;
					curpm.c = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2[i]);
					curpm.m = m;
					tmp.push_back(curpm);
				}
				std::sort(tmp.begin(), tmp.end(), cmppm);
				sba.push_back(tmp);
			}
		}
		//--------------------------------------------
#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			//for (int32_t l = 0x08; l < 0x09; l++)
			for (int32_t al = 1; al < 256; al++)//Ga
				//for (int32_t al = 0x0c; al < 0x0d; al++)
				for (int32_t uind = 0; uind < PSISIZE; uind++)//psi
					for (int32_t lind = 0; lind < PSISIZE; lind++)//Lambda*
						for (int32_t e = 0; e < LASIZE; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[0] = (l & 0xFF);
								Ga[0] = (al & 0xFF);

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(Lambdastar[lind], 0);
								T[7] = ExtractLowByte(Lambdastar[lind], 1);
								T[11] = ExtractLowByte(Lambdastar[lind], 2);
								T[15] = ExtractLowByte(Lambdastar[lind], 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value

								bsum = 0;
								if (cors != 0)
								{
									for (int32_t b = 1; b < 256; b++)//run over indeterminate
									//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
									{
										//comput cor2
										Ga2[0] = (b & 0xFF);
										double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

										W[3] = (ExtractLowByte(NDBE[b], 0) ^ Lambda[e]);
										W[7] = ExtractLowByte(NDBE[b], 1);
										W[11] = ExtractLowByte(NDBE[b], 2);
										W[15] = ExtractLowByte(NDBE[b], 3);

										std::array<std::array<uint8_t, 8>, 16> z = { 0 };
										SliceFourMask(U, V, W, T, 4, z);
										//Algorithm 2
										double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
										bsum += (cora * cor2);
									}
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 0; m < 256; m++)
								{
									double currentcor = sba[uind * 6 + e][m].c * bsum * cors;
									if (log2(abs(currentcor)) < -50)
										break;
									else if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
										}
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
										}

									}
								}
							}

#pragma omp parallel for collapse(5) firstprivate(Gap,Ga,Ga2,W,T,V,U) private(bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			for (int32_t al = 1; al < 256; al++)//Ga
				for (int32_t uind = 0; uind < PSISIZE; uind++)//psi
					for (int32_t lind = PSISIZE; lind < PSISIZE + 1; lind++)//Lambda*
						for (int32_t e = 0; e < LASIZE; e++)
							for (int32_t vind = 0; vind < Psip_size[uind]; vind++)//psi'
							{
								Gap[2] = ((l & 0xFF));
								Ga[2] = ((al & 0xFF));

								//initialize U,V
								U[12] = ExtractLowByte(Psi[uind], 0);
								U[13] = ExtractLowByte(Psi[uind], 1);
								U[14] = ExtractLowByte(Psi[uind], 2);
								U[15] = ExtractLowByte(Psi[uind], 3);

								V[12] = ExtractLowByte(Psip[uind][vind], 0);
								V[13] = ExtractLowByte(Psip[uind][vind], 1);
								V[14] = ExtractLowByte(Psip[uind][vind], 2);
								V[15] = ExtractLowByte(Psip[uind][vind], 3);

								T[3] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 0);
								T[7] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 1);
								T[11] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 2);
								T[15] = ExtractLowByte(LeftRote(Lambdastar[lind], 2), 3);

								double cors = AES_SBOX_LAT[al][La2[uind][0]];//here lat table should be modified to value
								bsum = 0;
								if (cors != 0)
								{
									for (int32_t b = 1; b < 256; b++)//run over indeterminate
									//for (int32_t b = 0xb7; b < 0xb9; b++)//run over indeterminate
									{
										//comput cor2
										Ga2[2] = (b & 0xFF);
										double cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

										W[3] = (ExtractLowByte(LeftRote(NDBE[b], 2), 0) ^ Lambda[e]);
										W[7] = ExtractLowByte(LeftRote(NDBE[b], 2), 1);
										W[11] = ExtractLowByte(LeftRote(NDBE[b], 2), 2);
										W[15] = ExtractLowByte(LeftRote(NDBE[b], 2), 3);

										std::array<std::array<uint8_t, 8>, 16> z = { 0 };
										SliceFourMask(U, V, W, T, 4, z);
										//Algorithm 2
										double cora = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
										bsum += (cora * cor2);
									}
								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 1; m < 256; m++)
								{
									double currentcor = sba[uind * 6 + e][m].c * bsum * cors;
									if (log2(abs(currentcor)) < -50)
										break;
									else if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
										}
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f\n",
												Gap[0], Ga[0], sba[uind * 6 + e][m].m, Lambda[e], Psi[uind], Psip[uind][vind], Lambdastar[lind], log2(abs(sba[uind * 6 + e][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)));
										}

									}

								}
							}


		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		free(maxcor1);
		//free(maxlap);
	}
}
void SearchOuterMask_Group8(FILE* gptr,double *cora)
{
	uint32_t Psi[PSISIZE] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0 };
	uint32_t Lambdastar[PSISIZE + 1] = { 0x81ec5a80,0x411af7c0,0x2161a1e0,0xe1970ca0, 0xc17a8fa8 };
	uint32_t Lambda2[PSISIZE + 1] = { 0xb7,0x6c,0x01,0xda, 0x9c };

	uint8_t Lambda[LASIZE] = { 0x80,0x40,0x20,0x10,0x08,0x04 };

	std::vector<std::vector<uint32_t> > Psip_m = {
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1, 0x89,0x99,0xa9,0xb9,0xc9,0xd9,0xe9,0xf9},
		{0x41,0x61,0x51,0x71,0x49,0x59,0x69,0x79},
		{0x21,0x31,0x29,0x39},
		{0x81,0xc1,0xa1,0xe1,0x91,0xb1,0xd1,0xf1}
	};
	std::vector<std::vector<uint32_t> > Psip_l = {
		{0x80,0x40,0x20,0x10,0x08,0x04},
		{0x40,0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04},
		{0x20,0x10,0x08,0x04}
	};
	//std::vector<std::vector<uint32_t> > Psip;
	uint32_t Psip[PSISIZE][96] = { 0 };
	uint32_t Psip_size[PSISIZE] = { 0 };
	for (int n = 0; n < PSISIZE; n++)
	{
		for (auto a : Psip_m[n])
			for (auto b : Psip_l[n])
			{
				Psip[n][Psip_size[n]] = ((a << 24) ^ (Psi[n] & 0x00FFFFFF) ^ b);
				Psip_size[n]++;
			}
	}

	uint64_t cor48 = 0, cor49 = 0, cor50 = 0;
	double bsum = 0;
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);

	uint8_t Gap[4] = { 0 };
	uint8_t Ga[4] = { 0 };
	uint8_t Ga2[4] = { 0 };
	uint8_t La[4] = { 0 };
	uint8_t Lap[4] = { 0 };

	uint8_t W[16] = { 0 };
	uint8_t V[16] = { 0 };
	uint8_t U[16] = { 0 };
	uint8_t T[16] = { 0 };

	uint8_t Ph2[PSISIZE][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0} };
	uint8_t La2[PSISIZE + 1][4] = { {0xb7,0,0,0},{0x6c,0,0,0},{0x01,0,0,0},{0xda,0,0,0},{0,0,0x9c,0} };

	std::vector<std::vector<pm> > sba;

	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		//1---------------------------------------------
		for (uint32_t i = 0; i < PSISIZE; i++)
		{
			for (uint16_t be = 0; be < LASIZE; be++)
			{
				std::vector<pm> tmp;
				for (uint16_t m = 1; m < 256; m++)
				{
					Lap[0] = (m & 0xFF);
					La[0] = (Lambda[be] & 0xFF);
					pm curpm;
					curpm.c = EvaluateSboxAdditionCorrelation(AS, La, Lap, Ph2[i]);
					curpm.m = m;
					tmp.push_back(curpm);
				}
				std::sort(tmp.begin(), tmp.end(), cmppm);
				sba.push_back(tmp);
			}
		}
		//--------------------------------------------
#pragma omp parallel for collapse(5) private(Gap,Ga,Ga2,bsum) reduction(+:cor48,cor49,cor50)
		for (int32_t l = 1; l < 256; l++)//Ga'
			//for (int32_t l = 0x08; l < 0x09; l++)
			for (int32_t al = 1; al < 256; al++)//Ga
				//for (int32_t al = 0x0c; al < 0x0d; al++)
				for (int32_t u = 0; u < PSISIZE; u++)//psi
					for (int32_t t = 0; t < PSISIZE+1; t++)//Lambda*
						for (int32_t w = 0; w < LASIZE; w++)//lambda
							for (int32_t v = 0; v < Psip_size[u]; v++)//psi'
							{
								Gap[0] = Gap[1] = Gap[2] = Gap[3] = 0;
								Ga[0] = Ga[1] = Ga[2] = Ga[3] = 0;
								Ga2[0] = Ga2[1] = Ga2[2] = Ga2[3] = 0;

								double cors = AES_SBOX_LAT[al][La2[u][0]];//here lat table should be modified to value

								if (t < PSISIZE)
								{
									Gap[0] = (l & 0xFF);
									Ga[0] = (al & 0xFF);
								}
								else
								{
									Gap[2] = (l & 0xFF);
									Ga[2] = (al & 0xFF);
								}

								bsum = 0;
								double delta = 0;
								double cor2 = 0;
								if (cors != 0)
								{
									for (int32_t b = 1; b < 256; b++)//run over indeterminate
									//for (int32_t b = 0xb7; b < 0xb8; b++)//run over indeterminate
									{
										if (t < PSISIZE)
										{
											Ga2[0] = (b & 0xFF);
										}
										else
										{
											Ga2[2] = (b & 0xFF);
										}
										cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);

										bsum += (*(cora + (COR_START(u, v, t, w) ^ b)) * cor2);
										//printf("%f,", log2(abs(*(cora + (COR_START(u, v, t, w) ^ b)))));
									}
									if (t < PSISIZE)
									{
										Ga2[0] = (Lambda2[t] & 0xFF);
									}
									else
									{
										Ga2[2] = (Lambda2[t] & 0xFF);
									}
									cor2 = EvaluateSboxAdditionCorrelation(AS, Ga, Gap, Ga2);
									delta = bsum - (*(cora + (COR_START(u, v, t, w) ^ Lambda2[t]))) * cor2;

								}
								//printf("(bsum:%f,cors:%f)\n", log2(abs(bsum)), log2(abs(cors)));

								for (uint16_t m = 0; m < 256; m++)
								{
									double currentcor = sba[u * 6 + w][m].c * bsum * cors;
									if (log2(abs(currentcor)) < -50)
										break;
									else if (log2(abs(currentcor)) > -50 && log2(abs(currentcor)) < -49)
									{
										cor50++;
									}
									else if (log2(abs(currentcor)) > -49 && log2(abs(currentcor)) < -48)
									{
										cor49++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f,delta:%f\n",
												Gap[0], Ga[0], sba[u * 6 + w][m].m, Lambda[w], Psi[u], Psip[u][v], Lambdastar[t], log2(abs(sba[u * 6 + w][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)),log2(abs(delta)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f,delta:%f\n",
												Gap[0], Ga[0], sba[u * 6 + w][m].m, Lambda[w], Psi[u], Psip[u][v], Lambdastar[t], log2(abs(sba[u * 6 + w][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)), log2(abs(delta)));
										}
									}
									else if (log2(abs(currentcor)) > -48)
									{
										cor48++;
#pragma omp critical
										{
											fprintf(gptr, "Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f,delta:%f\n",
												Gap[0], Ga[0], sba[u * 6 + w][m].m, Lambda[w], Psi[u], Psip[u][v], Lambdastar[t], log2(abs(sba[u * 6 + w][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)), log2(abs(delta)));
											printf("Gap[12]:0x%2.2x,Ga[12]:0x%2.2x,Lap[12]:0x%2.2x,La[12]:0x%2.2x,U[12~15]:0x%8.8x,V[12~15]:0x%8.8x,T[12~15]:0x%8.8x,Cor1:%f,bsum:%f,Cors:%f,Cor:%f,delta:%f\n",
												Gap[0], Ga[0], sba[u * 6 + w][m].m, Lambda[w], Psi[u], Psip[u][v], Lambdastar[t], log2(abs(sba[u * 6 + w][m].c)), log2(abs(bsum)), log2(abs(cors)), log2(abs(currentcor)), log2(abs(delta)));
										}

									}
								}
							}


		fprintf(gptr, "cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);
		printf("cor48:%lld,cor49:%lld,cor50:%lld\n", cor48, cor49, cor50);

		fclose(fptr);
		_mm_free(AS);
		//free(maxlap);
	}
}


void GenerateRandomMask(FILE* sptr,uint8_t len)
{
	double* cor = (double*)malloc(SAMPLE_CAP * sizeof(double));
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double mean = 0;
	double variance = 0;
	srand((uint32_t)time(NULL));
	uint8_t aeskey[16 * 11] = { 0 };
	for (int i = 0; i < 16 * 11; i++)
	{
		aeskey[i] = rand() & 0xFF;
	}
	__m128i key;
	uint8_t mask[16] = { 0 };
	uint8_t u[4] = { 0 };
	uint8_t x[4] = { 0 };
	uint8_t y[4] = { 0 };
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");

	uint32_t ictr = 0;
	if (fptr != NULL && AS != NULL && cor != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		for (uint64_t ctr = 0; ctr < SAMPLE_CAP; ctr++)
		{
			__m128i txt = _mm_set1_epi64x(ctr);
			for (uint8_t i = 0; i < 10; i++)
			{
				key = _mm_loadu_si128((const __m128i*)(aeskey + (i << 4)));
				txt = _mm_aesenc_si128(txt, key);
			}
			_mm_storeu_epi8(mask, txt);

			switch (len)
			{
			case 1:
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				cor[ctr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
				//ictr++;
				//printf("%.24llf,", cor[ctr]);
			case 2:
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				cor[ctr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
			case 3:
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				u[2] = mask[2];
				x[2] = mask[7];
				y[2] = mask[10];
				cor[ctr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
			case 4:
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				u[2] = mask[2];
				x[2] = mask[6];
				y[2] = mask[10];
				u[3] = mask[3];
				x[3] = mask[7];
				y[3] = mask[11];
				cor[ctr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
			}
			mean += cor[ctr];
		}
		//printf("%d", ictr);
		//compute mean
		mean /= SAMPLE_CAP;
		for (uint64_t ctr = 0; ctr < SAMPLE_CAP; ctr++)
		{
			variance += ((cor[ctr] - mean) * (cor[ctr] - mean));
		}
		variance /= SAMPLE_CAP;

		//write to file
		for (uint64_t ctr = 0; ctr < SAMPLE_CAP; ctr++)
		{
			fprintf(sptr, "%.32llf ", cor[ctr]);
		}
		printf("mu=%.32llf;\nsigma=sqrt(%.32llf);\n", mean, variance);
		_mm_free(AS);
		free(cor);
		fclose(fptr);
	}
}
void GenerateRandomMask_Suffix(FILE* sptr, uint8_t len)
{
	double* cor = (double*)malloc(SAMPLE_CAP * sizeof(double));
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	double mean = 0;
	double variance = 0;
	srand((uint32_t)time(NULL));
	uint8_t aeskey[16 * 11] = { 0 };
	for (int i = 0; i < 16 * 11; i++)
	{
		aeskey[i] = rand() & 0xFF;
	}
	__m128i key;
	uint8_t mask[16] = { 0 };
	uint8_t u[4] = { 0 };
	uint8_t x[4] = { 0 };
	uint8_t y[4] = { 0 };
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");

	uint32_t ictr = 0;
	uint64_t ctr = 0;
	if (fptr != NULL && AS != NULL && cor != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		while(ictr < SAMPLE_CAP)
		{
			__m128i txt = _mm_set1_epi64x(ctr);
			for (uint8_t i = 0; i < 10; i++)
			{
				key = _mm_loadu_si128((const __m128i*)(aeskey + (i << 4)));
				txt = _mm_aesenc_si128(txt, key);
			}
			_mm_storeu_epi8(mask, txt);

			if (len == 1)
			{
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				if (SameSuffixCondition(u, x, y, 1) == true)
				{
					cor[ictr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
					mean += cor[ictr];
					ictr++;
				}
			}
			else if (len == 2)
			{
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				if (SameSuffixCondition(u, x, y, 2) == true)
				{
					cor[ictr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
					mean += cor[ictr];
					ictr++;
				}
			}
			else if (len == 3)
			{
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				u[2] = mask[2];
				x[2] = mask[7];
				y[2] = mask[10];
				if (SameSuffixCondition(u, x, y, 3) == true)
				{
					cor[ictr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
					mean += cor[ictr];
					ictr++;
				}
			}
			else if (len == 4)
			{
				u[0] = mask[0];
				x[0] = mask[4];
				y[0] = mask[8];
				u[1] = mask[1];
				x[1] = mask[5];
				y[1] = mask[9];
				u[2] = mask[2];
				x[2] = mask[6];
				y[2] = mask[10];
				u[3] = mask[3];
				x[3] = mask[7];
				y[3] = mask[11];
				if (SameSuffixCondition(u, x, y, 4) == true)
				{
					cor[ictr] = EvaluateSboxAdditionCorrelation(AS, u, x, y);
					mean += cor[ictr];
					ictr++;
				}
			}
			ctr++;
		}
		printf("%d", ictr);
		//compute mean
		mean /= SAMPLE_CAP;
		for (uint64_t ctr = 0; ctr < SAMPLE_CAP; ctr++)
		{
			variance += ((cor[ctr] - mean) * (cor[ctr] - mean));
		}
		variance /= SAMPLE_CAP;

		//write to file
		for (uint64_t ctr = 0; ctr < SAMPLE_CAP; ctr++)
		{
			fprintf(sptr, "%.32llf ", cor[ctr]);
		}
		printf("mu=%.32llf;\nsigma=sqrt(%.32llf);\n", mean, variance);
		_mm_free(AS);
		free(cor);
		fclose(fptr);
	}
}

//statistic for algorithm
bool PearsonKSqurareInference(std::ifstream& infile, double* cdp,double left, double right ,double width)
{
	//
	double p[CANS] = { 0 };
	double frq[CANS] = { 0 };
	for (int i = 0; i < CANS; i++)
	{
		p[i] = cdp[i + 1] - cdp[i];
	}
	bool normal = true;
	double ks = 0;
	std::string data;
	std::vector<double> cor;
	while (std::getline(infile, data))
	{
		std::stringstream ss(data);
		double c = 0;
		while (ss >> c)
			cor.push_back(c);
	}

	for (double e : cor)
	{
		if (e < left)
			frq[0]++;//<left
		else if (e > right)
			frq[CANS-1]++;
		else
		{
			int ind = floor((e - left)/((double)width));
			frq[ind + 1]++;
		}
	}
	for (int i = 0; i < CANS; i++)
	{
		printf("%d:%llf,%llf\n",i, frq[i], SAMPLE_CAP * p[i]);
	}
	for (int i = 0; i < CANS; i++)
	{
		ks += ((frq[i] - SAMPLE_CAP * p[i]) * (frq[i] - SAMPLE_CAP * p[i]) / (SAMPLE_CAP * p[i]));
	}
	if (ks > 42.557)
		normal = false;
	return normal;
}
