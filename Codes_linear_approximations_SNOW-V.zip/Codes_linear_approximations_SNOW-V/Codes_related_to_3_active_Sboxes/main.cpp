#include<stdio.h>
#include<array>
#include<vector>
#include<math.h>
#include<inttypes.h>
#include<set>
#include<math.h>
#include<algorithm>
#include"improve.h"

//#define Position(u,wx,wy) (((int32_t)(u)<<18)^((int32_t)(wx)<<10)^((int32_t)(wy)<<2))


int main()
{
	/*
	printf("%f\n", log2(0.2 * 0.13 * 0.13*0.13*0.13));
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		double m[4] = { 0 };
		//0 and 1 column sum
		uint32_t ctr = 0;
		for (int i = 0; i < 256; i++)
			for (int j = 0; j < 256; j++)
				for (int k = 0; k < 256; k++)
				{
					if (ByteSameSuffixCondition(i, j, k) == true)
					//if (i!=0 || j!=0 || k!=0)
					{
						m[0] = *(AS + Position(i, j, k));
						m[2] = *(AS + Position(i, j, k) + 1);
						m[1] = *(AS + Position(i, j, k) + 2);
						m[3] = *(AS + Position(i, j, k) + 3);

						double cor[2] = { 0 };
						cor[0] = m[0] - m[2];//(1,-1)
						cor[1] = m[1] - m[3];
						if (cor[0]+cor[1]==0)
						//if((cor[0] == cor[1]) && cor[0]!=0)
						//if(std::max(abs(m[0]),abs(m[1]))>0.07)
						//if(m[0]+m[1]>0.1 || m[2]+m[3]>0.1)
						{
							//if(abs(m[2] + m[3])>0.095)
							//if(abs(cor[0] + cor[1]) > 0.190)
								//printf("u:%2.2x,x:%2.2x,y:%2.2x,%f,%f\n", i, j, k, cor[0] + cor[1],m[2]+m[3]);
							//printf("u:%2.2x,x:%2.2x,y:%2.2x,%f,%f\n", i, j, k, cor[0]+cor[1],cor[0]);
							//printf("u:%2.2x,x:%2.2x,y:%2.2x,%f,%f\n", i, j, k, m[1] + m[3], m[0] + m[2]);
							//printf("u:%2.2x,x:%2.2x,y:%2.2x\n", i, j, k);
							//printf("u:%2.2x,x:%2.2x,y:%2.2x,%f,%f\n", i, j, k, m[0] + m[1], m[2] + m[3]);

							ctr++;

							//printf("u:%2.2x,x:%2.2x,y:%2.2x\n", i, j, k);
							//printf("%.8llf, %.8llf\n", m[0], m[2]);
							//printf("%.8llf, %.8llf\n", m[1], m[3]);
							//printf("+:%.8llf, %.8llf\n", m[2] + m[0], m[1] + m[3]);
							//printf("-:%.8llf, %.8llf\n", cor[0], cor[1]);

							//printf("\n");
						}
						else
						{
							continue;
							//printf("u:%2.2x,x:%2.2x,y:%2.2x\n", i, j, k);
							//printf("%.8llf, %.8llf\n", m[0], m[2]);
							//printf("%.8llf, %.8llf\n", m[1], m[3]);
							//printf("+:%.8llf, %.8llf\n", m[2] + m[0], m[1] + m[3]);
							//printf("-:%.8llf, %.8llf\n", cor[0], cor[1]);

							//printf("\n");
						}
					}
				}
		printf("%d,%f", ctr, log2(ctr));

		_mm_free(AS);
		fclose(fptr);
	}
	*/
	/*
	FILE* gptr = fopen("sigmaaddition_improvesnowv_0011.txt", "w");
	if (gptr != NULL)
	{
		SigmaAdditionBinaryApproximation_0011(gptr);
		fclose(gptr);
	}
	*/
	/*
	FILE* ofs = fopen("improvesigmaaddition.txt", "w");
	if (ofs != NULL)
	{
		SigmaAdditionNewtrails(ofs);	
		fclose(ofs);
	}
	*/
	/*
	FILE* gptr = fopen("sigmaaddition_improvesnowv_0001.txt", "w");
	if (gptr != NULL)
	{
		SearchSigmaAddition(gptr);
		fclose(gptr);
	}
	*/

	/*
	FILE* gptr = fopen("sigmaaddition_improvesnowv_0001_searchlambda2.txt", "w");
	if (gptr != NULL)
	{
		SearchSigmaAddition3(gptr);
		fclose(gptr);
	}
	*/
	/*
	uint8_t a[2] = { 0xb7,0x40 };
	uint8_t b[2] = { 0xb7,0xb7 };
	double maxc12 = 0;
	maxc12=SearchSboxAddition(a, b);
	printf("max12+sigam:%f\n", maxc12 - 35.585);
	*/
	/*	
	FILE* gptr = fopen("OuterCorrelation_0001_1.txt", "w");
	uint8_t U_1[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0x80,0x5a,0xec,0x81 };
	uint8_t T_1[16] = { 0,0,0,0x80,0,0,0,0x5a,0,0,0,0xec,0,0,0,0x81 };
	uint8_t Ph2_1[4] = { 0xb7,0,0,0 };
	uint8_t La2_1[4] = { 0xb7,0,0,0 };
	if (gptr != NULL)
	{
		SearchOuterMask_Group1(gptr, U_1, T_1, Ph2_1, La2_1);
		fclose(gptr);
	}

	gptr = fopen("OuterCorrelation_0001_2.txt", "w");
	uint8_t U_2[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0xc0,0xf7,0x1a,0x41 };
	uint8_t T_2[16] = { 0,0,0,0xc0,0,0,0,0xf7,0,0,0,0x1a,0,0,0,0x41 };
	uint8_t Ph2_2[4] = { 0x6c,0,0,0 };
	uint8_t La2_2[4] = { 0x6c,0,0,0 };
	if (gptr != NULL)
	{
		SearchOuterMask_Group2(gptr, U_2, T_2, Ph2_2, La2_2);
		fclose(gptr);
	}

	gptr = fopen("OuterCorrelation_0001_3.txt", "w");
	uint8_t U_3[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0xe0,0xa1,0x61,0x21 };
	uint8_t T_3[16] = { 0,0,0,0xe0,0,0,0,0xa1,0,0,0,0x61,0,0,0,0x21 };
	uint8_t Ph2_3[4] = { 0x01,0,0,0 };
	uint8_t La2_3[4] = { 0x01,0,0,0 };
	if (gptr != NULL)
	{
		SearchOuterMask_Group3(gptr, U_3, T_3, Ph2_3, La2_3);
		fclose(gptr);
	}
	*/
	//mix
	/*
	FILE * gptr = fopen("OuterCorrelation_0001_4.txt", "w");
	if (gptr != NULL)
	{
		SearchOuterMask_Group4(gptr);
		fclose(gptr);
	}
	*/
	
	//double* precora = (double*)malloc((1 << 23) * sizeof(double));
	//FILE* fptr = fopen("Precompute_cora.dat", "wb");
	//if (fptr != NULL && precora != NULL)
	//{
	//	Precompute(precora);
	//	printf("pre complete\n");
	//	fwrite(precora, sizeof(double), (1 << 23), fptr);
	//	fclose(fptr);
	//	free(precora);
	//}
	//
	
	double* loadprecora = (double*)malloc((1 << 23) * sizeof(double));
	FILE* hptr = fopen("Precompute_cora.dat", "rb");
	FILE * gptr = fopen("OuterCorrelation_0001_8.txt", "w");
	if (hptr != NULL && gptr != NULL && loadprecora !=NULL)
	{
		fread(loadprecora, sizeof(double), 1 << 23, hptr);
		SearchOuterMask_Group8(gptr,loadprecora);
		fclose(gptr);
		fclose(hptr);
		free(loadprecora);
	}
	
	/*
	FILE * sptr = fopen("randomcorrelation.txt", "w");
	if (sptr != NULL)
	{
		GenerateRandomMask_Suffix(sptr,1);
		fclose(sptr);
	}
		
	//CANS=29

	double cdp[CANS + 1] = { 0,
0.000890460008202486, 0.00202767812558512, 0.00435641351848881, 0.00883601898780799, 0.0169307645972545, 0.0306715316265455, 0.0525825995468740, 0.0854043185339549, 0.131589714098084, 0.192640868896286, 0.268451344019437, 0.356883633158187, 0.453787022479680, 0.553537182461496, 0.649994414223266, 0.737614266410877, 0.812382424442364, 0.872316960521454, 0.917448870969272, 0.949374255557389, 0.970588819043272, 0.983831540456386, 0.991596964043427, 0.995874536302198, 0.998088004745184, 0.999163955809637
,1
	};
	double left = -0.0125;
	double right = 0.0125;
	double width = 0.001;
	std::ifstream infile("randomcorrelation.txt", std::ios::in);
	bool flag = true;
	if (infile.is_open())
	{
		flag=PearsonKSqurareInference(infile, cdp,left,right,width);
		printf("Normal is %d\n", flag);
		infile.close();
	}
	*/
	return 0;
}