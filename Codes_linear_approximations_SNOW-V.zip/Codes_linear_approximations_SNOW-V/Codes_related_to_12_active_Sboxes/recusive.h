#pragma once
#include<set>
#include<inttypes.h>
#include<math.h>
#include<vector>
#include<array>
#include<algorithm>
#include<iterator>
#include<math.h>
#include<omp.h>
#include<immintrin.h>
#include<string>
#include<memory>
#define MEM_SIZE ((1<<24)*2)
#define WORD_SIZE_RECUR 32
#define ExtractByte(y,i) (((y)>>((3-(i))<<3))&0xFF)

//These functions are related to recusively generate mask for modulo 2^n addition by Nyberg's method

//generate SBox Walsh spectral
//k: correlation exponents +-2^k,k!=0; n: length of mask; ind:type of transition 0:e0->e0,1:e0->e1
//w: all masks of correlation +-2^k
void GenerateTwoInputsLinearMasks_Binary(int8_t n, int8_t k, int8_t ind, std::vector<std::vector<uint8_t> >& w)
{
	if (ind == 0)
	{
		if (k < 0 || k >= n)
			w.clear();
		else if (n == 1 && k == 0)
			w.push_back(std::vector<uint8_t>(1, 0));
		else
		{
			std::vector<std::vector<uint8_t> > wt0, wt1;
			GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, wt0);
			GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, wt1);
			for (auto e : wt0)
			{
				w.push_back(e);
				(w.back()).push_back(0);
			}
			for (auto e : wt1)
			{
				w.push_back(e);
				(w.back()).push_back(1);
				w.push_back(e);
				(w.back()).push_back(2);
				w.push_back(e);
				(w.back()).push_back(4);
				w.push_back(e);
				(w.back()).push_back(7);
			}
		}
	}
	else
	{
		if (k < 0 || k >= n)
			w.clear();
		else if (n == 1 && k == 0)
			w.push_back(std::vector<uint8_t>(1, 7));
		else
		{
			std::vector<std::vector<uint8_t> > wt0, wt1, wt2;
			GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, wt0);
			GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, wt1);
			for (auto e : wt0)
			{
				w.push_back(e);
				(w.back()).push_back(7);
			}
			for (auto e : wt1)
			{
				w.push_back(e);
				(w.back()).push_back(0);
				w.push_back(e);
				(w.back()).push_back(3);
				w.push_back(e);
				(w.back()).push_back(5);
				w.push_back(e);
				(w.back()).push_back(6);
			}
		}
	}
}
//k: correlation exponents +-2^k,k!=0; n: length of mask; ind:type of transition 0:e0->e0,1:e0->e1
//w: all masks of correlation +-2^k with one or two masks be fixed
//fixmask: one or two fixed masks of {u*Z=wa*Y+wb*z}, if one mask is not fixed set it 0;
void GenerateTwoInputsLinearMasks_Binary(int8_t n, int8_t k, int8_t ind, std::vector<bool> fix, std::vector<uint32_t> fixmsk, std::vector<std::vector<uint8_t> >& w)
{
	if (ind == 0)
	{
		if (k < 0 || k >= n)
			w.clear();
		else if (n == 1 && k == 0)
			w.push_back(std::vector<uint8_t>(1, 0));
		else
		{
			//shieve the possible msk
			std::set<uint32_t> S0 = { 0 };
			std::vector<std::set<uint32_t> > S1 = { {1,2},{4,7},{1,4},{2,7},{2,4},{1,7} };
			std::set<uint32_t> S1_avaliable = { 1,2,4,7 };
			std::set<uint32_t> T;
			uint8_t bi = 0;
			for (uint8_t i = 0; i < 3; i++)
			{
				if (fix[i] != 0)
				{
					bi = (fixmsk[i] & 0x1);
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S1[(i << 1) + bi].begin(), S1[(i << 1) + bi].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
					if (bi != 0)
						S0.clear();
				}
			}

			std::vector<std::vector<uint8_t> > wt0, wt1;
			std::vector<uint32_t> nextmsk;
			for (auto e : fixmsk)
				nextmsk.push_back(e >> 1);
			if (!S0.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, fix, nextmsk, wt0);
				for (auto e : wt0)
				{
					for (auto s : S0)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
			if (!S1_avaliable.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, fix, nextmsk, wt1);
				for (auto e : wt1)
				{
					for (auto s : S1_avaliable)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
		}
	}
	else
	{
		if (k < 0 || k >= n)
			w.clear();
		else if (n == 1 && k == 0)
			w.push_back(std::vector<uint8_t>(1, 7));
		else
		{
			//shieve the possible msk
			std::set<uint32_t> S0 = { 7 };
			std::vector<std::set<uint32_t> > S1 = { {0,3},{5,6},{0,5},{3,6},{0,6},{3,5} };
			std::set<uint32_t> S1_avaliable = { 0,3,5,6 };
			std::set<uint32_t> T;
			uint8_t bi = 0;
			for (uint8_t i = 0; i < 3; i++)
			{
				if (fix[i] != 0)
				{
					bi = (fixmsk[i] & 0x1);
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S1[(i << 1) + bi].begin(), S1[(i << 1) + bi].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
					if (bi != 1)
						S0.clear();
				}
			}

			std::vector<std::vector<uint8_t> > wt0, wt1;
			std::vector<uint32_t> nextmsk;
			for (auto e : fixmsk)
				nextmsk.push_back(e >> 1);
			if (!S0.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, fix, nextmsk, wt0);
				for (auto e : wt0)
				{
					for (auto s : S0)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
			if (!S1_avaliable.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, fix, nextmsk, wt1);
				for (auto e : wt1)
				{
					for (auto s : S1_avaliable)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
		}
	}
}
//usually, when one mask is fixed, its mode is already is fixed, 
//for the mask not fixed, a binary word to restrict its form can be given
//if not given(==0), then this mask is free for all possible mode
//a mode defines which cell is restrict to 0, or free. eg. 0xFF00 mean the first byte should be 0,
//and the second arbitary
void GenerateTwoInputsLinearMasks_Binary(int8_t n, int8_t k, int8_t ind, std::vector<bool> fix, std::vector<uint32_t> fixmsk, std::vector<uint32_t> mode, std::vector<std::vector<uint8_t> >& w)
{
	printf("(%d,%d,%d)", n,k,ind);
	if (ind == 0)
	{
		if (k < 0 || k >= n)//empty
			w.clear();
		else if (n == 1 && k == 0)//S^0(1,0)=0
			w.push_back(std::vector<uint8_t>(1, 0));
		else
		{
			//shieve the possible msk
			std::set<uint32_t> S0 = { 0 };
			std::vector<std::set<uint32_t> > S1 = { {1,2},{4,7},{1,4},{2,7},{2,4},{1,7} };
			std::vector<std::set<uint32_t> > S2 = { {1,2},{1,2,4,7},{1,4},{1,2,4,7},{2,4},{1,2,4,7} };
			std::set<uint32_t> S1_avaliable = { 1,2,4,7 };
			std::set<uint32_t> T;
			uint8_t bi = 0, bj = 0;
			for (uint8_t i = 0; i < 3; i++)
			{
				if (fix[i] != 0)//i-th mask fixed
				{
					bi = (fixmsk[i] & 0x1);//lsb
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S1[(i << 1) + bi].begin(), S1[(i << 1) + bi].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
					if (bi != 0)
						S0.clear();
				}
				else
				{
					//deal with mode here
					bj = (mode[i] & 0x01);//0-0,1-0/1
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S2[(i << 1) + bj].begin(), S2[(i << 1) + bj].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
				}
			}

			std::vector<std::vector<uint8_t> > wt0, wt1;
			std::vector<uint32_t> nextmsk;
			std::vector<uint32_t> nextmode;
			for (auto e : fixmsk)
				nextmsk.push_back(e >> 1);
			for (auto e : mode)
				nextmode.push_back(e >> 1);
			if (!S0.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, fix, nextmsk, nextmode, wt0);
				for (auto e : wt0)
				{
					for (auto s : S0)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
			if (!S1_avaliable.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, fix, nextmsk, nextmode, wt1);
				for (auto e : wt1)
				{
					for (auto s : S1_avaliable)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}

			}
			//print to check
			for (auto e : w)
			{
				for (auto x : e)
					printf("%d,", x);
				printf("\n");
			}
		}
	}
	else
	{
		if (k < 0 || k >= n)//empty
			w.clear();
		else if (n == 1 && k == 0)//S^1(1,0)=7
		{
			w.push_back(std::vector<uint8_t>(1, 7));
			printf("triger 7 at: (%d,%d,%d)", n, k, ind);

		}
		else
		{
			//shieve the possible msk
			std::set<uint32_t> S0 = { 7 };
			std::vector<std::set<uint32_t> > S1 = { {0,3},{5,6},{0,5},{3,6},{0,6},{3,5} };
			std::vector<std::set<uint32_t> > S2 = { {0,3},{0,3,5,6},{0,5},{0,3,5,6},{0,6},{0,3,5,6} };
			std::set<uint32_t> S1_avaliable = { 0,3,5,6 };
			std::set<uint32_t> T;
			uint8_t bi = 0, bj = 0;
			for (uint8_t i = 0; i < 3; i++)
			{
				if (fix[i] != 0)
				{
					bi = (fixmsk[i] & 0x1);
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S1[(i << 1) + bi].begin(), S1[(i << 1) + bi].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
					if (bi == 0)
						S0.clear();
				}
				else
				{
					//deal with mode here
					bj = (mode[i] & 0x01);
					std::set_intersection(S1_avaliable.begin(), S1_avaliable.end(), S2[(i << 1) + bj].begin(), S2[(i << 1) + bj].end(), std::inserter(T, T.begin()));
					S1_avaliable = T;
					T.clear();
					if (bj == 0)
						S0.clear();
				}
			}

			std::vector<std::vector<uint8_t> > wt0, wt1;
			std::vector<uint32_t> nextmsk;
			std::vector<uint32_t> nextmode;

			for (auto e : fixmsk)
				nextmsk.push_back(e >> 1);
			for (auto e : mode)
				nextmode.push_back(e >> 1);
			if (!S0.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k, 0, fix, nextmsk, nextmode, wt0);
				for (auto e : wt0)
				{
					for (auto s : S0)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
			if (!S1_avaliable.empty())
			{
				GenerateTwoInputsLinearMasks_Binary(n - 1, k - 1, 1, fix, nextmsk, nextmode, wt1);
				for (auto e : wt1)
				{
					for (auto s : S1_avaliable)
					{
						w.push_back(e);
						(w.back()).push_back(s);
					}
				}
			}
			//print to check
			for (auto e : w)
			{
				for (auto x : e)
					printf("%d,", x);
				printf("\n");
			}
		}
	}
}
//biparition search: assuming data is in order
inline bool BiSearch(uint32_t x, uint32_t *data, int32_t datasize)
{
	int32_t p = 0, r = (datasize - 1), q = 0;
	//printf("%d,%d,", r, datasize);
	while (p <= r)
	{
		q = ((p + r) >> 1);
		if (data[q] == x)
			return true;
		else if (data[q] > x)
		{
			r = q - 1;
		}
		else if (data[q] < x)
		{
			p = q + 1;
		}
	}
	return false;
}
//modified for searching
//S^-1(y)+x=z
//u*z~wy*y+wx*x
//fix: indeterminate mask wyprime
//wyp_fix 31...0 msb->lsb
//u||wy||wx
//maskpair:(u,wx)
void GenerateTwoInputsLinearMasks_Binary_1(int8_t n, int8_t k, uint8_t wyp_fix[32], uint8_t wz[4],int32_t zmaxpointsize[4], std::vector<uint64_t>& maskpair);

void GenerateTwoInputsLinearMasks_Binary_0(int8_t n, int8_t k,uint8_t wyp_fix[32], uint8_t wz[4], int32_t zmaxpointsize[4], std::vector<uint64_t> &maskpair)
{
	//printf("(%d,%d,0)", n, k);
	if (k < 0 || k >= n)//empty
		maskpair.clear();
	else if (n == 1 && k == 0)//S^0(1,0)=0
	{
		if (wyp_fix[WORD_SIZE_RECUR - n] == 0)
		{
			maskpair.push_back(0);//wz[31]||wx[31]
			//printf("triger ini 0 (%d,%d,0)", n, k);
		}
		else
			maskpair.clear();
	}
	else
	{
		std::vector<uint64_t> S0, S1;
		if (wyp_fix[WORD_SIZE_RECUR - n] == 0)
		{
			GenerateTwoInputsLinearMasks_Binary_0(n - 1, k, wyp_fix, wz,zmaxpointsize, S0);
			GenerateTwoInputsLinearMasks_Binary_1(n - 1, k-1, wyp_fix, wz,zmaxpointsize, S1);

			//first push all possible 
			for (uint64_t e : S0)
			{
				maskpair.push_back((e << 1));
				//printf("triger S0 0 (%d,%d,0)", n, k);
			}
			for (uint32_t i = 0; i < S1.size(); i++)
			{
				//push 001:1
				maskpair.push_back((S1[i] << 1)^1);
				//printf("triger S1 1 (%d,%d,0)", n, k);
				//push 100:4
				maskpair.push_back((S1[i] << 1) ^ 0x100000000);//push 1
				//printf("triger S1 4 (%d,%d,0)", n, k);

			}
			//for (uint64_t e : maskpair)
			//	printf("%16.16llx,", e);
			//printf("\n");
			// shieve from u mode
			if ((n & 7) == 0 && maskpair.empty()==false)
			{
				while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
				{
					maskpair.pop_back();
					//printf("pop\n");
					if (maskpair.empty() == true)
						break;
				}
				if (maskpair.empty() == false)
				{
					std::vector<uint64_t>::iterator l = maskpair.begin();
					while (l != maskpair.end())
					{
						if (BiSearch(ExtractByte((uint32_t)((*l) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
						{
							*l = *(maskpair.end() - 1);
							maskpair.pop_back();
							//printf("pop\n");
							while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
								maskpair.pop_back();
							l++;
						}
						else
							l++;
					}
				}
			}
			S0.clear();
			S1.clear();
		}
		else
		{
			GenerateTwoInputsLinearMasks_Binary_1(n - 1, k - 1, wyp_fix, wz, zmaxpointsize, S1);
			for (uint32_t i = 0; i < S1.size(); i++)
			{
				//push 010:2
				maskpair.push_back((S1[i] << 1));
				//printf("triger S1 2 (%d,%d,0)", n, k);

				//push 111:7
				maskpair.push_back((S1[i] << 1) ^ 0x100000001);
				//printf("triger S1 7 (%d,%d,0)", n, k);
			}
			//for (uint64_t e : maskpair)
			//	printf("%16.16llx,", e);
			//printf("\n");
			// shieve from u mode
			if ((n & 7) == 0 && maskpair.empty() == false)
			{
				while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
				{
					maskpair.pop_back();
					//printf("pop\n");
					if (maskpair.empty() == true)
						break;
				}
				if (maskpair.empty() == false)
				{
					std::vector<uint64_t>::iterator l = maskpair.begin();
					while (l != maskpair.end())
					{
						if (BiSearch(ExtractByte((uint32_t)((*l) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
						{
							*l = *(maskpair.end() - 1);
							maskpair.pop_back();
							//printf("pop\n");
							while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
								maskpair.pop_back();
							l++;
						}
						else
							l++;
					}
				}
			}
			S0.clear();
			S1.clear();
		}
	}

}
//wyp_fix 31~0 msb~lsb
//lsb in the high level
//msb in the deep level
void GenerateTwoInputsLinearMasks_Binary_1(int8_t n, int8_t k, uint8_t wyp_fix[32], uint8_t wz[4], int32_t zmaxpointsize[4], std::vector<uint64_t>& maskpair)
{
	//printf("(%d,%d,1)", n, k);
	if (k < 0 || k >= n)//empty
		maskpair.clear();
	else if (n == 1 && k == 0)//S^0(1,0)=7 deepest level
	{
		if (wyp_fix[WORD_SIZE_RECUR - n] == 1)
		{
			maskpair.push_back(0x100000001);//wz[31]||wx[31]
			//printf("triger ini 7(%d,%d,0)", n, k);

		}
		else
			maskpair.clear();
	}
	else
	{
		std::vector<uint64_t> S0, S1;
		if (wyp_fix[WORD_SIZE_RECUR-n] == 1)
		{
			GenerateTwoInputsLinearMasks_Binary_0(n - 1, k, wyp_fix, wz, zmaxpointsize, S0);
			GenerateTwoInputsLinearMasks_Binary_1(n - 1, k - 1, wyp_fix, wz, zmaxpointsize, S1);

			//first push all possible 
			for (uint64_t e : S0)
			{
				maskpair.push_back((e << 1) ^ 0x100000001);
				//printf("triger S0 7 (%d,%d,0)", n, k);
			}
			for (uint32_t i = 0; i < S1.size(); i++)
			{
				//push 011:3
				maskpair.push_back((S1[i] << 1) ^ 1);
				//printf("triger S1 3 (%d,%d,0)", n, k);

				//push 110:6
				maskpair.push_back((S1[i] << 1) ^ 0x100000000);
				//printf("triger S1 6 (%d,%d,0)", n, k);

			}
			//for (uint64_t e : maskpair)
			//	printf("%16.16llx,", e);
			//printf("\n");
			// shieve from u mode
			if ((n & 7) == 0 && maskpair.empty() == false)
			{
				while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
				{
					maskpair.pop_back();
					//printf("pop\n");
					if (maskpair.empty() == true)
						break;
				}
				if (maskpair.empty() == false)
				{
					std::vector<uint64_t>::iterator l = maskpair.begin();
					while (l != maskpair.end())
					{
						if (BiSearch(ExtractByte((uint32_t)((*l) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
						{
							*l = *(maskpair.end() - 1);
							maskpair.pop_back();
							//printf("pop\n");
							while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
								maskpair.pop_back();
							l++;
						}
						else
							l++;
					}
				}
			}
			S0.clear();
			S1.clear();
		}
		else
		{
			GenerateTwoInputsLinearMasks_Binary_1(n - 1, k - 1, wyp_fix, wz, zmaxpointsize, S1);
			for (uint32_t i = 0; i < S1.size(); i++)
			{
				//push 000:0
				maskpair.push_back((S1[i] << 1));
				//printf("triger S1 0 (%d,%d,0)", n, k);
				//push 101:5
				maskpair.push_back((S1[i] << 1) ^ 0x100000001);//push 1
				//printf("triger S1 5 (%d,%d,0)", n, k);

			}
			//for (uint64_t e : maskpair)
			//	printf("%16.16llx,", e);
			//printf("\n");

			//printf("S0:");
			//for (auto e : S0)
			//	printf("%16.16x,", e);
			//printf("S1:");
			//for (auto e : S1)
			//	printf("%16.16x,", e);
			// shieve from u mode
			if ((n & 7) == 0 && maskpair.empty() == false)
			{
				while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
				{
					maskpair.pop_back();
					//printf("pop\n");
					if (maskpair.empty() == true)
						break;
				}
				if (maskpair.empty() == false)
				{
					std::vector<uint64_t>::iterator l = maskpair.begin();
					while (l != maskpair.end())
					{
						if (BiSearch(ExtractByte((uint32_t)((*l) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
						{
							*l = *(maskpair.end() - 1);
							maskpair.pop_back();
							//printf("pop\n");
							while (BiSearch(ExtractByte((uint32_t)((*(maskpair.end() - 1)) >> 32), 3), MAXPOINT_AESINV[wz[4 - (n >> 3)]], zmaxpointsize[4 - (n >> 3)]) == false)
								maskpair.pop_back();
							l++;
						}
						else
							l++;
					}
				}
			}
			S0.clear();
			S1.clear();
		}
	}
}
