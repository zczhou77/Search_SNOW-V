#pragma once

#include<inttypes.h>
#include<set>
#include<fstream>
#include<iostream>
#include<immintrin.h>
#include<pmmintrin.h>
#include<assert.h>
#include"table.h"
#include"recusive.h"

//Parameters for searching
#define SIGMAADDITION_BOUND (-16.0)//N3_t bound
#define NOISEONE_PRUNEBOUND (-21.0)//N1_t bound
#define NOISETWO_PRUNEBOUND (-31.0)//N2_t bound
#define TOTAL_COR_BOUND (-90.0)
#define AES_BYTE 256
#define AES_MODU (AES_BYTE -1)
#define PRUNE_CAPACITY 65536
#define OFFSET_ga2 256
#define PRESERVE_LAMBDA 256
#define TOTAL_MASK_NUM 60
#define SBOX_CORRELATION (-4)
#define Rote(y,r) (((y)<<((r)<<3))|((y)>>(32-((r)<<3))))
//i from 0 to 3 left to right
#define ExtractByte(y,i) (((y)>>((3-(i))<<3))&0xFF)
#define ByteToInt(x3,x2,x1,x0) (((uint32_t)(x3) << 24) ^ ((uint32_t)(x2) << 16) ^ ((uint32_t)(x1) << 8) ^ ((uint32_t)(x0)))
#define Position(u,wx,wy) (((int32_t)(u)<<18)^((int32_t)(wx)<<10)^((int32_t)(wy)<<2))
//alpha
static uint8_t AL[8*8] = {
0,0,0,0,0,0,0,1,
1,0,0,0,0,0,0,1,
0,1,0,0,0,0,0,0,
0,0,1,0,0,0,0,1,
0,0,0,1,0,0,0,1,
0,0,0,0,1,0,0,0,
0,0,0,0,0,1,0,0,
0,0,0,0,0,0,1,0,
};
//0xe
static uint8_t E[8*8] = {
0,0,0,0,0,1,1,1,
1,0,0,0,0,1,0,0,
1,1,0,0,0,0,1,0,
1,1,1,0,0,1,1,0,
0,1,1,1,0,1,0,0,
0,0,1,1,1,0,1,0,
0,0,0,1,1,1,0,1,
0,0,0,0,1,1,1,0,
};
//0xb
static uint8_t B[8*8] = {
1,0,0,0,0,1,0,1,
1,1,0,0,0,1,1,1,
0,1,1,0,0,0,1,1,
1,0,1,1,0,1,0,0,
0,1,0,1,1,1,1,1,
0,0,1,0,1,1,1,1,
0,0,0,1,0,1,1,1,
0,0,0,0,1,0,1,1,
};
//0xd
static uint8_t D[8*8] = {
1,0,0,0,0,1,1,0,
0,1,0,0,0,1,0,1,
1,0,1,0,0,0,1,0,
1,1,0,1,0,1,1,1,
0,1,1,0,1,1,0,1,
0,0,1,1,0,1,1,0,
0,0,0,1,1,0,1,1,
0,0,0,0,1,1,0,1,
};
//0x9
static uint8_t N[8*8] = {
1,0,0,0,0,1,0,0,
0,1,0,0,0,1,1,0,
0,0,1,0,0,0,1,1,
1,0,0,1,0,1,0,1,
0,1,0,0,1,1,1,0,
0,0,1,0,0,1,1,1,
0,0,0,1,0,0,1,1,
0,0,0,0,1,0,0,1,
};
//AES SBox inverse
static STATIC_CACHE_ALIGN_AVX2 uint8_t SINV[256] = {
82, 9, 106, 213, 48, 54, 165, 56, 191, 64, 163, 158, 129, 243, 215, 251,
124, 227, 57, 130, 155, 47, 255, 135, 52, 142, 67, 68, 196, 222, 233, 203, 
84, 123, 148, 50, 166, 194, 35, 61, 238, 76, 149, 11, 66, 250, 195, 78, 8, 
46, 161, 102, 40, 217, 36, 178, 118, 91, 162, 73, 109, 139, 209, 37, 114, 
248, 246, 100, 134, 104, 152, 22, 212, 164, 92, 204, 93, 101, 182, 146, 108,
 112, 72, 80, 253, 237, 185, 218, 94, 21, 70, 87, 167, 141, 157, 132, 144, 
 216, 171, 0, 140, 188, 211, 10, 247, 228, 88, 5, 184, 179, 69, 6, 208, 44, 
 30, 143, 202, 63, 15, 2, 193, 175, 189, 3, 1, 19, 138, 107, 58, 145, 17, 65,
79, 103, 220, 234, 151, 242, 207, 206, 240, 180, 230, 115, 150, 172, 116, 34,
231, 173, 53, 133, 226, 249, 55, 232, 28, 117, 223, 110, 71, 241, 26, 113,
29, 41, 197, 137, 111, 183, 98, 14, 170, 24, 190, 27, 252, 86, 62, 75, 198, 
210, 121, 32, 154, 219, 192, 254, 120, 205, 90, 244, 31, 221, 168, 51, 136, 
7, 199, 49, 177, 18, 16, 89, 39, 128, 236, 95, 96, 81, 127, 169, 25, 181, 74, 
13, 45, 229, 122, 159, 147, 201, 156, 239, 160, 224, 59, 77, 174, 42, 245, 176, 
200, 235, 187, 60, 131, 83, 153, 97, 23, 43, 4, 126, 186, 119, 214, 38, 225, 105, 20, 99, 85, 33, 12, 125
};
static uint8_t HeadOne[256] = {
0, 0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3,
4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 
5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 
6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7 };
static uint8_t TailOne[256] = {
0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0, 
7, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
6, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
5, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0,
4, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };
//for MDS inverse multiply
uint32_t LIIHW[256] = {
0x00000000,0x01018180,0x02028381,0x03030201,0x04040602,0x05058782,0x06068583,0x07070403,
0x08088c84,0x09090d04,0x0a0a0f05,0x0b0b8e85,0x0c0c8a86,0x0d0d0b06,0x0e0e0907,0x0f0f8887,
0x10109888,0x11111908,0x12121b09,0x13139a89,0x14149e8a,0x15151f0a,0x16161d0b,0x17179c8b,
0x1818140c,0x1919958c,0x1a1a978d,0x1b1b160d,0x1c1c120e,0x1d1d938e,0x1e1e918f,0x1f1f100f,
0x20203010,0x2121b190,0x2222b391,0x23233211,0x24243612,0x2525b792,0x2626b593,0x27273413,
0x2828bc94,0x29293d14,0x2a2a3f15,0x2b2bbe95,0x2c2cba96,0x2d2d3b16,0x2e2e3917,0x2f2fb897,
0x3030a898,0x31312918,0x32322b19,0x3333aa99,0x3434ae9a,0x35352f1a,0x36362d1b,0x3737ac9b,
0x3838241c,0x3939a59c,0x3a3aa79d,0x3b3b261d,0x3c3c221e,0x3d3da39e,0x3e3ea19f,0x3f3f201f,
0x40406020,0x4141e1a0,0x4242e3a1,0x43436221,0x44446622,0x4545e7a2,0x4646e5a3,0x47476423,
0x4848eca4,0x49496d24,0x4a4a6f25,0x4b4beea5,0x4c4ceaa6,0x4d4d6b26,0x4e4e6927,0x4f4fe8a7,
0x5050f8a8,0x51517928,0x52527b29,0x5353faa9,0x5454feaa,0x55557f2a,0x56567d2b,0x5757fcab,
0x5858742c,0x5959f5ac,0x5a5af7ad,0x5b5b762d,0x5c5c722e,0x5d5df3ae,0x5e5ef1af,0x5f5f702f,
0x60605030,0x6161d1b0,0x6262d3b1,0x63635231,0x64645632,0x6565d7b2,0x6666d5b3,0x67675433,
0x6868dcb4,0x69695d34,0x6a6a5f35,0x6b6bdeb5,0x6c6cdab6,0x6d6d5b36,0x6e6e5937,0x6f6fd8b7,
0x7070c8b8,0x71714938,0x72724b39,0x7373cab9,0x7474ceba,0x75754f3a,0x76764d3b,0x7777ccbb,
0x7878443c,0x7979c5bc,0x7a7ac7bd,0x7b7b463d,0x7c7c423e,0x7d7dc3be,0x7e7ec1bf,0x7f7f403f,
0x8080c040,0x818141c0,0x828243c1,0x8383c241,0x8484c642,0x858547c2,0x868645c3,0x8787c443,
0x88884cc4,0x8989cd44,0x8a8acf45,0x8b8b4ec5,0x8c8c4ac6,0x8d8dcb46,0x8e8ec947,0x8f8f48c7,
0x909058c8,0x9191d948,0x9292db49,0x93935ac9,0x94945eca,0x9595df4a,0x9696dd4b,0x97975ccb,
0x9898d44c,0x999955cc,0x9a9a57cd,0x9b9bd64d,0x9c9cd24e,0x9d9d53ce,0x9e9e51cf,0x9f9fd04f,
0xa0a0f050,0xa1a171d0,0xa2a273d1,0xa3a3f251,0xa4a4f652,0xa5a577d2,0xa6a675d3,0xa7a7f453,
0xa8a87cd4,0xa9a9fd54,0xaaaaff55,0xabab7ed5,0xacac7ad6,0xadadfb56,0xaeaef957,0xafaf78d7,
0xb0b068d8,0xb1b1e958,0xb2b2eb59,0xb3b36ad9,0xb4b46eda,0xb5b5ef5a,0xb6b6ed5b,0xb7b76cdb,
0xb8b8e45c,0xb9b965dc,0xbaba67dd,0xbbbbe65d,0xbcbce25e,0xbdbd63de,0xbebe61df,0xbfbfe05f,
0xc0c0a060,0xc1c121e0,0xc2c223e1,0xc3c3a261,0xc4c4a662,0xc5c527e2,0xc6c625e3,0xc7c7a463,
0xc8c82ce4,0xc9c9ad64,0xcacaaf65,0xcbcb2ee5,0xcccc2ae6,0xcdcdab66,0xcecea967,0xcfcf28e7,
0xd0d038e8,0xd1d1b968,0xd2d2bb69,0xd3d33ae9,0xd4d43eea,0xd5d5bf6a,0xd6d6bd6b,0xd7d73ceb,
0xd8d8b46c,0xd9d935ec,0xdada37ed,0xdbdbb66d,0xdcdcb26e,0xdddd33ee,0xdede31ef,0xdfdfb06f,
0xe0e09070,0xe1e111f0,0xe2e213f1,0xe3e39271,0xe4e49672,0xe5e517f2,0xe6e615f3,0xe7e79473,
0xe8e81cf4,0xe9e99d74,0xeaea9f75,0xebeb1ef5,0xecec1af6,0xeded9b76,0xeeee9977,0xefef18f7,
0xf0f008f8,0xf1f18978,0xf2f28b79,0xf3f30af9,0xf4f40efa,0xf5f58f7a,0xf6f68d7b,0xf7f70cfb,
0xf8f8847c,0xf9f905fc,0xfafa07fd,0xfbfb867d,0xfcfc827e,0xfdfd03fe,0xfefe01ff,0xffff807f};
uint32_t RIIHWT[256] ={
0x00000000,0x01018180,0x02028381,0x03030201,0x04040602,0x05058782,0x06068583,0x07070403,
0x08088c84,0x09090d04,0x0a0a0f05,0x0b0b8e85,0x0c0c8a86,0x0d0d0b06,0x0e0e0907,0x0f0f8887,
0x10109888,0x11111908,0x12121b09,0x13139a89,0x14149e8a,0x15151f0a,0x16161d0b,0x17179c8b,
0x1818140c,0x1919958c,0x1a1a978d,0x1b1b160d,0x1c1c120e,0x1d1d938e,0x1e1e918f,0x1f1f100f,
0x20203010,0x2121b190,0x2222b391,0x23233211,0x24243612,0x2525b792,0x2626b593,0x27273413,
0x2828bc94,0x29293d14,0x2a2a3f15,0x2b2bbe95,0x2c2cba96,0x2d2d3b16,0x2e2e3917,0x2f2fb897,
0x3030a898,0x31312918,0x32322b19,0x3333aa99,0x3434ae9a,0x35352f1a,0x36362d1b,0x3737ac9b,
0x3838241c,0x3939a59c,0x3a3aa79d,0x3b3b261d,0x3c3c221e,0x3d3da39e,0x3e3ea19f,0x3f3f201f,
0x40406020,0x4141e1a0,0x4242e3a1,0x43436221,0x44446622,0x4545e7a2,0x4646e5a3,0x47476423,
0x4848eca4,0x49496d24,0x4a4a6f25,0x4b4beea5,0x4c4ceaa6,0x4d4d6b26,0x4e4e6927,0x4f4fe8a7,
0x5050f8a8,0x51517928,0x52527b29,0x5353faa9,0x5454feaa,0x55557f2a,0x56567d2b,0x5757fcab,
0x5858742c,0x5959f5ac,0x5a5af7ad,0x5b5b762d,0x5c5c722e,0x5d5df3ae,0x5e5ef1af,0x5f5f702f,
0x60605030,0x6161d1b0,0x6262d3b1,0x63635231,0x64645632,0x6565d7b2,0x6666d5b3,0x67675433,
0x6868dcb4,0x69695d34,0x6a6a5f35,0x6b6bdeb5,0x6c6cdab6,0x6d6d5b36,0x6e6e5937,0x6f6fd8b7,
0x7070c8b8,0x71714938,0x72724b39,0x7373cab9,0x7474ceba,0x75754f3a,0x76764d3b,0x7777ccbb,
0x7878443c,0x7979c5bc,0x7a7ac7bd,0x7b7b463d,0x7c7c423e,0x7d7dc3be,0x7e7ec1bf,0x7f7f403f,
0x8080c040,0x818141c0,0x828243c1,0x8383c241,0x8484c642,0x858547c2,0x868645c3,0x8787c443,
0x88884cc4,0x8989cd44,0x8a8acf45,0x8b8b4ec5,0x8c8c4ac6,0x8d8dcb46,0x8e8ec947,0x8f8f48c7,
0x909058c8,0x9191d948,0x9292db49,0x93935ac9,0x94945eca,0x9595df4a,0x9696dd4b,0x97975ccb,
0x9898d44c,0x999955cc,0x9a9a57cd,0x9b9bd64d,0x9c9cd24e,0x9d9d53ce,0x9e9e51cf,0x9f9fd04f,
0xa0a0f050,0xa1a171d0,0xa2a273d1,0xa3a3f251,0xa4a4f652,0xa5a577d2,0xa6a675d3,0xa7a7f453,
0xa8a87cd4,0xa9a9fd54,0xaaaaff55,0xabab7ed5,0xacac7ad6,0xadadfb56,0xaeaef957,0xafaf78d7,
0xb0b068d8,0xb1b1e958,0xb2b2eb59,0xb3b36ad9,0xb4b46eda,0xb5b5ef5a,0xb6b6ed5b,0xb7b76cdb,
0xb8b8e45c,0xb9b965dc,0xbaba67dd,0xbbbbe65d,0xbcbce25e,0xbdbd63de,0xbebe61df,0xbfbfe05f,
0xc0c0a060,0xc1c121e0,0xc2c223e1,0xc3c3a261,0xc4c4a662,0xc5c527e2,0xc6c625e3,0xc7c7a463,
0xc8c82ce4,0xc9c9ad64,0xcacaaf65,0xcbcb2ee5,0xcccc2ae6,0xcdcdab66,0xcecea967,0xcfcf28e7,
0xd0d038e8,0xd1d1b968,0xd2d2bb69,0xd3d33ae9,0xd4d43eea,0xd5d5bf6a,0xd6d6bd6b,0xd7d73ceb,
0xd8d8b46c,0xd9d935ec,0xdada37ed,0xdbdbb66d,0xdcdcb26e,0xdddd33ee,0xdede31ef,0xdfdfb06f,
0xe0e09070,0xe1e111f0,0xe2e213f1,0xe3e39271,0xe4e49672,0xe5e517f2,0xe6e615f3,0xe7e79473,
0xe8e81cf4,0xe9e99d74,0xeaea9f75,0xebeb1ef5,0xecec1af6,0xeded9b76,0xeeee9977,0xefef18f7,
0xf0f008f8,0xf1f18978,0xf2f28b79,0xf3f30af9,0xf4f40efa,0xf5f58f7a,0xf6f68d7b,0xf7f70cfb,
0xf8f8847c,0xf9f905fc,0xfafa07fd,0xfbfb867d,0xfcfc827e,0xfdfd03fe,0xfefe01ff,0xffff807f,
};
uint32_t NDBE[256] = {
0x00000000,0x2161a1e0,0x62a2e321,0x43c342c1,0xc445c643,0xe52467a3,0xa6e72562,0x87868482,
0xa9eb2d67,0x888a8c87,0xcb49ce46,0xea286fa6,0x6daeeb24,0x4ccf4ac4,0x0f0c0805,0x2e6da9e5,
0x72b6fa2e,0x53d75bce,0x1014190f,0x3175b8ef,0xb6f33c6d,0x97929d8d,0xd451df4c,0xf5307eac,
0xdb5dd749,0xfa3c76a9,0xb9ff3468,0x989e9588,0x1f18110a,0x3e79b0ea,0x7dbaf22b,0x5cdb53cb,
0xe46cf45c,0xc50d55bc,0x86ce177d,0xa7afb69d,0x2029321f,0x014893ff,0x428bd13e,0x63ea70de,
0x4d87d93b,0x6ce678db,0x2f253a1a,0x0e449bfa,0x89c21f78,0xa8a3be98,0xeb60fc59,0xca015db9,
0x96da0e72,0xb7bbaf92,0xf478ed53,0xd5194cb3,0x529fc831,0x73fe69d1,0x303d2b10,0x115c8af0,
0x3f312315,0x1e5082f5,0x5d93c034,0x7cf261d4,0xfb74e556,0xda1544b6,0x99d60677,0xb8b7a797,
0xc8d8e8b8,0xe9b94958,0xaa7a0b99,0x8b1baa79,0x0c9d2efb,0x2dfc8f1b,0x6e3fcdda,0x4f5e6c3a,
0x6133c5df,0x4052643f,0x039126fe,0x22f0871e,0xa576039c,0x8417a27c,0xc7d4e0bd,0xe6b5415d,
0xba6e1296,0x9b0fb376,0xd8ccf1b7,0xf9ad5057,0x7e2bd4d5,0x5f4a7535,0x1c8937f4,0x3de89614,
0x13853ff1,0x32e49e11,0x7127dcd0,0x50467d30,0xd7c0f9b2,0xf6a15852,0xb5621a93,0x9403bb73,
0x2cb41ce4,0x0dd5bd04,0x4e16ffc5,0x6f775e25,0xe8f1daa7,0xc9907b47,0x8a533986,0xab329866,
0x855f3183,0xa43e9063,0xe7fdd2a2,0xc69c7342,0x411af7c0,0x607b5620,0x23b814e1,0x02d9b501,
0x5e02e6ca,0x7f63472a,0x3ca005eb,0x1dc1a40b,0x9a472089,0xbb268169,0xf8e5c3a8,0xd9846248,
0xf7e9cbad,0xd6886a4d,0x954b288c,0xb42a896c,0x33ac0dee,0x12cdac0e,0x510eeecf,0x706f4f2f,
0x90b0d070,0xb1d17190,0xf2123351,0xd37392b1,0x54f51633,0x7594b7d3,0x3657f512,0x173654f2,
0x395bfd17,0x183a5cf7,0x5bf91e36,0x7a98bfd6,0xfd1e3b54,0xdc7f9ab4,0x9fbcd875,0xbedd7995,
0xe2062a5e,0xc3678bbe,0x80a4c97f,0xa1c5689f,0x2643ec1d,0x07224dfd,0x44e10f3c,0x6580aedc,
0x4bed0739,0x6a8ca6d9,0x294fe418,0x082e45f8,0x8fa8c17a,0xaec9609a,0xed0a225b,0xcc6b83bb,
0x74dc242c,0x55bd85cc,0x167ec70d,0x371f66ed,0xb099e26f,0x91f8438f,0xd23b014e,0xf35aa0ae,
0xdd37094b,0xfc56a8ab,0xbf95ea6a,0x9ef44b8a,0x1972cf08,0x38136ee8,0x7bd02c29,0x5ab18dc9,
0x066ade02,0x270b7fe2,0x64c83d23,0x45a99cc3,0xc22f1841,0xe34eb9a1,0xa08dfb60,0x81ec5a80,
0xaf81f365,0x8ee05285,0xcd231044,0xec42b1a4,0x6bc43526,0x4aa594c6,0x0966d607,0x280777e7,
0x586838c8,0x79099928,0x3acadbe9,0x1bab7a09,0x9c2dfe8b,0xbd4c5f6b,0xfe8f1daa,0xdfeebc4a,
0xf18315af,0xd0e2b44f,0x9321f68e,0xb240576e,0x35c6d3ec,0x14a7720c,0x576430cd,0x7605912d,
0x2adec2e6,0x0bbf6306,0x487c21c7,0x691d8027,0xee9b04a5,0xcffaa545,0x8c39e784,0xad584664,
0x8335ef81,0xa2544e61,0xe1970ca0,0xc0f6ad40,0x477029c2,0x66118822,0x25d2cae3,0x04b36b03,
0xbc04cc94,0x9d656d74,0xdea62fb5,0xffc78e55,0x78410ad7,0x5920ab37,0x1ae3e9f6,0x3b824816,
0x15efe1f3,0x348e4013,0x774d02d2,0x562ca332,0xd1aa27b0,0xf0cb8650,0xb308c491,0x92696571,
0xceb236ba,0xefd3975a,0xac10d59b,0x8d71747b,0x0af7f0f9,0x2b965119,0x685513d8,0x4934b238,
0x67591bdd,0x4638ba3d,0x05fbf8fc,0x249a591c,0xa31cdd9e,0x827d7c7e,0xc1be3ebf,0xe0df9f5f,
};

//byte hamming weight
inline uint8_t ByteWeight(uint32_t x)
{
	uint8_t w = 0;
	for (uint8_t i = 0; i < 4; i++)
		if (((x >> (i << 3))&0xFF) != 0)
			w++;
	return w;
}
//given input mask of SINV[y], say wy, find the best choice of the other two: u and wx
//case 1: u=wx
//case 2: u!=wx
void GenerateTwoAdditionWithLargeCorrelation()
{
	std::vector<std::vector<uint8_t> > msk;
	std::set<uint64_t> ordermask;
	std::array<uint32_t, 3> uxy;
	uint64_t ux = 0;
	for (uint8_t k = 2; k <= 4; k++)//all masks in linear hull
	{
		msk.clear();
		GenerateTwoInputsLinearMasks_Binary(32, k, 0, msk);
		printf("type 0 mask size of cor 2^-%d, %d\n",k, msk.size());
		for (auto e : msk)
		{
			ThreeMaskSliceToInt(e, uxy);
			ux = ((uint64_t)uxy[0] << 32) ^ ((uint64_t)uxy[1]);//u||wx
			//if (((uxy[2] & 0xFF000000) != 0) && ((uxy[2] & 0x00FF0000) != 0) && ((uxy[2] & 0x0000FF00) != 0) && ((uxy[2] & 0x000000FF) != 0))
			if (((uxy[2] & 0xFF000000) != 0) && ((uxy[2] & 0x0000FF00) != 0) && ((uxy[2] & 0x000000FF) != 0))
				ordermask.insert(ux);
		}
	}
	for (uint8_t k = 2; k <= 4; k++)//all masks in linear hull
	{
		//
		msk.clear();
		GenerateTwoInputsLinearMasks_Binary(32, k, 1, msk);
		printf("type 1 mask size of cor 2^-%d, %d\n", k, msk.size());
		for (auto e : msk)
		{
			ThreeMaskSliceToInt(e, uxy);
			ux = ((uint64_t)uxy[0] << 32) ^ ((uint64_t)uxy[1]);//u||wx
			//if (((uxy[2] & 0xFF000000) != 0) && ((uxy[2] & 0x00FF0000) != 0) && ((uxy[2] & 0x0000FF00) != 0) && ((uxy[2] & 0x000000FF) != 0))
			if (((uxy[2] & 0xFF000000) != 0) && ((uxy[2] & 0x0000FF00) != 0) && ((uxy[2] & 0x000000FF) != 0))
				ordermask.insert(ux);
		}
	}
	printf("ux set size %d\n", ordermask.size());
	std::ofstream foo("SBox addition large cor mask pair_col2-4.dat", std::ios::binary | std::ios::out);

	if (foo.is_open()) {
		for (auto e : ordermask)
		{
			foo << e;
		}
		printf("write dat file done\n");
	}
	foo.close();
	std::ofstream goo("SBox addition large cor mask pair_col2-4.txt", std::ios::out);
	if (goo.is_open()) {
		for (auto e : ordermask)
		{
			goo << "0x";
			goo.width(8);
			goo << std::hex<<e<<std::endl;
		}
		printf("write txt file done\n");
	}
	goo.close();
}
//generate connection matrices for N1_t and N2_t
void PreComConectionMatrix(double* A)
{
#pragma omp parallel for
	for (int32_t u = 0; u < 256; u++)
		for (int32_t wx = 0; wx < 256; wx++)
			for (int32_t wy = 0; wy < 256; wy++)
			{
				double tmp[8] = { 0 };
				for (int32_t x = 0; x < 256; x++)
					for (int32_t y = 0; y < 256; y++)
					{
						//vaule z
						int32_t z_zcp = (x + SINV[y]);
						int32_t z_ocp = z_zcp + 1;
						int32_t ccz = ((z_zcp >> 8) & 1);//carry
						int32_t cco = ((z_ocp >> 8) & 1);

						uint8_t sum_xor_z = Parity[((u & z_zcp) ^ (wx & x) ^ (wy & y)) & 0xFF];
						uint8_t sum_xor_o = Parity[((u & z_ocp) ^ (wx & x) ^ (wy & y)) & 0xFF];
						tmp[(ccz << 2) + sum_xor_z] += 1;
						tmp[(cco << 2) + 2 + sum_xor_o] += 1;
					}
				A[(u << 18) ^ (wx << 10) ^ (wy << 2)] = (tmp[0] - tmp[1]) / ((double)(1 << 16));
				A[(u << 18) ^ (wx << 10) ^ (wy << 2) ^ 1] = (tmp[2] - tmp[3]) / ((double)(1 << 16));
				A[(u << 18) ^ (wx << 10) ^ (wy << 2) ^ 2] = (tmp[4] - tmp[5]) / ((double)(1 << 16));
				A[(u << 18) ^ (wx << 10) ^ (wy << 2) ^ 3] = (tmp[6] - tmp[7]) / ((double)(1 << 16));
			}
}
//These function are used to search sparse masks for N3_t
//(2->3,2->3,2->3,2->3)
void SigmaAdditionBinaryApproximation_2222(uint8_t weight)
{
	FILE* gptr = fopen("sigmaaddition_inputweight2222_3333_outputtotalweight6-8_mask+cor.txt", "w");
	if (gptr != NULL)
	{
		uint32_t col[4] = { 0 }, las_row[4] = { 0 }, col_addr[4] = { 0 };
		uint8_t msk[16] = { 0 };
#pragma omp parallel for collapse(4) private(col,las_row,col_addr,msk)
		for (int32_t l = 1; l < 256; l++)
			for (int32_t i = 1; i < 256; i++)
				for (int32_t j = 1; j < 256; j++)
					for (int32_t k = 1; k < 256; k++)
						for (uint8_t c0 = 0; c0 < 6; c0++)//input type
							for (uint8_t c1 = 0; c1 < 6; c1++)//input type
								for (uint8_t c2 = 0; c2 < 6; c2++)//input type
									for (uint8_t c3 = 0; c3 < 6; c3++)//input type
										for (uint8_t m = 1; m < 5; m++)//3: outputtype
											for (uint8_t p = 0; p < 4; p++)//zero column position
											{
												col[0] = TWOTOTHREE[m * 6 + c0][l];
												col[1] = TWOTOTHREE[m * 6 + c1][i];
												col[2] = TWOTOTHREE[m * 6 + c2][j];
												col[3] = TWOTOTHREE[m * 6 + c3][k];
												for (uint8_t i = 0; i < 4; i++)
												{
													msk[i] = ExtractByte(col[0], 3 - i);
													msk[i + 4] = ExtractByte(col[1], 3 - i);
													msk[i + 8] = ExtractByte(col[2], 3 - i);
													msk[i + 12] = ExtractByte(col[3], 3 - i);
												}
												col_addr[0] = TWOTOTHREE_INPUT[m * 6 + c0][l];
												col_addr[1] = TWOTOTHREE_INPUT[m * 6 + c1][i];
												col_addr[2] = TWOTOTHREE_INPUT[m * 6 + c2][j];
												col_addr[3] = TWOTOTHREE_INPUT[m * 6 + c3][k];

												las_row[0] = RIIHWT[msk[0]] ^ Rote(RIIHWT[msk[4]], 1) ^ Rote(RIIHWT[msk[8]], 2) ^ Rote(RIIHWT[msk[12]], 3);
												las_row[1] = RIIHWT[msk[1]] ^ Rote(RIIHWT[msk[5]], 1) ^ Rote(RIIHWT[msk[9]], 2) ^ Rote(RIIHWT[msk[13]], 3);
												las_row[2] = RIIHWT[msk[2]] ^ Rote(RIIHWT[msk[6]], 1) ^ Rote(RIIHWT[msk[10]], 2) ^ Rote(RIIHWT[msk[14]], 3);
												las_row[3] = RIIHWT[msk[3]] ^ Rote(RIIHWT[msk[7]], 1) ^ Rote(RIIHWT[msk[11]], 2) ^ Rote(RIIHWT[msk[15]], 3);

												//check here <= or ==
												if (ByteWeight(las_row[0]) + ByteWeight(las_row[1]) + ByteWeight(las_row[2]) + ByteWeight(las_row[3]) <= weight)
												{

													std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
													SliceFourMask(msk, msk, msk, msk, 4, z);
													double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
													if (log2(abs(cor)) >= SIGMAADDITION_BOUND)
													{

														{
															fprintf(gptr, "0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
																col_addr[0], col_addr[1], col_addr[2], col_addr[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
															printf("0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
																col_addr[0], col_addr[1], col_addr[2], col_addr[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
														}
													}
												}

											}
	}
	fclose(gptr);
}
//(2->3,2->3,2->3)
void SigmaAdditionBinaryApproximation_222(uint8_t weight)
{
	FILE* gptr = fopen("sigmaaddition_inputweight222_333_outputtotalweight6-8_mask+cor.txt", "w");
	if (gptr != NULL)
	{
		uint32_t col[4] = { 0 }, las_row[4] = { 0 }, col_addr[4] = { 0 };
		uint8_t msk[16] = { 0 };
#pragma omp parallel for collapse(3) private(col,las_row,col_addr,msk)
		for (int32_t i = 1; i < 256; i++)
			for (int32_t j = 1; j < 256; j++)
				for (int32_t k = 1; k < 256; k++)
					for (uint8_t c1 = 0; c1 < 6; c1++)//input type
						for (uint8_t c2 = 0; c2 < 6; c2++)//input type
							for (uint8_t c3 = 0; c3 < 6; c3++)//input type
								for (uint8_t m = 1; m < 5; m++)//3: outputtype
									for (uint8_t p = 0; p < 4; p++)//zero column position
									{
										col[(p) & 3] = 0;
										col[(p + 1) & 3] = TWOTOTHREE[m * 6 + c1][i];
										col[(p + 2) & 3] = TWOTOTHREE[m * 6 + c2][j];
										col[(p + 3) & 3] = TWOTOTHREE[m * 6 + c3][k];
										for (uint8_t i = 0; i < 4; i++)
										{
											msk[i] = ExtractByte(col[0], 3 - i);
											msk[i + 4] = ExtractByte(col[1], 3 - i);
											msk[i + 8] = ExtractByte(col[2], 3 - i);
											msk[i + 12] = ExtractByte(col[3], 3 - i);
										}
										col_addr[(p) & 3] = 0;
										col_addr[(p + 1) & 3] = TWOTOTHREE_INPUT[m * 6 + c1][i];
										col_addr[(p + 2) & 3] = TWOTOTHREE_INPUT[m * 6 + c2][j];
										col_addr[(p + 3) & 3] = TWOTOTHREE_INPUT[m * 6 + c3][k];

										las_row[0] = RIIHWT[msk[0]] ^ Rote(RIIHWT[msk[4]], 1) ^ Rote(RIIHWT[msk[8]], 2) ^ Rote(RIIHWT[msk[12]], 3);
										las_row[1] = RIIHWT[msk[1]] ^ Rote(RIIHWT[msk[5]], 1) ^ Rote(RIIHWT[msk[9]], 2) ^ Rote(RIIHWT[msk[13]], 3);
										las_row[2] = RIIHWT[msk[2]] ^ Rote(RIIHWT[msk[6]], 1) ^ Rote(RIIHWT[msk[10]], 2) ^ Rote(RIIHWT[msk[14]], 3);
										las_row[3] = RIIHWT[msk[3]] ^ Rote(RIIHWT[msk[7]], 1) ^ Rote(RIIHWT[msk[11]], 2) ^ Rote(RIIHWT[msk[15]], 3);

										//check here <= or ==
										if (ByteWeight(las_row[0]) + ByteWeight(las_row[1]) + ByteWeight(las_row[2]) + ByteWeight(las_row[3]) <= weight)
										{

											std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
											SliceFourMask(msk, msk, msk, msk, 4, z);
											double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
											if (log2(abs(cor)) >= SIGMAADDITION_BOUND)
											{

												{
													fprintf(gptr, "0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
														col_addr[0], col_addr[1], col_addr[2], col_addr[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
													printf("0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
														col_addr[0], col_addr[1], col_addr[2], col_addr[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
												}
											}
										}

									}
	}
	fclose(gptr);
}
//(3->3,2->3,2->3)
void SigmaAdditionBinaryApproximation_322A(uint8_t tweight)
{
	//--section 1 compute all possible mask's correlation of sigma addition
	//generate all legal masks
	//(1)read 3->3 mask input frome file and the 2->3 type are already in global variable
	//std::ifstream ifs("threetothree_output.dat", std::ios::binary | std::ios::in);
	//assert(ifs.is_open());
	//uint32_t* THREETOTHREE = new uint32_t[64770 * 16]();
	//ifs.read((char *)THREETOTHREE, sizeof(uint32_t) * 64770);
	//ifs.close();
	//(2)prepare for loop
	uint8_t colwgt[12][4] = {
	3,2,1,0,//input mod [3,2,2,0]
	3,2,0,1,//input mod [3,2,0,2]
	3,0,2,1,//input mod [3,0,2,2]
	2,3,1,0,//input mod [2,3,2,0]
	2,3,0,1,//input mod [2,3,0,2]
	0,3,2,1,//input mod [0,3,2,2]
	2,1,3,0,//input mod [2,2,3,0]
	2,0,3,1,//input mod [2,0,3,2]
	0,2,3,1,//input mod [0,2,3,2]
	2,1,0,3,//input mod [2,2,0,3]
	2,0,1,3,//input mod [2,0,2,3]
	0,2,1,3//input mod [0,2,2,3]
	};

	FILE* ofs = fopen("sigmaaddition_inputweight322_333_outputtotalweight7_mask+cor.txt", "w");
	if (ofs != NULL)
	{
		//[[1, 1, 0, 0]0, [1, 0, 1, 0]1, [0, 1, 1, 0]2, [1, 0, 0, 1]3,[0, 1, 0, 1]4,[0, 0, 1, 1]5]
		//[[0, 0, 0, 0]0, [1, 1, 1, 0]1, [1, 1, 0, 1]2, [1, 0, 1, 1]3, [0, 1, 1, 1]4]
		uint8_t u[16] = { 0 }, wx[16] = { 0 }, wy[16] = { 0 }, wz[16] = { 0 };
		uint32_t col[4] = { 0,0,0,0 };
		uint32_t col_p[4] = { 0,0,0,0 };
		uint32_t col_in[4] = { 0,0,0,0 };
		uint32_t col_in_p[4] = { 0,0,0,0 };
		uint32_t las_row[4] = { 0,0,0,0 };
#pragma omp parallel for private(u,wx,wy,wz,col,col_p,col_in,col_in_p,las_row) collapse(3)
		for (int32_t i = 0; i < 64770; i++)//three each subtable size 4*4=16 subtable
			for (int32_t j = 1; j < 256; j++)//two
				for (int32_t k = 1; k < 256; k++)//two
					for (int32_t o = 0; o < 1; o++)//mod of Phi(out) 1: MSB=0
						for (int32_t h = 0; h < 1; h++)//mod of ph3 input 1:MSB=0
							for (int32_t t1 = 0; t1 < 3; t1++)//mod of ph3 input weight 2 3:MSB=0
								for (int32_t t2 = 0; t2 < 3; t2++)//mod of ph3 input weight 2 3: MSB=0
									for (int32_t wt = 0; wt < 12; wt++)
									{
										col_p[0] = 0;
										col_p[1] = TWOTOTHREE[(o + 1) * 6 + t1][k];
										col_p[2] = TWOTOTHREE[(o + 1) * 6 + t2][j];
										col_p[3] = THREETOTHREE[(o << 2) * 64770 + h * 64770 + i];
										col_in_p[0] = 0;
										col_in_p[1] = TWOTOTHREE_INPUT[(o + 1) * 6 + t1][k];
										col_in_p[2] = TWOTOTHREE_INPUT[(o + 1) * 6 + t2][j];
										col_in_p[3] = THREETOTHREE_INPUT[(o << 2) * 64770 + h * 64770 + i];
										col[0] = col_p[colwgt[wt][0]];
										col[1] = col_p[colwgt[wt][1]];
										col[2] = col_p[colwgt[wt][2]];
										col[3] = col_p[colwgt[wt][3]];
										col_in[0] = col_in_p[colwgt[wt][0]];
										col_in[1] = col_in_p[colwgt[wt][1]];
										col_in[2] = col_in_p[colwgt[wt][2]];
										col_in[3] = col_in_p[colwgt[wt][3]];
										for (uint8_t i = 0; i < 4; i++)
										{
											u[i] = wx[i] = wy[i] = wz[i] = ExtractByte(col[0], 3 - i);
											u[i + 4] = wx[i + 4] = wy[i + 4] = wz[i + 4] = ExtractByte(col[1], 3 - i);
											u[i + 8] = wx[i + 8] = wy[i + 8] = wz[i + 8] = ExtractByte(col[2], 3 - i);
											u[i + 12] = wx[i + 12] = wy[i + 12] = wz[i + 12] = ExtractByte(col[3], 3 - i);
										}
										las_row[0] = RIIHWT[wy[0]] ^ Rote(RIIHWT[wy[4]], 1) ^ Rote(RIIHWT[wy[8]], 2) ^ Rote(RIIHWT[wy[12]], 3);
										las_row[1] = RIIHWT[wy[1]] ^ Rote(RIIHWT[wy[5]], 1) ^ Rote(RIIHWT[wy[9]], 2) ^ Rote(RIIHWT[wy[13]], 3);
										las_row[2] = RIIHWT[wy[2]] ^ Rote(RIIHWT[wy[6]], 1) ^ Rote(RIIHWT[wy[10]], 2) ^ Rote(RIIHWT[wy[14]], 3);
										las_row[3] = RIIHWT[wy[3]] ^ Rote(RIIHWT[wy[7]], 1) ^ Rote(RIIHWT[wy[11]], 2) ^ Rote(RIIHWT[wy[15]], 3);
										uint8_t bw = ByteWeight(las_row[0]) + ByteWeight(las_row[1]) + ByteWeight(las_row[2]) + ByteWeight(las_row[3]);
										if (bw <= tweight && ByteWeight(col_p[3]) == 3)
										{
											std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
											SliceFourMask(u, wx, wy, wz, 4, z);
											double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
											if (log2(abs(cor)) >= SIGMAADDITION_BOUND)
											{
#pragma omp critical
												{
													fprintf(ofs, "0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
														col_in[0], col_in[1], col_in[2], col_in[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
													printf("0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
														col_in[0], col_in[1], col_in[2], col_in[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
												}
											}
										}
										//input mod [3,2,0,2]

									}
		//delete[] THREETOTHREE;
		fclose(ofs);
	}
}
//(3->2,2->3,2->3)
void SigmaAdditionBinaryApproximation_322(uint8_t tweight)
{
	//--section 1 compute all possible mask's correlation of sigma addition
	//generate all legal masks
	//(1)read 3->3 mask input frome file and the 2->3 type are already in global variable
	//std::ifstream ifs("threetothree_output.dat", std::ios::binary | std::ios::in);
	//assert(ifs.is_open());
	//uint32_t* THREETOTHREE = new uint32_t[64770 * 16]();
	//ifs.read((char *)THREETOTHREE, sizeof(uint32_t) * 64770);
	//ifs.close();
	//(2)prepare for loop
	//row: outputmode[[0, 0, 0, 0]0, [1, 1, 1, 0]1, [1, 1, 0, 1]2, [1, 0, 1, 1]3, [0, 1, 1, 1]4]
	uint8_t prop23[5][3] = {
		0,0,0,//0
		0,1,2,//1(*,*,*,0)
		0,3,4,//2
		1,3,5,//3
		2,4,5//4
	};
	
	uint8_t colwgt[12][4] = {
		3,2,1,0,//input mod [3,2,2,0]
		3,2,0,1,//input mod [3,2,0,2]
		3,0,2,1,//input mod [3,0,2,2]
		2,3,1,0,//input mod [2,3,2,0]
		2,3,0,1,//input mod [2,3,0,2]
		0,3,2,1,//input mod [0,3,2,2]
		2,1,3,0,//input mod [2,2,3,0]
		2,0,3,1,//input mod [2,0,3,2]
		0,2,3,1,//input mod [0,2,3,2]
		2,1,0,3,//input mod [2,2,0,3]
		2,0,1,3,//input mod [2,0,2,3]
		0,2,1,3//input mod [0,2,2,3]
	};
	FILE* ofs = fopen("sigmaaddition_inputweight322_233_outputtotalweight7_mask+cor.txt", "w");
	if (ofs != NULL)
	{
		uint8_t u[16] = { 0 }, wx[16] = { 0 }, wy[16] = { 0 }, wz[16] = { 0 };
		uint32_t col[4] = { 0,0,0,0 };
		uint32_t col_p[4]= { 0,0,0,0 };
		uint32_t col_in[4] = { 0,0,0,0 };
		uint32_t col_in_p[4] = { 0,0,0,0 };
		uint32_t las_row[4] = { 0,0,0,0 };
#pragma omp parallel for private(u,wx,wy,wz,col,col_p,col_in,col_in_p,las_row) collapse(3)
		for (int32_t i = 1; i < 256; i++)//three input x
			for (int32_t j = 1; j < 256; j++)//two input y
				for (int32_t k = 1; k < 256; k++)//two input z//prefix t = 2, h=3
					for (int32_t tmi1 = 0; tmi1 < 6; tmi1++)//3: MSB=0;6: 0/1, 2->3 input
						for (int32_t tmi2 = 0; tmi2 < 6; tmi2++)//3: MSB=0;6: 0/1 2->3 input
							for (int32_t tmo = 0; tmo < 4; tmo++)//outmode[1, 1, 1, 0]0, [1, 1, 0, 1]1, [1, 0, 1, 1]2, [0, 1, 1, 1]3
								for (int32_t hmi = 0; hmi < 4; hmi++)//1: MSB=0[1, 1, 1, 0]0, [1, 1, 0, 1]1, [1, 0, 1, 1]2, [0, 1, 1, 1]3
									for (int32_t hmo = 0; hmo < 3; hmo++)//restricted by tmo in prop23
										for (int32_t wt = 0; wt < 12; wt++)
										{
											//input mod [3,2,2,0]
											col_p[0] = 0;
											col_p[1]= TWOTOTHREE[(tmo + 1) * 6 + tmi2][k];
											col_p[2]= TWOTOTHREE[(tmo + 1) * 6 + tmi1][j];
											col_p[3]= THREETOTWO[((prop23[tmo + 1][hmo] * 4 + hmi) << 8) + i];
											col_in_p[0] = 0;
											col_in_p[1] = TWOTOTHREE_INPUT[(tmo + 1) * 6 + tmi2][k];
											col_in_p[2] = TWOTOTHREE_INPUT[(tmo + 1) * 6 + tmi1][j];
											col_in_p[3] = THREETOTWO_INPUT[((prop23[tmo + 1][hmo] * 4 + hmi) << 8) + i];
											col[0] = col_p[colwgt[wt][0]];
											col[1] = col_p[colwgt[wt][1]];
											col[2] = col_p[colwgt[wt][2]];
											col[3] = col_p[colwgt[wt][3]];
											col_in[0] = col_in_p[colwgt[wt][0]];
											col_in[1] = col_in_p[colwgt[wt][1]];
											col_in[2] = col_in_p[colwgt[wt][2]];
											col_in[3] = col_in_p[colwgt[wt][3]];
											//if (col_in[0] == 0x88109800 && col_in[1] == 0x00008898 && col_in[2] == 0x00008898 && col_in[3] == 0x00000000)
											//	printf("find\n");
											for (uint8_t i = 0; i < 4; i++)
											{
												u[i] = wx[i] = wy[i] = wz[i] = ExtractByte(col[0], 3 - i);
												u[i + 4] = wx[i + 4] = wy[i + 4] = wz[i + 4] = ExtractByte(col[1], 3 - i);
												u[i + 8] = wx[i + 8] = wy[i + 8] = wz[i + 8] = ExtractByte(col[2], 3 - i);
												u[i + 12] = wx[i + 12] = wy[i + 12] = wz[i + 12] = ExtractByte(col[3], 3 - i);
											}
											las_row[0] = RIIHWT[wy[0]] ^ Rote(RIIHWT[wy[4]], 1) ^ Rote(RIIHWT[wy[8]], 2) ^ Rote(RIIHWT[wy[12]], 3);
											las_row[1] = RIIHWT[wy[1]] ^ Rote(RIIHWT[wy[5]], 1) ^ Rote(RIIHWT[wy[9]], 2) ^ Rote(RIIHWT[wy[13]], 3);
											las_row[2] = RIIHWT[wy[2]] ^ Rote(RIIHWT[wy[6]], 1) ^ Rote(RIIHWT[wy[10]], 2) ^ Rote(RIIHWT[wy[14]], 3);
											las_row[3] = RIIHWT[wy[3]] ^ Rote(RIIHWT[wy[7]], 1) ^ Rote(RIIHWT[wy[11]], 2) ^ Rote(RIIHWT[wy[15]], 3);
											uint8_t bw = ByteWeight(las_row[0]) + ByteWeight(las_row[1]) + ByteWeight(las_row[2]) + ByteWeight(las_row[3]);
											if (bw <= tweight)
											{
												std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
												SliceFourMask(u, wx, wy, wz, 4, z);
												double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
												if (log2(abs(cor)) >= SIGMAADDITION_BOUND)
												{
		#pragma omp critical
													{
														fprintf(ofs, "0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
															col_in[0], col_in[1], col_in[2], col_in[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
														printf("0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,%f\n",
															col_in[0], col_in[1], col_in[2], col_in[3], las_row[0], las_row[1], las_row[2], las_row[3], log2(abs(cor)));
													}
												}
											}

										}

	}
	//delete[] THREETOTHREE;
	fclose(ofs);
}
//This function are used to generate all possible Lambda
//Lambda XOR Lambda^(3)=Gamma^(3),Gamma^(3)->MDS->Gamma^(2)
//ga2:Gamma^(2),la:Lambda,offset: Lambda^(3),la->MDS->la_input
bool LoadLambda_Cac_Offsetmode(uint32_t colmod_ps1[4], uint32_t colmod_ga2[4], uint8_t offset[16], uint32_t* la, uint32_t* la_input, int32_t size[4])
{
	bool flag = true;
	for (int32_t i = 0; i < 4; i++)//col
	{
		if (colmod_ps1[i] == 0x00000000)
		{
			size[i] = 1;
			la[(i * PRUNE_CAPACITY)] = 0;
			la_input[(i * PRUNE_CAPACITY)] = 0;
		}
		else
		{
			//range
			uint32_t base[4] = { 0,0,0,0 };
			uint32_t range[4] = { 0,0,0,0 };
			uint32_t bytehead = 0, bytetail = 0;
			for (int32_t j = 0; j < 4; j++)
			{
				if (ExtractByte(colmod_ps1[i], 3 - j) != 0)
				{
					//lsb position byte !-0
					bytetail = j;
					break;
				}
			}
			for (int32_t j = 0; j < 4; j++)
			{
				if (ExtractByte(colmod_ps1[i], j) != 0)
				{
					//lsb position byte !-0
					bytehead = 3 - j;
					break;
				}
			}
			for (int32_t j = 0; j < 4; j++)
			{
				if (ExtractByte(colmod_ga2[i], 3 - j) != 0)
				{
					range[j] = 0xFF;
					base[j] = 0x01;
				}
				else
				{
					range[j] = 0;
					base[j] = 0;
				}
			}
			try
			{
				//condition
				uint32_t ctr = 0;
				for (uint32_t x = base[0]; x <= range[0]; x++)
					for (uint32_t y = base[1]; y <= range[1]; y++)
						for (uint32_t z = base[2]; z <= range[2]; z++)
							for (uint32_t w = base[3]; w <= range[3]; w++)
							{
								uint32_t col_mask = NDBE[x] ^ Rote(NDBE[y], 1) ^ Rote(NDBE[z], 2) ^ Rote(NDBE[w], 3);
								bool tailflag = true;
								bool headflag = true;
								for (uint32_t a = 0; a < bytetail; a++)
								{
									if (ExtractByte(col_mask, 3 - a) != offset[(i << 2)+a])
									{
										tailflag = false;
										break;
									}
								}
								for (uint32_t a = 3; a > bytehead; a--)
								{
									if (ExtractByte(col_mask, 3 - a) != offset[(i << 2) + a])
									{
										headflag = false;
										break;
									}
								}
								if (ExtractByte(col_mask, 3 - bytetail) == offset[(i << 2) + bytetail])
								{
									tailflag = false;
								}
								if (ExtractByte(col_mask, 3 - bytehead) == offset[(i << 2) + bytehead])
								{
									headflag = false;
								}

								if (ctr >= PRUNE_CAPACITY)
								{
									bool flag = false;
									printf("%d", ctr);
									throw std::runtime_error("SIZE OVER 65536!");
								}
								if (tailflag == true && headflag == true)
								{
									la[i * PRUNE_CAPACITY + ctr] = col_mask;
									la_input[i * PRUNE_CAPACITY + ctr] = ByteToInt(w, z, y, x);
									ctr++;
								}

							}
				size[i] = ctr;
			}
			catch (std::runtime_error er)
			{
				std::cerr << er.what() << "\n";
			}
		}
	}

	return flag;
}
//struct to store the candidate masks when deal with N1_t
typedef struct NoiseOne
{
	uint32_t mask[4] = { 0,0,0,0 };//Gamma^(2)||Lambda||Psi^(1)||Lambda'
	double col_cor = 0.0;
	//compare function
	bool operator<(const NoiseOne& a) const
	{
		if (col_cor != a.col_cor)
			return col_cor > a.col_cor;
		else
			return mask[0] >= a.mask[0];
	}
}NoiseOne;
//The function corresponding to Algorithm 1 with prune strategy for N1_t
//AS: connection matrices,la:Lambda, ps1: Psi^(1)
//la:Lambda,offset: Lambda^(3),la->MDS->la_input
void SBoxAddition_OneColumn_PruneSearch(double* AS, uint8_t offset[4], int32_t size, uint8_t ps1[4], uint32_t* la, uint32_t* la_input, std::vector<NoiseOne>& col_seq_scaled)
{
	//format: u||wx||wy    ||base||range||shift   ||bytehead||bytetail
	//format: 0||4||8      ||12||16||20           ||24||25
	uint8_t tsection[26] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	std::vector<NoiseOne> col_seq;
	//dynamic prune bound
	double dynamic_bound = 0;
	uint32_t col_wt_ps1 = 0;
	if (size <= 256)
	{
		dynamic_bound = -22.0;
	}
	else if (size >= 256 && size < 65536)
	{
		//col_wt_ps1 = 0;
		//for (uint32_t i = 0; i < 4; i++)
		//{
		//	if (ps1[i] != 0)
		//		col_wt_ps1++;
		//}
		//if (col_wt_ps1 > 2)
		//	dynamic_bound = -15.0;
		//else
		//	dynamic_bound = -11.0;
		if (ps1[0] != 0 && ps1[3] != 0)
			dynamic_bound = -16.0;
		else
			dynamic_bound = -11.0;
	}
	else if (size >= 65536)
	{
		//col_wt_ps1 = 0;
		//for (uint32_t i = 0; i < 4; i++)
		//{
		//	if (ps1[i] != 0)
		//		col_wt_ps1++;
		//}
		//if (col_wt_ps1 > 2)
		//	dynamic_bound = -9.0;
		//else
		//	dynamic_bound = -9.0;
		if (ps1[0] != 0 && ps1[3] != 0)
			dynamic_bound = -10.0;
		else
			dynamic_bound = -9.0;
	}
	if (ByteToInt(ps1[3], ps1[2], ps1[1], ps1[0]) == 0)
	{
		NoiseOne ht;
		ht.mask[0] = RIIHWT[offset[0]] ^ Rote(RIIHWT[offset[1]], 1) ^ Rote(RIIHWT[offset[2]], 2) ^ Rote(RIIHWT[offset[3]], 3);
		ht.mask[1] = 0;//la
		ht.mask[2] = 0;//ps1
		ht.mask[3] = 0;//lap
		ht.col_cor = 0;
		col_seq.push_back(ht);
	}
	else
	{
		//#pragma omp simd aligned(cor_vec:32)
		//omp_set_num_threads(4);
		//int tid = 0;
#pragma omp parallel for private(tsection,cor_vec)
		for (int32_t i = 0; i < size; i++)
		{
			//tid = omp_get_thread_num();
			uint32_t lap = 0;
			double maxcor = dynamic_bound;
			for (int32_t j = 0; j < 26; j++)
				tsection[j] = 0;
			for (int32_t j = 0; j < 4; j++)
			{
				tsection[8 + j] = ps1[j];//wy
				//since la_input->la, and we restrict true la be la+offset, so that the la_input=ga2->la+offest+offset
				tsection[j] = ExtractByte(la[i], 3 - j) ^ offset[j];//u 20210313//u=la
				tsection[12 + j] = tsection[16 + j] = 0;//base
			}
			for (int32_t j = 0; j < 4; j++)
			{
				if (tsection[j] != 0)//u
				{
					//lsb position byte !-0
					tsection[25] = j;//bytetail
					tsection[20 + j] = TailOne[tsection[j]] + 1;//shift
					break;
				}
			}
			for (int32_t j = 3; j >= 0; j--)
			{
				if (tsection[j] != 0)//u
				{
					//msb position byte !=0
					tsection[24] = j;
					break;
				}
			}
			if (tsection[24] == tsection[25])//mask weight 1
			{
				if (TailOne[tsection[tsection[25]]] < HeadOne[tsection[tsection[24]]])//not ...0001000...
				{
					//base[bytetail] = (1 << TailOne[u[bytetail]]) ^ (1 << HeadOne[u[bytehead]]);
					tsection[12 + tsection[25]] = (1 << TailOne[tsection[tsection[25]]]) ^ (1 << HeadOne[tsection[tsection[24]]]);
					//range[bytetail] = (1 << (HeadOne[u[bytehead]] - TailOne[u[bytetail]] - 1)) - 1;
					tsection[16 + tsection[25]] = (1 << (HeadOne[tsection[tsection[24]]] - TailOne[tsection[tsection[25]]] - 1)) - 1;
				}
				else
				{
					tsection[12 + tsection[25]] = (1 << TailOne[tsection[tsection[25]]]);
					tsection[16 + tsection[25]] = 0;
				}
			}
			else//weight > 1
			{
				for (uint32_t j = 0; j < 4; j++)
				{
					if (j < tsection[25])
					{
						tsection[12 + j] = 0;
						tsection[16 + j] = 0;
					}
					else if (j == tsection[25])
					{
						tsection[12 + j] = (1 << TailOne[tsection[j]]);
						tsection[16 + j] = (1 << (7 - TailOne[tsection[j]])) - 1;
					}
					else if (j > tsection[25] && j < tsection[24])
					{
						tsection[12 + j] = 0;
						tsection[16 + j] = 0xFF;
					}
					else if (j == tsection[24])
					{
						tsection[12 + j] = (1 << HeadOne[tsection[j]]);
						tsection[16 + j] = (1 << HeadOne[tsection[j]]) - 1;
					}
					else
					{
						tsection[12 + j] = 0;
						tsection[16 + j] = 0;
					}
				}
			}

			//if not, here need to be modifying
			//std::array<double, 10> C = { 1,0 };
			__m128d C1 = _mm_set_pd(0, 1.0);
			__m128d C2 = _mm_setzero_pd();
			__m128d C3 = _mm_setzero_pd();
			__m128d C4 = _mm_setzero_pd();
			__m128d C5 = _mm_setzero_pd();

			for (int32_t wx0 = 0; wx0 <= tsection[16]; wx0++)
			{
				tsection[4] = (uint8_t)(tsection[12] ^ (wx0 << tsection[20]));
				//loop
				//cell 0
				C2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(tsection[0], tsection[4], tsection[8])), C1),
					_mm_mul_pd(_mm_load_pd(AS + (Position(tsection[0], tsection[4], tsection[8]) ^ 2)), C1));
				_mm_storeu_pd(cor_vec, C2);
				if (cor_vec[0] + cor_vec[1] != 0)
				{
					if (log2(abs(cor_vec[0] + cor_vec[1])) < maxcor)
						continue;
				}
				else if (cor_vec[0] == 0.0 && cor_vec[1] == 0.0)
					continue;
				for (int32_t wx1 = 0; wx1 <= tsection[17]; wx1++)
				{
					tsection[5] = (uint8_t)(tsection[13] ^ (wx1 << tsection[21]));
					//cell 1
					C3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(tsection[1], tsection[5], tsection[9])), C2),
						_mm_mul_pd(_mm_load_pd(AS + (Position(tsection[1], tsection[5], tsection[9]) ^ 2)), C2));
					_mm_storeu_pd(cor_vec, C3);
					if (cor_vec[0] + cor_vec[1] != 0)
					{
						if (log2(abs(cor_vec[0] + cor_vec[1])) < maxcor)
							continue;
					}
					else if (cor_vec[0] == 0.0 && cor_vec[1] == 0.0)
						continue;
					for (int32_t wx2 = 0; wx2 <= tsection[18]; wx2++)
					{
						tsection[6] = (uint8_t)(tsection[14] ^ (wx2 << tsection[22]));
						//cell 2
						C4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(tsection[2], tsection[6], tsection[10])), C3),
							_mm_mul_pd(_mm_load_pd(AS + (Position(tsection[2], tsection[6], tsection[10]) ^ 2)), C3));
						_mm_storeu_pd(cor_vec, C4);
						if (cor_vec[0] + cor_vec[1] != 0)
						{
							if (log2(abs(cor_vec[0] + cor_vec[1])) < maxcor)
								continue;
						}
						else if (cor_vec[0] == 0.0 && cor_vec[1] == 0.0)
							continue;
						for (int32_t wx3 = 0; wx3 <= tsection[19]; wx3++)
						{
							tsection[7] = (uint8_t)(tsection[15] ^ (wx3 << tsection[23]));
							//cell 3
							//C[8] = AS[Position(u[3], wx3, wy[3]) ^ 0] * C[6] + AS[Position(u[3], wx3, wy[3]) ^ 1] * C[7];
							//C[9] = AS[Position(u[3], wx3, wy[3]) ^ 2] * C[6] + AS[Position(u[3], wx3, wy[3]) ^ 3] * C[7];
							//row1 = _mm_load_pd(AS + Position(u[3], wx3, wy[3]));
							//row2 = _mm_load_pd(AS + Position(u[3], wx3, wy[3]) + 2);
							C5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(tsection[3], tsection[7], tsection[11])), C4),
								_mm_mul_pd(_mm_load_pd(AS + (Position(tsection[3], tsection[7], tsection[11]) ^ 2)), C4));
							_mm_storeu_pd(cor_vec, C5);
							if (cor_vec[0] + cor_vec[1] != 0)
							{
								double cor_exp = log2(abs(cor_vec[0] + cor_vec[1]));
								if (cor_exp > maxcor)
								{
									maxcor = cor_exp;
									lap = ByteToInt(tsection[7], tsection[6], tsection[5], tsection[4]);
								}
							}
						}
					}
				}
			}
			if (lap != 0x00000000)
			{
#pragma omp critical
				{
					NoiseOne ht;
					ht.mask[0] = la_input[i];
					ht.mask[1] = (la[i] ^ ByteToInt(offset[3], offset[2], offset[1], offset[0]));
					ht.mask[2] = ByteToInt(ps1[3], ps1[2], ps1[1], ps1[0]);
					ht.mask[3] = lap;
					ht.col_cor = maxcor;
					col_seq.push_back(ht);
				}
			}
		}
	}
	if (col_seq.size() > 0)
	{
		std::sort(col_seq.begin(), col_seq.end());
		uint32_t scale = (col_seq.size() < PRESERVE_LAMBDA ? col_seq.size() : PRESERVE_LAMBDA);
		for (uint32_t i = 0; i < scale; i++)
		{
			col_seq_scaled.push_back(col_seq[i]);
		}
	}
}
//FourColumns for N1_t
//maskpair:Psi^(2)||Lambda^(2)
void SBoxAddition_FourColumns(double* AS, uint8_t offset[16], uint32_t* mskpair, uint32_t colmod_ga2[4], std::vector<std::vector<NoiseOne> >& four_col_seq)
{
	//maybe used for linear hull 3
	uint8_t ps1[16] = { 0 };
	uint8_t la2[16] = { 0 };
	uint32_t colmod_ps1[4] = { 0 };
	int32_t size[4] = { 0 };
	uint32_t scale[4] = { 0 };
	for (uint8_t i = 0; i < 4; i++)//col
		for (uint8_t j = 0; j < 4; j++)//row
		{
			ps1[(i << 2) + j] = ExtractByte(mskpair[(i + (4 - j)) & 0x3], 3 - j);//shift rows
			//la2[(i << 2) + j] = ExtractByte(mskpair[4 + i], 3 - j);
			if (ps1[(i << 2) + j] != 0)
				colmod_ps1[i] ^= (0x000000FF << (j << 3));
		}
	uint32_t* la = (uint32_t*)calloc(PRUNE_CAPACITY * 4, sizeof(uint32_t));
	uint32_t* la_input = (uint32_t*)calloc(PRUNE_CAPACITY * 4, sizeof(uint32_t));
	std::vector<NoiseOne> tmp;
	if (la != NULL && la_input != NULL)
	{
		LoadLambda_Cac_Offsetmode(colmod_ps1, colmod_ga2, offset, la, la_input, size);
		//printf("Loaded colmod_ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x\n", colmod_ga2[0], colmod_ga2[1], colmod_ga2[2], colmod_ga2[3]);
		printf("No. of candidates of ga2: %d,%d,%d,%d-->", size[0], size[1], size[2], size[3]);
		SBoxAddition_OneColumn_PruneSearch(AS, offset,size[0], ps1, la, la_input, tmp);
		four_col_seq.push_back(tmp);
		scale[0] = tmp.size();
		tmp.clear();
		SBoxAddition_OneColumn_PruneSearch(AS, offset+4, size[1], ps1 + 4, la + PRUNE_CAPACITY, la_input + PRUNE_CAPACITY, tmp);
		four_col_seq.push_back(tmp);
		scale[1] = tmp.size();
		tmp.clear();
		SBoxAddition_OneColumn_PruneSearch(AS, offset+8,size[2], ps1 + 8, la + PRUNE_CAPACITY * 2, la_input + PRUNE_CAPACITY * 2, tmp);
		four_col_seq.push_back(tmp);
		scale[2] = tmp.size();
		tmp.clear();
		SBoxAddition_OneColumn_PruneSearch(AS, offset+12, size[3], ps1 + 12, la + PRUNE_CAPACITY * 3, la_input + PRUNE_CAPACITY * 3, tmp);
		four_col_seq.push_back(tmp);
		scale[3] = tmp.size();
		tmp.clear();
		printf("No. of ga2 column with large bias: %d,%d,%d,%d\n", scale[0], scale[1], scale[2], scale[3]);
	}
	free(la);
	free(la_input);
}

//These functions are used to compute N2_t's correlation
//tweak, outputall, bytediff has minor differences except the last byte of the mask
//bytediff uses byte differential with low Hamming weight(<=2). 
//tweak and outputall use 32-bit word differential with low Hamming weight(<=2)
void DuplicateSBoxAddition_PruneSearch_tweak(double* AS, uint32_t* la, uint32_t* lap, uint32_t* ga2, uint32_t size[4], uint32_t la2[4], double* groupcor, double sigmacor, FILE* fptr)
{
	//each column's potential masks less than 256.
	//if column == 0x00000000 then size=1 !!!
	uint8_t wy[16] = { 0 };
	uint8_t wz[16] = { 0 };
	uint8_t range[4] = { 0 };
	//int32_t dsec[2] = { 0 };
	uint32_t total_maxmask[8] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	double cor_cur_log = 0;
	double cor_sbox_log_sum = 0;
	double col_cor[4] = { 0,0,0,0 };

	for (uint8_t i = 0; i < 4; i++)//col
		for (uint8_t j = 0; j < 4; j++)//row
		{
			wz[(i << 2) + j] = ExtractByte(la2[(i + (4 - j)) & 0x3], 3 - j);//shift rows inverse la2->la1 inverse
		}
	//uint8_t delta[37] = {
	//0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x08,0x09,0x0a,0x0c,0x10,0x11,0x12,0x14,0x18,
	//0x20,0x21,0x22,0x24,0x28,0x30,0x40,0x41,0x42,0x44,0x48,0x50,0x60,0x80,0x81,0x82,
	//0x84,0x88,0x90,0xa0,0xc0};
#pragma omp parallel for collapse(4) private(wy,total_maxmask,col_cor,range,cor_vec,cor_cur_log,cor_sbox_log_sum)
	for (int32_t c0 = 0; c0 < size[0]; c0++)
		for (int32_t c1 = 0; c1 < size[1]; c1++)
			for (int32_t c2 = 0; c2 < size[2]; c2++)
				for (int32_t c3 = 0; c3 < size[3]; c3++)
				{
					//generate msk
					wy[0] = ExtractByte(ga2[c0], 3);//lsb
					wy[4] = ExtractByte(ga2[OFFSET_ga2 + c1], 3);
					wy[8] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 3);
					wy[12] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 3);

					wy[1] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 2);
					wy[5] = ExtractByte(ga2[c0], 2);
					wy[9] = ExtractByte(ga2[OFFSET_ga2 + c1], 2);
					wy[13] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 2);

					wy[2] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 1);
					wy[6] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 1);
					wy[10] = ExtractByte(ga2[c0], 1);
					wy[14] = ExtractByte(ga2[OFFSET_ga2 + c1], 1);

					wy[3] = ExtractByte(ga2[OFFSET_ga2 + c1], 0);
					wy[7] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 0);
					wy[11] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 0);
					wy[15] = ExtractByte(ga2[c0], 0);

					//20200114
					double total_cor = sigmacor + groupcor[c0] + groupcor[OFFSET_ga2 + c1] + groupcor[OFFSET_ga2 * 2 + c2] + groupcor[OFFSET_ga2 * 3 + c3];
					total_maxmask[0] = total_maxmask[1] = total_maxmask[2] = total_maxmask[3] = 0;
					total_maxmask[4] = total_maxmask[5] = total_maxmask[6] = total_maxmask[7] = 0;
					col_cor[0] = col_cor[1] = col_cor[2] = col_cor[3] = 0;
					//dsec[0] = 0;
					//dsec[1] = 32;
					bool flag = false;
					for (int32_t i = 0; i < 4; i++)
					{
						//here need to give base, range,shift for each column 20210106
						//simple than hull3, no HeadOne and TailOne
						//only bytehead and bytetail
						double maxcor = NOISETWO_PRUNEBOUND;
						uint32_t maxmask[2] = { 0 };
						cor_cur_log = 0;
						cor_sbox_log_sum = 0;
						range[0] = range[1] = range[2] = range[3] = 0xFF;
						for (int32_t j = 0; j < 4; j++)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//lsb position byte !=0
								range[j] = 0;
								//dsec[0] = ((j+1)<<3);
							}
							else
								break;
						}
						for (int32_t j = 3; j >= 0; j--)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//msb position byte !=0
								range[j] = 0;
								//dsec[1] = (j << 3);
							}
							else
								break;
						}
						//extend wx
						
						//input mask zero,continue to next column
						bool zeroy = (wy[(i << 2)] == 0 && wy[(i << 2) + 1] == 0 && wy[(i << 2) + 2] == 0 && wy[(i << 2) + 3] == 0);
						bool zeroz = (wz[(i << 2)] == 0 && wz[(i << 2) + 1] == 0 && wz[(i << 2) + 2] == 0 && wz[(i << 2) + 3] == 0);
						if (zeroy || zeroz)
							continue;
						//column0
						__m128d C1 = _mm_set_pd(0, 1.0);
						__m128d C2 = _mm_setzero_pd();
						__m128d C3 = _mm_setzero_pd();
						__m128d C4 = _mm_setzero_pd();
						__m128d C5 = _mm_setzero_pd();

						for (int32_t wx0 = 0; wx0 <= range[0]; wx0++)
						{
							if (AES_SBOX_LAT[wx0][wz[i << 2]] > SBOX_CORRELATION)
							{
								//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]];
								C2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx0, wx0, wy[i << 2])), C1),
									_mm_mul_pd(_mm_load_pd(AS + (Position(wx0, wx0, wy[i << 2]) ^ 2)), C1));
								_mm_store_pd(cor_vec, C2);
								(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]]);
								if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
									continue;
							}
							else
								continue;
							for (int32_t wx1 = 0; wx1 <= range[1]; wx1++)
							{
								//cell 1
								if (AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] > SBOX_CORRELATION)
								{
									//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]]+AES_SBOX_LAT[wx1][wz[(i << 2) + 1]];
									C3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx1, wx1, wy[(i << 2) + 1])), C2),
										_mm_mul_pd(_mm_load_pd(AS + (Position(wx1, wx1, wy[(i << 2) + 1]) ^ 2)), C2));
									_mm_store_pd(cor_vec, C3);
									(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]]);
									if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
										continue;
								}
								else
									continue;
								for (int32_t wx2 = 0; wx2 <= range[2]; wx2++)
								{
									//cell 2
									if (AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] > SBOX_CORRELATION)
									{
										//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]]+AES_SBOX_LAT[wx1][wz[(i << 2) + 1]]+AES_SBOX_LAT[wx2][wz[(i << 2) + 2]];
										C4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx2, wx2, wy[(i << 2) + 2])), C3),
											_mm_mul_pd(_mm_load_pd(AS + (Position(wx2, wx2, wy[(i << 2) + 2]) ^ 2)), C3));
										_mm_store_pd(cor_vec, C4);
										(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]]);
										if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
											continue;
									}
									else
										continue;

									for (int32_t wx3 = 0; wx3 <= range[3]; wx3++)
									{
										//cell 3
										if (AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] > SBOX_CORRELATION)
										{
											//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]]+AES_SBOX_LAT[wx3][wz[(i << 2) + 3]];
											C5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx3, wx3, wy[(i << 2) + 3])), C4),
												_mm_mul_pd(_mm_load_pd(AS + Position(wx3, wx3, wy[(i << 2) + 3]) + 2), C4));
											_mm_store_pd(cor_vec, C5);
											if ((cor_vec[0] + cor_vec[1] != 0))
											{
												cor_cur_log = (AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] + log2(abs(cor_vec[0] + cor_vec[1])));
												//printf("%f,", log2(abs(cor_vec[0] + cor_vec[1])));
												if (cor_cur_log > maxcor)
												{
													maxcor = cor_cur_log;
													maxmask[0] = maxmask[1] = ByteToInt(wx3, wx2, wx1, wx0);
												}
											}
											//20210313 modify to avoid zero correlation
											for (int32_t d = 0; d < DELTA_SIZE; d++)
											{
												__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx0, wx0 ^ ExtractByte(DELTA[d], 3), wy[i << 2])), C1),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx0, wx0 ^ ExtractByte(DELTA[d], 3), wy[i << 2]) ^ 2)), C1));
												__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx1, wx1 ^ ExtractByte(DELTA[d], 2), wy[(i << 2) + 1])), CC2),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx1, wx1 ^ ExtractByte(DELTA[d], 2), wy[(i << 2) + 1]) ^ 2)), CC2));
												__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx2, wx2 ^ ExtractByte(DELTA[d], 1), wy[(i << 2) + 2])), CC3),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx2, wx2 ^ ExtractByte(DELTA[d], 1), wy[(i << 2) + 2]) ^ 2)), CC3));
												__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx3, wx3 ^ ExtractByte(DELTA[d], 0), wy[(i << 2) + 3])), CC4),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx3, wx3 ^ ExtractByte(DELTA[d], 0), wy[(i << 2) + 3]) ^ 2)), CC4));
												_mm_store_pd(cor_vec, CC5);
												if ((cor_vec[0] + cor_vec[1] != 0))
												{
													cor_cur_log = (AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] + log2(abs(cor_vec[0] + cor_vec[1])));
													//printf("%f,", log2(abs(cor_vec[0] + cor_vec[1])));

													if (cor_cur_log > maxcor)
													{
														maxcor = cor_cur_log;
														maxmask[0] = ByteToInt(wx3, wx2, wx1, wx0);
														maxmask[1] = (ByteToInt(wx3, wx2, wx1, wx0) ^ DELTA[d]);
													}
												}

											}

										}
									}
								}
							}
						}
						if (maxmask[0] != 0)
						{
							total_cor += maxcor;
							total_maxmask[i<<1] = maxmask[0];
							total_maxmask[(i<<1)+1] = maxmask[1];
							col_cor[i] = maxcor;

						}
						if (total_cor <= TOTAL_COR_BOUND || (maxmask[0] == 0 && ByteToInt(wy[(i << 2) + 3], wy[(i << 2) + 2], wy[(i << 2) + 1], wy[(i << 2)]) != 0))
						{
							flag = true;
							break;
						}
						
					}
					if (flag == true)
						continue;
					else if (flag == false)
					{
#pragma omp critical
						{
							fprintf(fptr, "la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
								la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
								lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
								total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
								total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
								ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
								ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
								ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], total_cor);
							printf("la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
								la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
								lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
								total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
								total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
								ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
								ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
								ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], total_cor);
						}
					}
				}

}
void DuplicateSBoxAddition_PruneSearch_outputall(double* AS, uint32_t* la, uint32_t* lap, uint32_t* ga2, uint32_t size[4], uint32_t la2[4], double* groupcor, double sigmacor, FILE* fptr, uint64_t& a, uint64_t& b)
{
	//each column's potential masks less than 256.
	//if column == 0x00000000 then size=1 !!!
	uint8_t wy[16] = { 0 };
	uint8_t wz[16] = { 0 };
	uint8_t range[4] = { 0 };
	//int32_t dsec[2] = { 0 };
	uint32_t total_maxmask[8] = { 0 };
	uint64_t suma = 0;
	uint64_t sumb = 0;
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	double cor_cur_log = 0;
	double cor_sbox_log_sum = 0;
	double col_cor[4] = { 0,0,0,0 };
	//double outputbound = -89;
	for (uint8_t i = 0; i < 4; i++)//col
		for (uint8_t j = 0; j < 4; j++)//row
		{
			wz[(i << 2) + j] = ExtractByte(la2[(i + (4 - j)) & 0x3], 3 - j);//shift rows inverse la2->la1 inverse
		}
	//uint8_t delta[37] = {
	//0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x08,0x09,0x0a,0x0c,0x10,0x11,0x12,0x14,0x18,
	//0x20,0x21,0x22,0x24,0x28,0x30,0x40,0x41,0x42,0x44,0x48,0x50,0x60,0x80,0x81,0x82,
	//0x84,0x88,0x90,0xa0,0xc0};
#pragma omp parallel for collapse(4) private(wy,total_maxmask,col_cor,range,cor_vec,cor_cur_log,cor_sbox_log_sum) reduction(+:suma,sumb)
	for (int32_t c0 = 0; c0 < size[0]; c0++)
		for (int32_t c1 = 0; c1 < size[1]; c1++)
			for (int32_t c2 = 0; c2 < size[2]; c2++)
				for (int32_t c3 = 0; c3 < size[3]; c3++)
				{
					//generate msk
					wy[0] = ExtractByte(ga2[c0], 3);//lsb
					wy[4] = ExtractByte(ga2[OFFSET_ga2 + c1], 3);
					wy[8] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 3);
					wy[12] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 3);

					wy[1] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 2);
					wy[5] = ExtractByte(ga2[c0], 2);
					wy[9] = ExtractByte(ga2[OFFSET_ga2 + c1], 2);
					wy[13] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 2);

					wy[2] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 1);
					wy[6] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 1);
					wy[10] = ExtractByte(ga2[c0], 1);
					wy[14] = ExtractByte(ga2[OFFSET_ga2 + c1], 1);

					wy[3] = ExtractByte(ga2[OFFSET_ga2 + c1], 0);
					wy[7] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 0);
					wy[11] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 0);
					wy[15] = ExtractByte(ga2[c0], 0);

					//20200114
					double total_cor = sigmacor + groupcor[c0] + groupcor[OFFSET_ga2 + c1] + groupcor[OFFSET_ga2 * 2 + c2] + groupcor[OFFSET_ga2 * 3 + c3];
					total_maxmask[0] = total_maxmask[1] = total_maxmask[2] = total_maxmask[3] = 0;
					total_maxmask[4] = total_maxmask[5] = total_maxmask[6] = total_maxmask[7] = 0;
					col_cor[0] = col_cor[1] = col_cor[2] = col_cor[3] = 0;
					//dsec[0] = 0;
					//dsec[1] = 32;
					bool flag = false;
					for (int32_t i = 0; i < 4; i++)
					{
						//here need to give base, range,shift for each column 20210106
						//simple than hull3, no HeadOne and TailOne
						//only bytehead and bytetail
						double maxcor = NOISETWO_PRUNEBOUND;
						//uint32_t maxmask[2] = { 0 };
						cor_cur_log = 0;
						cor_sbox_log_sum = 0;
						range[0] = range[1] = range[2] = range[3] = 0xFF;
						for (int32_t j = 0; j < 4; j++)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//lsb position byte !=0
								range[j] = 0;
							}
							else
								break;
						}
						for (int32_t j = 3; j >= 0; j--)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//msb position byte !=0
								range[j] = 0;
							}
							else
								break;
						}
						//extend wx

						//input mask zero,continue to next column
						bool zeroy = (wy[(i << 2)] == 0 && wy[(i << 2) + 1] == 0 && wy[(i << 2) + 2] == 0 && wy[(i << 2) + 3] == 0);
						bool zeroz = (wz[(i << 2)] == 0 && wz[(i << 2) + 1] == 0 && wz[(i << 2) + 2] == 0 && wz[(i << 2) + 3] == 0);
						if (zeroy || zeroz)
							continue;
						//column0
						__m128d C1 = _mm_set_pd(0, 1.0);
						__m128d C2 = _mm_setzero_pd();
						__m128d C3 = _mm_setzero_pd();
						__m128d C4 = _mm_setzero_pd();
						__m128d C5 = _mm_setzero_pd();

						for (int32_t wx0 = 0; wx0 <= range[0]; wx0++)
						{
							if (AES_SBOX_LAT[wx0][wz[i << 2]] > SBOX_CORRELATION)
							{
								//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]];
								C2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx0, wx0, wy[i << 2])), C1),
									_mm_mul_pd(_mm_load_pd(AS + (Position(wx0, wx0, wy[i << 2]) ^ 2)), C1));
								_mm_store_pd(cor_vec, C2);
								(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]]);
								if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
									continue;
							}
							else
								continue;
							for (int32_t wx1 = 0; wx1 <= range[1]; wx1++)
							{
								//cell 1
								if (AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] > SBOX_CORRELATION)
								{
									//cor_sbox_log_sum += AES_SBOX_LAT[wx1][wz[(i << 2) + 1]];
									C3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx1, wx1, wy[(i << 2) + 1])), C2),
										_mm_mul_pd(_mm_load_pd(AS + (Position(wx1, wx1, wy[(i << 2) + 1]) ^ 2)), C2));
									_mm_store_pd(cor_vec, C3);
									(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]]);
									if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
										continue;
								}
								else
									continue;
								for (int32_t wx2 = 0; wx2 <= range[2]; wx2++)
								{
									//cell 2
									if (AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] > SBOX_CORRELATION)
									{
										//cor_sbox_log_sum += AES_SBOX_LAT[wx2][wz[(i << 2) + 2]];
										C4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx2, wx2, wy[(i << 2) + 2])), C3),
											_mm_mul_pd(_mm_load_pd(AS + (Position(wx2, wx2, wy[(i << 2) + 2]) ^ 2)), C3));
										_mm_store_pd(cor_vec, C4);
										(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]]);
										if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
											continue;
									}
									else
										continue;
									for (int32_t wx3 = 0; wx3 <= range[3]; wx3++)
									{
										//cell 3
										if (AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] > SBOX_CORRELATION)
										{
											//20210313 modify to avoid zero correlation
											for (int32_t d = 0; d < DELTA_SIZE; d++)
											{
												__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx0, wx0 ^ ExtractByte(DELTA[d], 3), wy[i << 2])), C1),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx0, wx0 ^ ExtractByte(DELTA[d], 3), wy[i << 2]) ^ 2)), C1));
												__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx1, wx1 ^ ExtractByte(DELTA[d], 2), wy[(i << 2) + 1])), CC2),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx1, wx1 ^ ExtractByte(DELTA[d], 2), wy[(i << 2) + 1]) ^ 2)), CC2));
												__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx2, wx2 ^ ExtractByte(DELTA[d], 1), wy[(i << 2) + 2])), CC3),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx2, wx2 ^ ExtractByte(DELTA[d], 1), wy[(i << 2) + 2]) ^ 2)), CC3));
												__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx3, wx3 ^ ExtractByte(DELTA[d], 0), wy[(i << 2) + 3])), CC4),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx3, wx3 ^ ExtractByte(DELTA[d], 0), wy[(i << 2) + 3]) ^ 2)), CC4));
												_mm_store_pd(cor_vec, CC5);
												if ((cor_vec[0] + cor_vec[1] != 0))
												{
													cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] + log2(abs(cor_vec[0] + cor_vec[1]));
													if (cor_cur_log > maxcor)
														maxcor = cor_cur_log;
													if ((cor_cur_log +total_cor) > TOTAL_COR_BOUND)
													{
														total_maxmask[(i<<1)] = ByteToInt(wx3, wx2, wx1, wx0);
														total_maxmask[(i<<1)+1] = (ByteToInt(wx3, wx2, wx1, wx0) ^ DELTA[d]);
														col_cor[i] = cor_cur_log;
														sumb++;
														if ((cor_cur_log + total_cor) > -89.0)
															suma++;
//#pragma omp critical
//														{
//															fprintf(fptr, "la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,corhull3:%f,%f,%f,%f,sigcor:%f,tcor:%f\n",
//																la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
//																lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
//																total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
//																total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
//																ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
//																ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
//																ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3],
//																groupcor[c0] , groupcor[OFFSET_ga2 + c1] , groupcor[OFFSET_ga2 * 2 + c2] , groupcor[OFFSET_ga2 * 3 + c3],sigmacor,cor_cur_log + total_cor);
//															printf("la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,corhull3:%f,%f,%f,%f,sigcor:%f,tcor:%f\n",
//																la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
//																lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
//																total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
//																total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
//																ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
//																ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
//																ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3],
//																groupcor[c0], groupcor[OFFSET_ga2 + c1], groupcor[OFFSET_ga2 * 2 + c2], groupcor[OFFSET_ga2 * 3 + c3], sigmacor, cor_cur_log + total_cor);
//														}

													}
												}

											}

										}
									}
								}
							}
						}

					}
				}
				a += suma;
				b += sumb;
				printf("%lld,%lld\n", suma, sumb);
	
}
void DuplicateSBoxAddition_PruneSearch_bytediff(double* AS, uint32_t* la, uint32_t* lap, uint32_t* ga2, uint32_t size[4], uint32_t la2[4], double* groupcor, double sigmacor, FILE* fptr)
{
	//each column's potential masks less than 256.
	//if column == 0x00000000 then size=1 !!!
	uint8_t wy[16] = { 0 };
	uint8_t wz[16] = { 0 };
	uint8_t range[4] = { 0 };
	//int32_t dsec[2] = { 0 };
	uint32_t total_maxmask[8] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	double cor_cur_log = 0;
	double cor_sbox_log_sum = 0;
	double col_cor[4] = { 0,0,0,0 };
	double outputbound = -89;
	for (uint8_t i = 0; i < 4; i++)//col
		for (uint8_t j = 0; j < 4; j++)//row
		{
			wz[(i << 2) + j] = ExtractByte(la2[(i + (4 - j)) & 0x3], 3 - j);//shift rows inverse la2->la1 inverse
		}

#pragma omp parallel for collapse(4) private(wy,total_maxmask,col_cor,range,cor_vec,cor_cur_log,cor_sbox_log_sum)
	for (int32_t c0 = 0; c0 < size[0]; c0++)
		for (int32_t c1 = 0; c1 < size[1]; c1++)
			for (int32_t c2 = 0; c2 < size[2]; c2++)
				for (int32_t c3 = 0; c3 < size[3]; c3++)
				{
					//generate msk
					wy[0] = ExtractByte(ga2[c0], 3);//lsb
					wy[4] = ExtractByte(ga2[OFFSET_ga2 + c1], 3);
					wy[8] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 3);
					wy[12] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 3);

					wy[1] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 2);
					wy[5] = ExtractByte(ga2[c0], 2);
					wy[9] = ExtractByte(ga2[OFFSET_ga2 + c1], 2);
					wy[13] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 2);

					wy[2] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 1);
					wy[6] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 1);
					wy[10] = ExtractByte(ga2[c0], 1);
					wy[14] = ExtractByte(ga2[OFFSET_ga2 + c1], 1);

					wy[3] = ExtractByte(ga2[OFFSET_ga2 + c1], 0);
					wy[7] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 0);
					wy[11] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 0);
					wy[15] = ExtractByte(ga2[c0], 0);

					//20200114
					double total_cor = sigmacor + groupcor[c0] + groupcor[OFFSET_ga2 + c1] + groupcor[OFFSET_ga2 * 2 + c2] + groupcor[OFFSET_ga2 * 3 + c3];
					total_maxmask[0] = total_maxmask[1] = total_maxmask[2] = total_maxmask[3] = 0;
					total_maxmask[4] = total_maxmask[5] = total_maxmask[6] = total_maxmask[7] = 0;
					col_cor[0] = col_cor[1] = col_cor[2] = col_cor[3] = 0;
					//dsec[0] = 0;
					//dsec[1] = 32;
					bool flag = false;
					for (int32_t i = 0; i < 4; i++)
					{
						//here need to give base, range,shift for each column 20210106
						//simple than hull3, no HeadOne and TailOne
						//only bytehead and bytetail
						double maxcor = NOISETWO_PRUNEBOUND;
						//uint32_t maxmask[2] = { 0 };
						cor_cur_log = 0;
						cor_sbox_log_sum = 0;
						range[0] = range[1] = range[2] = range[3] = 0xFF;
						for (int32_t j = 0; j < 4; j++)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//lsb position byte !=0
								range[j] = 0;
								//dsec[0] = ((j+1)<<3);
							}
							else
								break;
						}
						for (int32_t j = 3; j >= 0; j--)
						{
							if (wy[(i << 2) + j] == 0)
							{
								//msb position byte !=0
								range[j] = 0;
								//dsec[1] = (j << 3);
							}
							else
								break;
						}
						//extend wx

						//input mask zero,continue to next column
						bool zeroy = (wy[(i << 2)] == 0 && wy[(i << 2) + 1] == 0 && wy[(i << 2) + 2] == 0 && wy[(i << 2) + 3] == 0);
						bool zeroz = (wz[(i << 2)] == 0 && wz[(i << 2) + 1] == 0 && wz[(i << 2) + 2] == 0 && wz[(i << 2) + 3] == 0);
						if (zeroy || zeroz)
							continue;
						//column0
						__m128d C1 = _mm_set_pd(0, 1.0);
						__m128d C2 = _mm_setzero_pd();
						__m128d C3 = _mm_setzero_pd();
						__m128d C4 = _mm_setzero_pd();
						__m128d C5 = _mm_setzero_pd();

						for (int32_t wx0 = 0; wx0 <= range[0]; wx0++)
						{
							if (AES_SBOX_LAT[wx0][wz[i << 2]] <= SBOX_CORRELATION)
								continue;
							else
							{
								for (int32_t d0 = 0; d0 < BYTE_DELTA_SIZE; d0++)
								{
									//cor_sbox_log_sum = AES_SBOX_LAT[wx0][wz[i << 2]];
									C2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx0, (wx0 ^ BYTE_DELTA[d0]), wy[i << 2])), C1),
										_mm_mul_pd(_mm_load_pd(AS + (Position(wx0, (wx0 ^ BYTE_DELTA[d0]), wy[i << 2]) ^ 2)), C1));
									_mm_store_pd(cor_vec, C2);
									(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]]);
									if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
										continue;

									for (int32_t wx1 = 0; wx1 <= range[1]; wx1++)
									{
										//cell 1
										if (AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] <= SBOX_CORRELATION)
											continue;
										else
										{
											for (int32_t d1 = 0; d1 < BYTE_DELTA_SIZE; d1++)
											{
												//cor_sbox_log_sum += AES_SBOX_LAT[wx0][wz[i << 2]]+AES_SBOX_LAT[wx1][wz[(i << 2) + 1]];
												C3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx1, (wx1 ^ BYTE_DELTA[d1]), wy[(i << 2) + 1])), C2),
													_mm_mul_pd(_mm_load_pd(AS + (Position(wx1, (wx1 ^ BYTE_DELTA[d1]), wy[(i << 2) + 1]) ^ 2)), C2));
												_mm_store_pd(cor_vec, C3);
												(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]]);
												if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
													continue;

												for (int32_t wx2 = 0; wx2 <= range[2]; wx2++)
												{
													//cell 2
													if (AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] <= SBOX_CORRELATION)
														continue;
													else
													{
														for (int32_t d2 = 0; d2 < BYTE_DELTA_SIZE; d2++)
														{
															//cor_sbox_log_sum += AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]]+AES_SBOX_LAT[wx2][wz[(i << 2) + 2]];
															C4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx2, (wx2^BYTE_DELTA[d2]), wy[(i << 2) + 2])), C3),
																_mm_mul_pd(_mm_load_pd(AS + (Position(wx2, (wx2 ^ BYTE_DELTA[d2]), wy[(i << 2) + 2]) ^ 2)), C3));
															_mm_store_pd(cor_vec, C4);
															(cor_vec[0] + cor_vec[1] != 0) ? (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + log2(abs(cor_vec[0] + cor_vec[1]))) : (cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]]);
															if (cor_cur_log < maxcor || (cor_vec[0] == 0.0 && cor_vec[1] == 0.0))
																continue;
															for (int32_t wx3 = 0; wx3 <= range[3]; wx3++)
															{
																//cell 3
																if (AES_SBOX_LAT[wx3][wz[(i << 2) + 3]] <= SBOX_CORRELATION)
																	continue;
																else
																{
																	//20210313 modify to avoid zero correlation
																	for (int32_t d3 = 0; d3 < BYTE_DELTA_SIZE; d3++)
																	{
																		C5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(wx3, (wx3 ^BYTE_DELTA[d3]), wy[(i << 2) + 3])), C4),
																			_mm_mul_pd(_mm_load_pd(AS + (Position(wx3, (wx3 ^ BYTE_DELTA[d3]), wy[(i << 2) + 3]) ^ 2)), C4));
																		_mm_store_pd(cor_vec, C5);
																		if ((cor_vec[0] + cor_vec[1] != 0))
																		{
																			cor_cur_log = AES_SBOX_LAT[wx0][wz[i << 2]] + AES_SBOX_LAT[wx1][wz[(i << 2) + 1]] + AES_SBOX_LAT[wx2][wz[(i << 2) + 2]] + AES_SBOX_LAT[wx3][wz[(i << 2) + 3]]+ log2(abs(cor_vec[0] + cor_vec[1]));
																			if (cor_cur_log > maxcor)
																				maxcor = cor_cur_log;
																			if ((cor_cur_log + total_cor) > TOTAL_COR_BOUND)
																			{
																				total_maxmask[(i << 1)] = ByteToInt(wx3, wx2, wx1, wx0);
																				total_maxmask[(i << 1) + 1] = (ByteToInt(wx3 ^ BYTE_DELTA[d3], wx2 ^ BYTE_DELTA[d2], wx1 ^ BYTE_DELTA[d1], wx0 ^ BYTE_DELTA[d0]));
																				col_cor[i] = cor_cur_log;
#pragma omp critical
																				{
																					fprintf(fptr, "la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
																						la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
																						lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
																						total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
																						total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
																						ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
																						ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
																						ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], cor_cur_log + total_cor);
																					printf("la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
																						la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
																						lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
																						total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
																						total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
																						ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
																						ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
																						ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], cor_cur_log + total_cor);
																			}

																			}
																		}

																	}

																}
															}

														}
													}

												}

											}
										}

									}

								}
							}
						}

					}
				}
}
//Try to find good linear approximation with Nyberg recursive method
void DuplicateSBoxAddition_PruneSearch_recursive(double* AS, uint32_t* la, uint32_t* lap, uint32_t* ga2, uint32_t size[4], uint32_t la2[4], double* groupcor, double sigmacor, FILE* fptr)
{
	//each column's potential masks less than 256.
	//if column == 0x00000000 then size=1 !!!
	uint8_t wy[16] = { 0 };
	uint8_t wz[16] = { 0 };
	uint8_t gap[16] = { 0 };
	uint8_t ga[16] = { 0 };
	uint8_t range[4] = { 0 };
	int32_t zsize[16] = { 0 };
	uint32_t total_maxmask[8] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	double cor_cur_log = 0;
	double cor_sbox_log_sum = 0;
	double col_cor[4] = { 0,0,0,0 };

	for (uint8_t i = 0; i < 4; i++)//col
		for (uint8_t j = 0; j < 4; j++)//row
		{
			wz[(i << 2) + j] = ExtractByte(la2[(i + (4 - j)) & 0x3], 3 - j);//shift rows inverse la2->la1 inverse
			if (wz[(i << 2) + j] != 0)
				zsize[(i << 2) + j] = MAXPOINT_SIZE;
			else
				zsize[(i << 2) + j] = 1;
		}

#pragma omp parallel for collapse(4) private(wy,total_maxmask,col_cor,range,cor_vec,cor_cur_log,cor_sbox_log_sum,gap,ga)
	for (int32_t c0 = 0; c0 < size[0]; c0++)
		for (int32_t c1 = 0; c1 < size[1]; c1++)
			for (int32_t c2 = 0; c2 < size[2]; c2++)
				for (int32_t c3 = 0; c3 < size[3]; c3++)
				{
					//generate msk
					wy[0] = ExtractByte(ga2[c0], 3);//lsb
					wy[4] = ExtractByte(ga2[OFFSET_ga2 + c1], 3);
					wy[8] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 3);
					wy[12] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 3);

					wy[1] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 2);
					wy[5] = ExtractByte(ga2[c0], 2);
					wy[9] = ExtractByte(ga2[OFFSET_ga2 + c1], 2);
					wy[13] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 2);

					wy[2] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 1);
					wy[6] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 1);
					wy[10] = ExtractByte(ga2[c0], 1);
					wy[14] = ExtractByte(ga2[OFFSET_ga2 + c1], 1);

					wy[3] = ExtractByte(ga2[OFFSET_ga2 + c1], 0);
					wy[7] = ExtractByte(ga2[OFFSET_ga2 * 2 + c2], 0);
					wy[11] = ExtractByte(ga2[OFFSET_ga2 * 3 + c3], 0);
					wy[15] = ExtractByte(ga2[c0], 0);

					//once wy and wz generated do 4 columns

					//20210114
					double total_cor = sigmacor + groupcor[c0] + groupcor[OFFSET_ga2 + c1] + groupcor[OFFSET_ga2 * 2 + c2] + groupcor[OFFSET_ga2 * 3 + c3];
					total_maxmask[0] = total_maxmask[1] = total_maxmask[2] = total_maxmask[3] = 0;
					col_cor[0] = col_cor[1] = col_cor[2] = col_cor[3] = 0;
					bool flag = false;
					std::vector<uint64_t> maskrecur0, maskrecur1;
					for (int32_t i = 0; i < 4; i++)
					{
						//range
						for (int32_t j = 0; j < 4; j++)
						{
							if (wy[(i << 2) + j] == 0)
								range[j] = 0;
							else
								range[j] = MAXPOINT_SIZE - 1;//size of linear mask with correlation >-4
						}
						double maxcor = NOISETWO_PRUNEBOUND;
						uint32_t maxmask[2] = { 0 };
						cor_cur_log = 0;
						cor_sbox_log_sum = 0;

						if (ByteToInt(wy[(i << 2) + 3], wy[(i << 2) + 2], wy[(i << 2) + 1], wy[(i << 2)]) == 0)
							continue;
						else
						{
							for (int32_t w0 = 0; w0 <= range[0]; w0++)
								for (int32_t w1 = 0; w1 <= range[1]; w1++)
									for (int32_t w2 = 0; w2 <= range[2]; w2++)
										for (int32_t w3 = 0; w3 <= range[3]; w3++)
										{
											uint8_t wypfix[32] = { 0 };
											for (int32_t j = 0; j < 8; j++)
											{
												wypfix[j] = ((MAXPOINT_AESINV[wy[(i << 2)]][w0] >> j) & 1);
												wypfix[8 + j] = ((MAXPOINT_AESINV[wy[(i << 2)] + 1][w1] >> j) & 1);
												wypfix[16 + j] = ((MAXPOINT_AESINV[wy[(i << 2)] + 2][w2] >> j) & 1);
												wypfix[24 + j] = ((MAXPOINT_AESINV[wy[(i << 2)] + 3][w3] >> j) & 1);
											}
											for (int32_t k = 1; k < 5; k++)
											{
												GenerateTwoInputsLinearMasks_Binary_0(32, k, wypfix, wz + (i << 2), zsize + (i << 2), maskrecur0);
												GenerateTwoInputsLinearMasks_Binary_1(32, k, wypfix, wz + (i << 2), zsize + (i << 2), maskrecur1);
												if (maskrecur0.empty() == false || maskrecur1.empty() == false)
												{
													break;
												}
											}
											for (auto e : maskrecur0)
											{
												ga[0] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 3);
												ga[1] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 2);
												ga[2] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 1);
												ga[3] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 0);

												gap[0] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 3);
												gap[1] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 2);
												gap[2] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 1);
												gap[3] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 0);

												__m128d CC1 = _mm_set_pd(0, 1.0);
												__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2)], gap[(i << 2)], wy[i << 2])), CC1),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2)], gap[(i << 2)], wy[i << 2]) ^ 2)), CC1));
												__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 1], gap[(i << 2) + 1], wy[(i << 2) + 1])), CC2),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 1], gap[(i << 2) + 1], wy[(i << 2) + 1]) ^ 2)), CC2));
												__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 2], gap[(i << 2) + 2], wy[(i << 2) + 2])), CC3),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 2], gap[(i << 2) + 2], wy[(i << 2) + 2]) ^ 2)), CC3));
												__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 3], gap[(i << 2) + 3], wy[(i << 2) + 3])), CC4),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 3], gap[(i << 2) + 3], wy[(i << 2) + 3]) ^ 2)), CC4));
												_mm_store_pd(cor_vec, CC5);
												if ((cor_vec[0] + cor_vec[1] != 0))
												{
													cor_cur_log = log2(abs(cor_vec[0] + cor_vec[1])) + AES_SBOX_LAT[gap[(i << 2)]][wz[i << 2]] + AES_SBOX_LAT[gap[(i << 2) + 1]][wz[(i << 2) + 1]] + AES_SBOX_LAT[gap[(i << 2) + 2]][wz[(i << 2) + 2]] + AES_SBOX_LAT[gap[(i << 2) + 3]][wz[(i << 2) + 3]];
													if (cor_cur_log > maxcor)
													{
														maxcor = cor_cur_log;
														maxmask[0] = (uint32_t)((e >> 32) & 0xFFFFFFFF);//u:ga
														maxmask[1] = (uint32_t)(e & 0xFFFFFFFF);//wx gap
													}
												}

											}
											for (auto e : maskrecur1)
											{
												ga[0] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 3);
												ga[1] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 2);
												ga[2] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 1);
												ga[3] = ExtractByte((uint32_t)((e >> 32) & 0xFFFFFFFF), 0);

												gap[0] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 3);
												gap[1] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 2);
												gap[2] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 1);
												gap[3] = ExtractByte((uint32_t)(e & 0xFFFFFFFF), 0);

												__m128d CC1 = _mm_set_pd(0, 1.0);
												__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2)], gap[(i << 2)], wy[i << 2])), CC1),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2)], gap[(i << 2)], wy[i << 2]) ^ 2)), CC1));
												__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 1], gap[(i << 2) + 1], wy[(i << 2) + 1])), CC2),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 1], gap[(i << 2) + 1], wy[(i << 2) + 1]) ^ 2)), CC2));
												__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 2], gap[(i << 2) + 2], wy[(i << 2) + 2])), CC3),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 2], gap[(i << 2) + 2], wy[(i << 2) + 2]) ^ 2)), CC3));
												__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(ga[(i << 2) + 3], gap[(i << 2) + 3], wy[(i << 2) + 3])), CC4),
													_mm_mul_pd(_mm_load_pd(AS + (Position(ga[(i << 2) + 3], gap[(i << 2) + 3], wy[(i << 2) + 3]) ^ 2)), CC4));
												_mm_store_pd(cor_vec, CC5);
												if ((cor_vec[0] + cor_vec[1] != 0))
												{
													cor_cur_log = log2(abs(cor_vec[0] + cor_vec[1])) + AES_SBOX_LAT[gap[(i << 2)]][wz[i << 2]] + AES_SBOX_LAT[gap[(i << 2) + 1]][wz[(i << 2) + 1]] + AES_SBOX_LAT[gap[(i << 2) + 2]][wz[(i << 2) + 2]] + AES_SBOX_LAT[gap[(i << 2) + 3]][wz[(i << 2) + 3]];
													if (cor_cur_log > maxcor)
													{
														maxcor = cor_cur_log;
														maxmask[0] = ((e >> 32) & 0xFFFFFFFF);//u:ga
														maxmask[1] = (e & 0xFFFFFFFF);//wx gap
													}
												}

											}
											maskrecur0.clear();
											maskrecur1.clear();

										}
							if (maxmask[0] != 0)
							{
								total_cor += maxcor;
								total_maxmask[i << 1] = maxmask[0];
								total_maxmask[(i << 1) + 1] = maxmask[1];
								col_cor[i] = maxcor;

							}
							if (total_cor <= TOTAL_COR_BOUND || (maxmask[0] == 0 && ByteToInt(wy[(i << 2) + 3], wy[(i << 2) + 2], wy[(i << 2) + 1], wy[(i << 2)]) != 0))
							{
								flag = true;
								break;
							}
						}
					}
					if (flag == true)
						continue;
					else if (flag == false)
					{
#pragma omp critical
						{
							fprintf(fptr, "la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
								la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
								lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
								total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
								total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
								ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
								ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
								ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], total_cor);
							printf("la:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,lap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,ga:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,gap:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la1:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, ga2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x, la2:0x%8.8x,0x%8.8x,0x%8.8x,0x%8.8x,colcor:%f,%f,%f,%f,tcor:%f\n",
								la[c0], la[c1 + OFFSET_ga2], la[c2 + OFFSET_ga2 * 2], la[c3 + OFFSET_ga2 * 3],
								lap[c0], lap[c1 + OFFSET_ga2], lap[c2 + OFFSET_ga2 * 2], lap[c3 + OFFSET_ga2 * 3],
								total_maxmask[0], total_maxmask[2], total_maxmask[4], total_maxmask[6],
								total_maxmask[1], total_maxmask[3], total_maxmask[5], total_maxmask[7],
								ByteToInt(wy[3], wy[2], wy[1], wy[0]), ByteToInt(wy[7], wy[6], wy[5], wy[4]), ByteToInt(wy[11], wy[10], wy[9], wy[8]), ByteToInt(wy[15], wy[14], wy[13], wy[12]),
								ByteToInt(wz[3], wz[2], wz[1], wz[0]), ByteToInt(wz[7], wz[6], wz[5], wz[4]), ByteToInt(wz[11], wz[10], wz[9], wz[8]), ByteToInt(wz[15], wz[14], wz[13], wz[12]),
								ga2[c0], ga2[c1 + OFFSET_ga2], ga2[c2 + OFFSET_ga2 * 2], ga2[c3 + OFFSET_ga2 * 3], la2[0], la2[1], la2[2], la2[3], col_cor[0], col_cor[1], col_cor[2], col_cor[3], total_cor);
						}
					}
				}

}

//given a mask tuple, compute N1_t's correlation
double EvaluateSboxAdditionCorrelation(double* AS, uint8_t u[4], uint8_t wx[4], uint8_t wy[4])
{
	//addtional 4 parallel sbxes
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	__m128d CC1 = _mm_set_pd(0, 1.0);
	__m128d TT = _mm_load_pd(AS + Position(u[3], wx[3], wy[3]));
	__m128d TTT = _mm_load_pd(AS + (Position(u[3], wx[3], wy[3]) ^ 2));
	__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[0], wx[0], wy[0])), CC1),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[0], wx[0], wy[0]) ^ 2)), CC1));
	__m128d CC3 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[1], wx[1], wy[1])), CC2),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[1], wx[1], wy[1]) ^ 2)), CC2));
	__m128d CC4 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[2], wx[2], wy[2])), CC3),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[2], wx[2], wy[2]) ^ 2)), CC3));
	__m128d CC5 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[3], wx[3], wy[3])), CC4),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[3], wx[3], wy[3]) ^ 2)), CC4));
	_mm_store_pd(cor_vec, CC5);
	return cor_vec[0] + cor_vec[1];
}
double EvaluateSboxAdditionCorrelationOne(double* AS, uint8_t u[4], uint8_t wx[4], uint8_t wy[4])
{
	//addtional 4 parallel sbxes
	STATIC_CACHE_ALIGN_AVX2 double cor_vec[2] = { 0 };
	__m128d CC1 = _mm_set_pd(0, 1.0);
	__m128d CC2 = _mm_hadd_pd(_mm_mul_pd(_mm_load_pd(AS + Position(u[0], wx[0], wy[0])), CC1),
		_mm_mul_pd(_mm_load_pd(AS + (Position(u[0], wx[0], wy[0]) ^ 2)), CC1));
	_mm_store_pd(cor_vec, CC2);
	return cor_vec[0] + cor_vec[1];
}

//compute FSM's correlation
//including two steps
//step 1 corresponds to N3_t, the results have already been put into maskpair,sigcor,offset
//step 2 corresponds to N1_t and N3_t
void ComputeNoisesCorrelation()
{
	//step 1 compute all sigma-addition with input output mask be in speical form
	//store the mask with correlatioin vaule >=15.0
	
	FILE* ofs = fopen("sigmaaddition_maskcor_16_verify.txt", "w");
	if (ofs != NULL)
	{
		uint8_t u[16] = { 0 }, wb[16] = { 0 };
		uint32_t ctr = 0;
		uint32_t VAL = 0xe;
		//uint8_t delta[163] = {
		//	0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,
		//	0x10,0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1a,0x1b,0x1c,0x1d,0x1e,0x20,
		//	0x21,0x22,0x23,0x24,0x25,0x26,0x27,0x28,0x29,0x2a,0x2b,0x2c,0x2d,0x2e,0x30,0x31,
		//	0x32,0x33,0x34,0x35,0x36,0x38,0x39,0x3a,0x3c,0x40,0x41,0x42,0x43,0x44,0x45,0x46,
		//	0x47,0x48,0x49,0x4a,0x4b,0x4c,0x4d,0x4e,0x50,0x51,0x52,0x53,0x54,0x55,0x56,0x58,
		//	0x59,0x5a,0x5c,0x60,0x61,0x62,0x63,0x64,0x65,0x66,0x68,0x69,0x6a,0x6c,0x70,0x71,
		//	0x72,0x74,0x78,0x80,0x81,0x82,0x83,0x84,0x85,0x86,0x87,0x88,0x89,0x8a,0x8b,0x8c,
		//	0x8d,0x8e,0x90,0x91,0x92,0x93,0x94,0x95,0x96,0x98,0x99,0x9a,0x9c,0xa0,0xa1,0xa2,
		//	0xa3,0xa4,0xa5,0xa6,0xa8,0xa9,0xaa,0xac,0xb0,0xb1,0xb2,0xb4,0xb8,0xc0,0xc1,0xc2,
		//	0xc3,0xc4,0xc5,0xc6,0xc8,0xc9,0xca,0xcc,0xd0,0xd1,0xd2,0xd4,0xd8,0xe0,0xe1,0xe2,
		//	0xe4,0xe8,0xf0 };
		for (uint8_t col = 0; col < 4; col++)//column
			for (int32_t x = VAL; x < VAL+1; x++)//xvalue maybe 0x0e is the best one
			{
				for (uint8_t c = 0; c < 4; c++)
					for (uint8_t r = 0; r < 4; r++)
					{
						u[(((c + col) & 3) << 2) + r] = ExtractByte(Rote(NDBE[x], (4 - c) & 3), 3 - r);
						wb[(((c + col) & 3) << 2) + r] = ExtractByte(Rote(NDBE[x], (4 - c) & 3), 3 - r);
					}
				//20211006
				for (int32_t y0 = 0; y0 < BYTE_DELTA_SIZE; y0++)//change value
					for (int32_t y1 = 0; y1 < BYTE_DELTA_SIZE; y1++)//change value
						for (int32_t y2 = 0; y2 < BYTE_DELTA_SIZE; y2++)//change value
							for (int32_t y3 = 0; y3 < BYTE_DELTA_SIZE; y3++)//change value
							{
								wb[col] = (u[col] ^ BYTE_DELTA[y0]);
								wb[col + 4] = (u[col + 4] ^ BYTE_DELTA[y1]);
								wb[col + 8] = (u[col + 8] ^ BYTE_DELTA[y2]);
								wb[col + 12] = (u[col + 12] ^ BYTE_DELTA[y3]);
								std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
								SliceFourMask(u, u, wb, u, 4, z);
								//Algorithm 2
								double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);
								if (log2(abs(cor)) >= -43.0)
								{
									fprintf(ofs, "col:%d,x:0x%2.2x: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,%f\n", 
										col, x, wb[0], wb[4], wb[8], wb[12], wb[1], wb[5], wb[9], wb[13], wb[2], wb[6], wb[10], wb[14], wb[3], wb[7], wb[11], wb[15], log2(abs(cor)));
									printf("col:%d,x:0x%2.2x: 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,%f\n",
										col, x, wb[0], wb[4], wb[8], wb[12], wb[1], wb[5], wb[9], wb[13], wb[2], wb[6], wb[10], wb[14], wb[3], wb[7], wb[11], wb[15], log2(abs(cor)));
									fprintf(ofs, "0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x, 0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x,%f\n",
										u[0], u[1], u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9], u[10], u[11], u[12], u[13], u[14], u[15]);
								}
							}
			}
		fclose(ofs);
	}
	/*
	////step 2 for each of the sigma-addition input and output mask
	////good linear approximations given by Algorithm 2
	uint32_t maskpair[TOTAL_MASK_NUM * 8] ={
		//col0 0xe
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,
		//col1
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,
		//col2
		0x000e0000,0x00000e00,0x0000000e,0x0e000000,0x000e0000,0x00000e00,0x0000000e,0x0e000000,
		//col3
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e, 0x0e000000, 0x000e0000, 0x00000e00, 0x0000000e,
		};
	double sigmacor[TOTAL_MASK_NUM] = {
		//col0 0xe
		-42.517326,	-41.278105,	-42.599857,	-41.581025,	-42.674567,	-42.977449,	-42.734941,	-41.734941,
		-42.661036,	-42.881303,	-42.671070,	-42.973997,	-42.282396,	-42.585317,	-42.739227,	-42.521586,
		-41.282396,	-42.604149,	-41.585317,	-42.678859,	-42.981741,	-42.739227,	-41.739227,	-42.665322,
		-42.885588,	-42.674293,	-42.977220,	-42.280245,	-42.583166,	-42.737079,
		//col1 
		-41.127008,	-42.448876,	-42.519329,	-42.126870,	-42.448801,	-42.519381,	-42.342862,	-41.342862,
		-42.664730,	-42.735183,	-42.342724,	-42.664655,	-42.735148,	-42.195469,
		//col2
		-42.700861,
		//col3
		-40.443730,	-41.765658,	-42.836051,	-41.836051,	-42.443730,	-42.765658,	-41.443730,	-42.765658,
		-41.765658,	-42.836080,	-41.836080,	-42.836080,	-42.734430,	-41.888349,	-42.888349,
	};
	uint32_t colmod_ga2[TOTAL_MASK_NUM * 4] = {
		//col0 0xe
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
		0x000000FF, 0xFF000000, 0x00FF0000, 0x0000FF00,
	//col1
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
		0x0000FF00, 0x000000FF, 0xFF000000, 0x00FF0000,
	//col2
		0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000,
	//col3
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF,
	};
	uint8_t offset[TOTAL_MASK_NUM*16] = {
		//col0 18
		0x05,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x0c,0x0d, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x0a,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x0a,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x4c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x8c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x8c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x08,0x8c,0x0a, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x0e,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x05,0x0e,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x04,0x08,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x04,0x08,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x04,0x08,0x8c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0c,0x0d, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0a,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x0a,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x4c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x8c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x8c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x08,0x8c,0x0a, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x0e,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x07,0x0e,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x06,0x08,0x0c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x06,0x08,0x0c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		0x06,0x08,0x8c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c,
		//col1 14
		0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0c,0x09, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0a,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x05,0x08,0x8c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x05,0x08,0x8c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x05,0x0e,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x04,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x08,0x0c,0x09, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x08,0x0a,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x08,0x8c,0x0e, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x08,0x8c,0x0b, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x07,0x0e,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		0x0f,0x05,0x08,0x0c, 0x06,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08,
		//col2 1
		0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x07,0x08,0x0c,0x0f, 0x08,0x0c,0x0f,0x05,	
		//col3 15
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0c,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0c,0x09,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x09,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x0a,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x4c,0x0e,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x4c,0x0b,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x8c,0x0e,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x8c,0x0d,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x08,0x8c,0x0b,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x0d,0x0c,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x0e,0x0c,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x05,0x0e,0x8c,0x0e,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x07,0x08,0x0c,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x06,0x08,0x0c,0x0f,
		0x08,0x0c,0x0f,0x05, 0x0c,0x0f,0x05,0x08, 0x0f,0x05,0x08,0x0c, 0x06,0x08,0x8c,0x0e,
	};
	*/
	/*
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	FILE* hsptr = fopen("HullSbox_maskwithmaxtotalcor_16.txt", "w");
	if (fptr != NULL && hsptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		std::vector<std::vector<NoiseOne> > la_candidates;
		for (uint32_t i = 0; i < 1; i++)//which group
		//for (uint32_t i = 0; i < TOTAL_MASK_NUM; i++)
		{
			uint32_t group_size[4] = { 0 };
			uint32_t group_mask[OFFSET_ga2 * 4*4] = { 0 };
			uint32_t group_ga2[OFFSET_ga2 * 4] = { 0 };
			uint32_t group_lap[OFFSET_ga2 * 4] = { 0 };
			uint32_t group_la[OFFSET_ga2 * 4] = { 0 };
			double group_cor[OFFSET_ga2 * 4] = { 0 };
			FILE* mptr, * cptr, * hptr;
			
			mptr = fopen("Hull3_mask_col0123_16.dat", "wb");
			cptr = fopen("Hull3_size_col0123_16.dat", "wb");
			hptr = fopen("Hull3_cor_col0123_16.dat", "wb");
			if (mptr == NULL || cptr == NULL || hptr == NULL)
				printf("file can't open");
			else
			{
				SBoxAddition_FourColumns(AS, offset + i * 16, maskpair + (i << 3), colmod_ga2 + (i << 2), la_candidates);
				if (la_candidates.empty() == false)
				{
					for (uint32_t u = 0; u < 4; u++)
					{
						if (la_candidates[u].empty())
							group_size[u] = 0;
						else
							group_size[u] = la_candidates[u].size();
						for (uint32_t j = 0; j < group_size[u]; j++)
						{
							fwrite(la_candidates[u][j].mask, sizeof(uint32_t), 4, mptr);
							fwrite(&(la_candidates[u][j].col_cor), sizeof(double), 1, hptr);
						}
					}
					fwrite(group_size, sizeof(uint32_t), 4, cptr);
				}
				fclose(mptr);
				fclose(cptr);
				fclose(hptr);
			}
			
			
			mptr = fopen("Hull3_mask_col0123_16.dat", "rb");
			cptr = fopen("Hull3_size_col0123_16.dat", "rb");
			hptr = fopen("Hull3_cor_col0123_16.dat", "rb");
			if (mptr == NULL || cptr == NULL || hptr == NULL)
				printf("file can't open");
			else
			{
				fread(group_size, sizeof(uint32_t), 4, cptr);
				for (uint32_t j = 0; j < 4; j++)
				{
					fread(group_mask + OFFSET_ga2 * j * 4, sizeof(uint32_t), group_size[j] * 4, mptr);
					fread(group_cor + OFFSET_ga2 * j, sizeof(double), group_size[j], hptr);
				}
				for (uint32_t u = 0; u < 4; u++)
					for (uint32_t v = 0; v < group_size[u]; v++)
					{
						//group_ga2[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[0];
						//group_la[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[1];
						//group_lap[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[3];
						//group_cor[OFFSET_ga2 * u + v] = la_candidates[u][v].col_cor;
						group_ga2[OFFSET_ga2 * u + v] = group_mask[OFFSET_ga2 * u * 4 + 4*v];
						group_la[OFFSET_ga2 * u + v] = group_mask[OFFSET_ga2 * u * 4 + 4 * v+1];
						group_lap[OFFSET_ga2 * u + v] = group_mask[OFFSET_ga2 * u * 4 + 4 * v+3];
					}
				DuplicateSBoxAddition_PruneSearch_outputall(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr);//
				//DuplicateSBoxAddition_PruneSearch_bytediff(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr);//
				//DuplicateSBoxAddition_PruneSearch_tweak(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr);//
				//la_candidates.clear();
				fclose(mptr);
				fclose(cptr);
				fclose(hptr);
			}
			
		}
		fclose(hsptr);
		fclose(fptr);
		_mm_free(AS);
	}
	*/
	/*
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	//A file stores all connection matrices for Algorithm 1, i.e., N1_t and N2_t
	//all connection matrices could be generated by "PreComConectionMatrix"
	FILE * fptr = fopen("SBox addition connection matrix.dat", "rb");
	FILE* hsptr = fopen("HullSbox_maskwithmaxtotalcor_16.txt", "w");
	if (fptr != NULL && hsptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		std::vector<std::vector<NoiseOne> > la_candidates;
		uint64_t totala = 0, totalb = 0;
		for (uint32_t i = 0; i < 60; i++)//which group
		//for (uint32_t i = 55; i < 60; i++)
		{
			uint32_t group_size[4] = { 0 };
			uint32_t group_mask[OFFSET_ga2 * 4 * 4] = { 0 };
			uint32_t group_ga2[OFFSET_ga2 * 4] = { 0 };
			uint32_t group_lap[OFFSET_ga2 * 4] = { 0 };
			uint32_t group_la[OFFSET_ga2 * 4] = { 0 };
			double group_cor[OFFSET_ga2 * 4] = { 0 };

			SBoxAddition_FourColumns(AS, offset + i * 16, maskpair + (i << 3), colmod_ga2 + (i << 2), la_candidates);
			if (la_candidates.empty() == false)
			{
				for (uint32_t u = 0; u < 4; u++)
				{
					if (la_candidates[u].empty())
						group_size[u] = 0;
					else
						group_size[u] = la_candidates[u].size();
				}
			}
			for (uint32_t u = 0; u < 4; u++)
				for (uint32_t v = 0; v < group_size[u]; v++)
				{
					group_ga2[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[0];
					group_la[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[1];
					group_lap[OFFSET_ga2 * u + v] = la_candidates[u][v].mask[3];
					group_cor[OFFSET_ga2 * u + v] = la_candidates[u][v].col_cor;
				}
			//DuplicateSBoxAddition_PruneSearch_tweak(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr);//
			DuplicateSBoxAddition_PruneSearch_outputall(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr,totala,totalb);//
			//DuplicateSBoxAddition_PruneSearch_bytediff(AS, group_la, group_lap, group_ga2, group_size, maskpair + (i << 3) + 4, group_cor, sigmacor[i], hsptr);//

			la_candidates.clear();
		}
		printf("%lld,%lld\n", totala, totalb);
		fclose(hsptr);
		fclose(fptr);
		_mm_free(AS);
	}
	*/
	/*
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	if (fptr != NULL && AS != NULL)
	{
		//summation all y
		fread(AS, sizeof(double), 1 << 26, fptr);
		uint8_t psi1[4] = { 0xe,0xe, 0xe, 0xe };
		uint8_t la1[4] = { 0xe,0xe, 0xe, 0xe };
		for (int16_t i = 0; i < 1; i++)
		{
			//get sigmacor
			//double cor = sigmacor[45];
			uint8_t lap[4] = { 0 };
			uint8_t lam[4] = { 0 };
			uint8_t ga[4] = { 0 };
			uint8_t gap[4] = { 0 };
			uint8_t ga1[4] = { 0 };

			lap[0] = ExtractByte(alllap_19[(i << 2) + 3], 3);
			lap[1] = ExtractByte(alllap_19[(i << 2) + 3], 2);
			lap[2] = ExtractByte(alllap_19[(i << 2) + 3], 1);
			lap[3] = ExtractByte(alllap_19[(i << 2) + 3], 0);
			//lap[0] = 0x09;
			//lap[1] = 0x58;
			//lap[2] = 0x4d;
			//lap[3] = 0x31;

			gap[0] = ExtractByte(allgap_19[(i << 2) + 3], 3);
			gap[1] = ExtractByte(allgap_19[(i << 2) + 3], 2);
			gap[2] = ExtractByte(allgap_19[(i << 2) + 3], 1);
			gap[3] = ExtractByte(allgap_19[(i << 2) + 3], 0);
			//gap[0] = 0x02;
			//gap[1] = 0x30;
			//gap[2] = 0xb3;
			//gap[3] = 0x0d;
			ga[0] = ExtractByte(allga_19[(i << 2) + 3], 3);
			ga[1] = ExtractByte(allga_19[(i << 2) + 3], 2);
			ga[2] = ExtractByte(allga_19[(i << 2) + 3], 1);
			ga[3] = ExtractByte(allga_19[(i << 2) + 3], 0);
			//ga[0] = 0x02;
			//ga[1] = 0x20;
			//ga[2] = 0xb3;
			//ga[3] = 0x09;

			uint8_t la[4] = { 0 };
			double sign = 1;
			double total_cor = 0;
			//compute hull three
			for (uint16_t y = 0x1; y < 256; y++)
			{
				//4-th column
				la[0] = (ExtractByte(NDBE[y], 3) ^ offset[45 * 16 + 12]);
				la[1] = (ExtractByte(NDBE[y], 2) ^ offset[45 * 16 + 13]);
				la[2] = (ExtractByte(NDBE[y], 1) ^ offset[45 * 16 + 14]);
				la[3] = (ExtractByte(NDBE[y], 0) ^ offset[45 * 16 + 15]);
				//la[0] = 0x0d;
				//la[1] = 0xf0;
				//la[2] = 0x49;
				//la[3] = 0x21;
				printf("%2.2x:", y);
				printf("offset:(0x%2.2x,0x%2.2x,0x%2.2x,0x%2.2x)", offset[45 * 16 + 12], offset[45 * 16 + 13], offset[45 * 16 + 14], offset[45 * 16 + 15]);
				printf("La:0x%8.8x,", ByteToInt(la[3], la[2], la[1], la[0]));
				//ga1[0] = (y & 0xff);
				ga1[0] = 0x1c;
				ga1[1] = 0xe;
				ga1[2] = 0xe;
				ga1[3] = 0xe;
				double cor1 = EvaluateSboxAdditionCorrelation(AS, la, lap, psi1);
				double cor2 = EvaluateSboxAdditionCorrelation(AS, ga, gap, ga1);
				double cors0 = 2 * AES_SBOX_BIAS[ga[0]][la1[0]];
				double cors1 = 2 * AES_SBOX_BIAS[ga[1]][la1[1]];
				double cors2 = 2 * AES_SBOX_BIAS[ga[2]][la1[2]];
				double cors3 = 2 * AES_SBOX_BIAS[ga[3]][la1[3]];
				printf("%f,%f,%f,", log2(abs(cor1)),log2(abs(cor2)),log2(abs(cors0* cors1 * cors2 * cors3)));

				double cor = cor1 * cor2 * cors0 * cors1 * cors2 * cors3;
				total_cor += cor;
				printf("%f,%f\n", log2(abs(cor)), log2(abs(total_cor)));
			}
			if (total_cor < 0)
				sign = -1;
			printf("total:%f,%f,\n,", sigmacor[45],log2(abs(total_cor)) + sigmacor[45]);
		}

		fclose(fptr);
		_mm_free(AS);
	}
	*/

}
