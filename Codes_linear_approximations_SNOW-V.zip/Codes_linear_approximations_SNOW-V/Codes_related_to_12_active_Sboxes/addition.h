#pragma once
#include<set>
#include<inttypes.h>
#include<math.h>
#include<vector>
#include<array>
#include<algorithm>
#include<iterator>
#include<math.h>
#include<omp.h>
#include<immintrin.h>
#include<string>
#include<memory>
#include<time.h>

//parameter definition section----------------------------------------------
////parameters for (X+sigma(Y+Z))
#define BLOCKS 4
#define LOGBLOCK 2
#define RANK 2
#define SIZE (1<<RANK)
#define MODULO SIZE-1
#define KD 2
#define RCSIZE ((1<<BLOCKS))

////for small AES
#define SMALL_BLOCKS 1
#define SMALL_RCSIZE ((1<<SMALL_BLOCKS))
#define SMALL_LOGBLOCK 1
////parameters for check combination impact
#define SCAL_COM 2
#define SIZE_COM (1<<SCAL_COM)
#define MODU_COM (SIZE_COM-1)
#define BLOCK_COM 3

////for computing the bias of two input addition with mode
#define ADD_CELL 8

////for sigma binary
#define CELLLEN 8
#define CELL_MODU ((1<<CELLLEN)-1)
////cach align for AVX
#define STATIC_CACHE_ALIGN_AVX2 __declspec(align(32))

////arithmatic operation for computing union pdf
#define Add(x,y,z,cr_prv,cc_prv) ((x+((y+z+cr_prv) & MODULO)+cc_prv) & MODULO)//compute byte addition
#define RowC(y,z,cr_prv) (((y+z+cr_prv)>>RANK)&0x1) //compute current row carry
#define ColC(x,y,z,cr_prv,cc_prv) (((x + ((y + z + cr_prv) & MODULO)+cc_prv) >> RANK)&0x1) //compute current column carry
//cc_current(1 bit)|| cr_current(1 bit)|| cr_history(0~3 offset bit)||bi_current(RANK bit)
#define Cat(cc_cur,cr_cur,cr_h,offset,bi_cur) ((((cc_cur<<1)^cr_cur)<<(RANK+offset))^(cr_h<<RANK)^bi_cur)
//extract the i-th RANK-bit-block from v
#define Etr(v,i) ((v >> (RANK * i)) & MODULO)//v=x||y||z or v=x||y||z||bip
#define Etrbt(v,i) ((v>>i)&0x1)
//x,y,z:exaustive loop; cr_pre,cc_pre: the carry bit from left postion(row) and above position(col)
//msk: current position 0~15(or BLOCK*BLOCK-1)
//bip: history combination of linear approximation
#define F(x,y,z,cr_pre,cc_pre,msk,bip) (bip^U_MSK[msk][Add(x, y, z, cr_pre, cc_pre)] ^ WX_MSK[msk][x] ^ WY_MSK[msk][y] ^ WZ_MSK[msk][z])//linear approx output
//--------------------------------------------------cur_col_carry---------cur_row_carry---cr_prevcolblock-shift---cur_out
//indeterminate form
#define PI(x,y,z,cr_pre,cc_pre,offset,cr_h,msk,bip) Cat(ColC(x, y, z, cr_pre,cc_pre), RowC(y, z, cr_pre), cr_h,       offset, F(x,y,z,cr_pre,cc_pre,msk,bip))//indeterminate 
//compute the new position in next matrix
//only for byte (0,0) position,i.e. msk=0,bip=0
#define NP0(v,cr_pre,cc_pre,offset,cr_h) PI(Etr(v,2),Etr(v,1),Etr(v,0),cr_pre,cc_pre,offset,cr_h,0,0)
//the other 14 position
#define NP1(v,cr_pre,cc_pre,offset,cr_h,msk) PI(Etr(v,3),Etr(v,2),Etr(v,1),cr_pre,cc_pre,offset,cr_h,msk,Etr(v,0))
//compute the old position of prev matrix
#define PP(cc_pre,cr_h,bip,offset) ((cc_pre<<(RANK+offset))^(cr_h<<RANK)^bip)
// for checking independency
#define Up(x) ((uint32_t)((x)<<SCAL_COM))
#define Cut(x) ((x)&MODU_COM)

//for sample
#define ByteToInt(x0,x1,x2,x3) ((uint32_t)(x0) ^ ((uint32_t)(x1)<<8)^ ((uint32_t)(x2)<<16)^ ((uint32_t)(x3)<<24))
#define IntToByte(x,i) ((uint8_t)(((x)>>(i*8))&0xFF))


//global variables section--------------------------------------------
//computing two input addition in bit (Nyberg)
static struct Two {
	double L[2] = { 1,0 };//L
	double C[2] = { 1,1 };//C
	double A[8][2][2] = {
		{ {1,0},{0,0.5} } ,//A0
		{ {0,0},{0.5,0} }, //A1
		{ {0,0},{0.5,0} } ,//A2
		{ {0,0},{0,-0.5} },//A3
		{ {0,0},{-0.5,0} },//A4
		{ {0,0},{0,0.5} },//A5
		{ {0,0},{0,0.5} },//A6
		{ {0,1},{0.5,0} } };//A7
}TWA;
static struct Three {
	double L[3] = { 1,0,0 };
	double C[3] = { 1,1,1 };
	double A[16][3][3] = {//connection matrices(Nyberg)
		{ {4,1,0},{4,6,4}, {0,1,4}} ,//A0
		{ {2,1,0},{-2,0,2},{0,-1,-2}}, //A1
		{ {2,1,0},{-2,0,2},{0,-1,-2}},//A2
		{ {0,1,0},{0,-2,0},{0,1,0 }},//A3
		{ {2,1,0},{-2,0,2},{0,-1,-2}},//A4
		{ {0,1,0},{0,-2,0},{0,1,0 }},//A5
		{ {0,1,0},{0,-2,0},{0,1,0 }},//A6
		{ {-2,1,0},{2,0,-2},{0,-1,2}},//A7
		{ {-2, -1, 0}, { 2,0,-2 }, { 0,1,2 }},//A8
		{ {0,-1,0},{0,2,0},{0,-1,0 } },//A9
		{ {0,-1,0},{0,2,0},{0,-1,0 } },//A10
		{ {2,-1,0},{-2,0,2},{0,1,-2}},//A11
		{ {0,-1,0},{0,2,0},{0,-1,0 } },//A12
		{ {2,-1,0},{-2,0,2},{0,1,-2}},//A13
		{ {2,-1,0},{-2,0,2},{0,1,-2}},//A14
		{ {4,-1,0},{4,-6,4}, {0,-1,4}} };//A15
}THA;
//connection matrix for computing the union pdf
//all representation by one dimension array to store carry and ouput matrix of carry
//the form is [Bi,nextcolcarry,nextrowcarry, historyrowcarry]
//byte(0,0)
static std::array<double, SIZE* KD* KD>  M_C0 = { 0 };
static std::array<double, SIZE* KD* KD>  M_C0_SMALL = { 0 };//for small verification
//byte(1,0)
static std::array<double, SIZE* KD* KD* KD>  M_C1 = { 0 };
static std::array<double, SIZE* KD* KD* KD>  M_C1_SMALL = { 0 };//for small verification
static std::array<double, SIZE* KD* KD* KD>  M_C1_TMP = { 0 };
static std::array<double, SIZE* KD* KD* KD>  M_C1_TOTAL = { 0 };
//byte(2,0)
static std::array<double, SIZE* KD* KD* KD* KD>  M_C2 = { 0 };
//byte(3,0):M[Bi][col][row0][row1][row2][row3]
static std::array<double, SIZE* KD* KD* KD* KD* KD>  M_C3 = { 0 };
static std::array<double, SIZE* KD* KD* KD* KD* KD>  M_C3_TMP = { 0 };
static std::array<double, SIZE* KD* KD* KD* KD* KD>  M_C3_TOTAL = { 0 };

//constants used for check the independency
//the multiply table and mask transform matrix for check the combination impact to independency
#if(SCAL_COM==4)
static uint8_t MUL_GF[16 * 16] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
0, 2, 4, 6, 8, 10, 12, 14, 3, 1, 7, 5, 11, 9, 15, 13,
0, 3, 6, 5, 12, 15, 10, 9, 11, 8, 13, 14, 7, 4, 1, 2,
0, 4, 8, 12, 3, 7, 11, 15, 6, 2, 14, 10, 5, 1, 13, 9,
0, 5, 10, 15, 7, 2, 13, 8, 14, 11, 4, 1, 9, 12, 3, 6,
0, 6, 12, 10, 11, 13, 7, 1, 5, 3, 9, 15, 14, 8, 2, 4,
0, 7, 14, 9, 15, 8, 1, 6, 13, 10, 3, 4, 2, 5, 12, 11,
0, 8, 3, 11, 6, 14, 5, 13, 12, 4, 15, 7, 10, 2, 9, 1,
0, 9, 1, 8, 2, 11, 3, 10, 4, 13, 5, 12, 6, 15, 7, 14,
0, 10, 7, 13, 14, 4, 9, 3, 15, 5, 8, 2, 1, 11, 6, 12,
0, 11, 5, 14, 10, 1, 15, 4, 7, 12, 2, 9, 13, 6, 8, 3,
0, 12, 11, 7, 5, 9, 14, 2, 10, 6, 1, 13, 15, 3, 4, 8,
0, 13, 9, 4, 1, 12, 8, 5, 2, 15, 11, 6, 3, 14, 10, 7,
0, 14, 15, 1, 13, 3, 2, 12, 9, 7, 6, 8, 4, 10, 11, 5,
0, 15, 13, 2, 9, 6, 4, 11, 1, 14, 12, 3, 8, 7, 5, 10 };
//present
static uint8_t SBOX[16] = { 12, 5, 6, 11, 9, 0, 10, 13, 3, 14, 15, 8, 4, 7, 1, 2 };
#if(BLOCK_COM==2)
static uint8_t LINV[2][2] = { 3,1,1,3 };//0.009404
#elif(BLOCK_COM==3)
static uint8_t LINV[3][3] = { 3,1,1, 1,3,1, 1,1,3 };//0.000952
#else
static uint8_t LINV[4][4] = { 3,15,3,10, 3,3,10,15, 3,10,15,3, 1,3,3,3 };//MDS 
#endif
#elif(SCAL_COM==2)
static uint8_t MUL_GF[4 * 4] = { 0,0,0,0, 0,1,2,3, 0,2,3,1, 0,3,1,2 };
//very small
static uint8_t SBOX[4] = { 0,2,3,1 };
#if(BLOCK_COM==2)
static uint8_t LINV[2][2] = { 3,1,1,3 };//0.005489
#elif(BLOCK_COM==3)
static uint8_t LINV[3][3] = { 3,1,1, 1,3,1, 1,1,3 };//0.000000
#endif
#endif

//if a byte x include odd number of bit 1, then Partiy[x]=1, otherwise 0
static uint8_t Parity[256] = {
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
1, 0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1,
0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0};

//store all the connection matrices column by column
//These matrices are used for algorithm 2 X + sigma(Y+Z)
__m256d A[16][4] = {
	//A[0]
	0.500000,0.250000,0.250000,0.000000,
	0.125000,0.625000,0.125000,0.125000,
	0.125000,0.125000,0.625000,0.125000,
	0.000000,0.250000,0.250000,0.500000,
	//A[1]
	0.250000,0.000000,-0.250000,0.000000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[2]
	0.250000,0.000000,-0.250000,0.000000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.125000,0.125000,-0.125000,-0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[3]
	0.000000,-0.250000,0.250000,0.000000,
	0.125000,-0.375000,0.125000,0.125000,
	0.125000,0.125000,-0.375000,0.125000,
	0.000000,0.250000,-0.250000,0.000000,
	//A[4]
	0.250000,-0.250000,0.000000,0.000000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.250000,-0.250000,
	//A[5]
	0.000000,0.000000,0.000000,0.000000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[6]
	0.000000,0.000000,0.000000,0.000000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.125000,-0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[7]
	-0.250000,0.250000,0.000000,0.000000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.125000,-0.125000,0.125000,-0.125000,
	0.000000,0.000000,-0.250000,0.250000,
	//A[8]
	-0.250000,0.250000,0.000000,0.000000,
	-0.125000,0.125000,-0.125000,0.125000,
	-0.125000,0.125000,-0.125000,0.125000,
	0.000000,0.000000,-0.250000,0.250000,
	//A[9]
	0.000000,0.000000,0.000000,0.000000,
	-0.125000,0.125000,0.125000,-0.125000,
	-0.125000,0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[10]
	0.000000,0.000000,0.000000,0.000000,
	-0.125000,0.125000,0.125000,-0.125000,
	-0.125000,0.125000,0.125000,-0.125000,
	0.000000,0.000000,0.000000,0.000000,
	//A[11]
	0.250000,-0.250000,0.000000,0.000000,
	-0.125000,0.125000,-0.125000,0.125000,
	-0.125000,0.125000,-0.125000,0.125000,
	0.000000,0.000000,0.250000,-0.250000,
	//A[12]
	0.000000,-0.250000,0.250000,0.000000,
	-0.125000,0.375000,-0.125000,-0.125000,
	-0.125000,-0.125000,0.375000,-0.125000,
	0.000000,0.250000,-0.250000,0.000000,
	//A[13]
	0.250000,0.000000,-0.250000,0.000000,
	-0.125000,-0.125000,0.125000,0.125000,
	-0.125000,-0.125000,0.125000,0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[14]
	0.250000,0.000000,-0.250000,0.000000,
	-0.125000,-0.125000,0.125000,0.125000,
	-0.125000,-0.125000,0.125000,0.125000,
	0.000000,0.250000,0.000000,-0.250000,
	//A[15]
	0.500000,0.250000,0.250000,0.000000,
	-0.125000,-0.625000,-0.125000,-0.125000,
	-0.125000,-0.125000,-0.625000,-0.125000,
	0.000000,0.250000,0.250000,0.500000,
};

//functions section--------------------------------------------------
//alpha*e in GF(2^4)
inline uint8_t Mulx_GF16(uint8_t e)
{
	return (((e >> 4) & 0x1) * 0x3) ^ (e << 1);
}
//K-L divergence overloads
//len: length of p.d. vector (p1,p2,...,p_len)
//pdf1:probability distribution 1,
//these functions are used in check independency
double KLDivergence(double* pdf1, double* pdf2, uint32_t len)
{
	double sum = 0;
	for (uint32_t i = 0; i < len; i++)
		sum += pdf1[i] * log2(pdf1[i] / pdf2[i]);
	return sum;
}
double KLDivergence(std::array<double, SIZE_COM* SIZE_COM> pdf1, std::array<double, SIZE_COM* SIZE_COM> pdf2)
{
	double sum = 0;
	for (uint32_t i = 0; i < pdf1.size(); i++)
		sum += pdf1[i] * log2(pdf1[i] / pdf2[i]);
	return sum;
}
double KLDivergence(std::array<double, SIZE> pdf1, std::array<double, SIZE> pdf2)
{
	double sum = 0;
	for (uint32_t i = 0; i < pdf1.size(); i++)
		sum += pdf1[i] * log2(pdf1[i] / pdf2[i]);
	return sum;
}
double SEI(std::array<double, SIZE> pdf)
{
	double sum = 0;
	for (uint32_t i = 0; i < pdf.size(); i++)
		sum += (SIZE*(pdf[i] - 1.0 / SIZE) * (pdf[i] - 1.0 / SIZE));
	return sum;
}
double SEI(double* pdf)
{
	double sum = 0;
	for (uint32_t i = 0; i < SIZE; i++)
		sum += (SIZE * (pdf[i] - 1.0 / SIZE) * (pdf[i] - 1.0 / SIZE));
	return sum;
}
double SEI(double* pdf, uint32_t scale)
{
	double sum = 0;
	for (uint32_t i = 0; i < SIZE; i++)
		sum += (scale * (pdf[i] - 1.0 / scale) * (pdf[i] - 1.0 / scale));
	return sum;
}

//These functions are used to compute linear correlation of modulo 2^n addition, related to Nyberg et al paper
//u_msk:output mask
//wa_msk and wb_msk: two input masks, len: length
double TwoInputCorrelation_Binary(uint32_t u_msk, uint32_t wa_msk, uint32_t wb_msk, uint8_t len)
{
	uint8_t w[32] = { 0 };
	for (uint8_t i = 0; i < len; i++)
		w[i] = (((u_msk >> i) & 0x1) << 2) + (((wa_msk >> i) & 0x1) << 1) + ((wb_msk >> i) & 0x1);
	uint8_t exp = 0;
	uint8_t sgn = 0;

	enum state { Zero, E0, E1 };
	state current = E0;
	for (int8_t i = len - 1; i >= 0; i--)
	{
		if (current == E0)
		{
			switch (w[i])
			{
			case 0:
				break;
			case 7:
				current = E1;
				break;
			default:
				current = Zero;
				break;
			}
		}
		else if (current == E1)
		{
			switch (w[i])
			{
			case 1:
				current = E0;
				exp++;
				break;
			case 2:
				current = E0;
				exp++;
				break;
			case 4://change sign
				current = E0;
				exp++;
				sgn++;
				break;
			case 7:
				current = E0;
				exp++;
				break;
			case 3://change sign
				exp++;
				sgn++;
				break;
			default://
				exp++;
				break;
			}
		}
		else
		{
			continue;
		}
	}
	if (current == Zero)
		return 0;
	else
	{
		return pow(-1, sgn & 0x1) * pow(0.5, exp);
	}
}
double ThreeInputCorrelation_Binary(uint32_t u_msk, uint32_t wa_msk, uint32_t wb_msk, uint32_t wc_msk, uint8_t len)
{
	//construct w
	uint8_t w[32] = { 0 };
	for (uint8_t i = 0; i < len; i++)
		w[i] = (((u_msk >> i) & 0x1) << 3) + (((wa_msk >> i) & 0x1) << 2) + (((wb_msk >> i) & 0x1) << 1) + ((wc_msk >> i) & 0x1);

	std::array < double, 3> u = { 1,1,1 };
	std::array < double, 3> v = { 0,0,0 };
	for (int8_t i = len - 1; i >= 0; i--)
	{
		for (uint8_t c = 0; c < 3; c++)
			v[c] = (u[0] * THA.A[w[i]][0][c] + u[1] * THA.A[w[i]][1][c] + u[2] * THA.A[w[i]][2][c])/8;
		if (w[i] >= 8 && w[i] <= 14)
		{
			v[0] *= -1;
			v[1] *= -1;
			v[2] *= -1;
		}
		u = v;
	}
	return v[0];
}
//These functions corresponds to Algorithm 2 in the paper
//z: bitsliced masks, edgelen: the size of row or column, e.g., edgelen is 4 for AES
//AVX version
double ComputeThreeAdditionDistributionWithSigma_Binary(std::array<std::array<uint8_t, CELLLEN>, 16> z, uint8_t edgelen)
{

	//std::array<double, 4> C = { 0,0,0,0 };//column vector C
	__m256d C = _mm256_setzero_pd();
	//std::array<double, 4> T = { 0,0,0,0 };//temp vector
	__m256d T = _mm256_setzero_pd();

	STATIC_CACHE_ALIGN_AVX2 double M[4 * 32] = { 1,0,0,0 };
	//__m256d M[4][8] = { 1,0,0,0 };
	//std::array<std::array<double, 32>, 4> M = { { {1,0,0,0},{0},{0},{0} } };
	//std::array<double, 32> MT = { 0 };
	//(0,0)-(0,3)
	for (uint8_t r = 0; r < edgelen; r++)
	{
		for (uint8_t cr_list = 0; cr_list < (1 << r); cr_list++)//r=1:0,1;r=2:0,1,2,3
		{
			C = _mm256_zextpd128_pd256(_mm_load_pd(M + (cr_list << 1)));
			for (uint8_t s = 0; s < CELLLEN; s++)
			{
				T = _mm256_add_pd(_mm256_mul_pd(A[z[r][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[r][s]][1], _mm256_permute4x64_pd(C, 0x55)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[r][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[r][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
				C = T;
			}
			_mm256_store_pd(M + 32 + (cr_list << 2), C);
		}
		memcpy(M, M + 32, 32 * sizeof(double));//m[0]=M[1]
	}
	//the prob of row carry (c0,c1,c2,c3) =M[0][(c0,c1,c2,c3)*2+0]+M[0][(c0,c1,c2,c3)*2+1]
	//column 1 to 3
	for (uint8_t c = 1; c < edgelen; c++)
	{
		for (uint8_t cr_hst = 0; cr_hst < (1 << edgelen); cr_hst++)//all possible histories of (cr0,cr1,cr2,cr3)
		{
			//(0,c)
			//C.fill(0);
			//M[1].fill(0);
			C = _mm256_setzero_pd();
			memset(M + 32, 0, 32 * sizeof(double));
			//hst=(crp0,crp1,...,crp_edgelen-1)
			uint8_t crp = ((cr_hst >> (edgelen - 1)) & 0x1);//crp0 row carry from previous
			//the first block of each column is difference(*,0,*,0)
			//the pre cc always =0, but crp could be 0/1
			//M[0][(crp0,crp1,...,crp_ed-1,cc)]
			double tmp = M[cr_hst << 1] + M[(cr_hst << 1) + 1];
			C = _mm256_zextpd128_pd256(_mm_load_pd1(&tmp));
			if (crp == 0)
				C = _mm256_permute4x64_pd(C, 0xFD);
			else
				C = _mm256_permute4x64_pd(C, 0xDF);

			for (uint8_t s = 0; s < CELLLEN; s++)//transition
			{
				T = _mm256_add_pd(_mm256_mul_pd(A[z[c * edgelen][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[c * edgelen][s]][1], _mm256_permute4x64_pd(C, 0x55)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
				T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
				C = T;
			}
			_mm256_store_pd(M + 32, C);
			//(1,c)~(3,c)
			for (uint8_t r = 1; r < edgelen; r++)
			{
				crp = ((cr_hst >> (edgelen - r - 1)) & 0x1);//crpi row carry from previous
				for (uint8_t cr_list = 0; cr_list < (1 << r); cr_list++)//r=1:0,1;r=2:0,1,2,3
				{
					//loading crp==1:(*,*,0,0,); crp=0:(0,0,*,*)
					C = _mm256_zextpd128_pd256(_mm_load_pd(M + 32 + (cr_list << 1)));
					if (crp == 1)
						C = _mm256_permute4x64_pd(C, 0x4E);
					for (uint8_t s = 0; s < CELLLEN; s++)//transition
					{
						T = _mm256_add_pd(_mm256_mul_pd(A[z[c * edgelen + r][s]][0], _mm256_permute4x64_pd(C, 0x00)), _mm256_mul_pd(A[z[c * edgelen + r][s]][1], _mm256_permute4x64_pd(C, 0x55)));
						T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen + r][s]][2], _mm256_permute4x64_pd(C, 0xaa)));
						T = _mm256_add_pd(T, _mm256_mul_pd(A[z[c * edgelen + r][s]][3], _mm256_permute4x64_pd(C, 0xFF)));
						C = T;
					}
					_mm256_store_pd(M + 64 + (cr_list << 2), C);
				}
				memcpy(M + 32, M + 64, 32 * sizeof(double));
				memset(M + 64, 0, 32 * sizeof(double));
			}
			//for each possible cr_hst, compute one M[1], then summation
			for (uint8_t i = 0; i < 32; i++)
				M[i + 96] += M[i + 32];
		}
		//printf("F2: %f,%f,%f,%f\n", F2[0], F2[1], F2[2], F2[3]);
		//M[0] = MT;
		//MT.fill(0);
		memcpy(M, M + 96, 32 * sizeof(double));
		memset(M + 96, 0, 32 * sizeof(double));
	}
	//accumulate M[0]
	double cor = 0;
	for (uint8_t cr_list = 0; cr_list < (1 << edgelen); cr_list++)
		cor += (M[(cr_list << 1)] + M[(cr_list << 1) + 1]);
	return cor;
}

//These function are related to independency
void ComputeAdditionBlock(std::vector<uint8_t> u, std::vector<uint8_t> wa, std::vector<uint8_t> wb, double pdf[SIZE_COM])
{
	//construct the mask,i.e. the multiply table over GF(16)
	//0 block
	std::array<double, SIZE_COM * 2> M1 = { 0 }, M2 = { 0 };
	uint8_t b0 = 0;
	for (uint32_t x = 0; x < SIZE_COM; x++)
		for (uint32_t y = 0; y < SIZE_COM; y++)
		{
			b0 = (MUL_GF[(u[0] << SCAL_COM) ^ ((x + y) & MODU_COM)] ^ MUL_GF[(wa[0] << SCAL_COM) ^ x] ^ MUL_GF[(wb[0] << SCAL_COM) ^ y]);
			M1[((x + y) & SIZE_COM) ^ b0] += 1.0;
		}
	for (uint32_t i = 0; i < M1.size(); i++)
		M1[i] /= (double)(SIZE_COM * SIZE_COM);

	for (uint32_t i = 1; i < u.size(); i++)
	{
		for (uint32_t x = 0; x < SIZE_COM; x++)
			for (uint32_t y = 0; y < SIZE_COM; y++)
				for (uint32_t bip = 0; bip < SIZE_COM; bip++)
				{
					uint8_t bi = bip ^ MUL_GF[(u[i] << SCAL_COM) ^ ((x + y) & MODU_COM)] ^ MUL_GF[(wa[i] << SCAL_COM) ^ (x & MODU_COM)] ^ MUL_GF[(wb[i] << SCAL_COM) ^ (y & MODU_COM)];
					M2[((x + y) & SIZE_COM) ^ bi] += M1[bip];
					bi = bip ^ MUL_GF[(u[i] << SCAL_COM) ^ ((x + y + 1) & MODU_COM)] ^ MUL_GF[(wa[i] << SCAL_COM) ^ (x & MODU_COM)] ^ MUL_GF[(wb[i] << SCAL_COM) ^ (y & MODU_COM)];
					M2[((x + y + 1) & SIZE_COM) ^ bi] += M1[SIZE_COM ^ bip];
				}
		M1 = M2;
		M2.fill(0.0);
		for (uint32_t i = 0; i < M1.size(); i++)
			M1[i] /= (double)(SIZE_COM * SIZE_COM);
	}
	for (uint32_t i = 0; i < SIZE_COM; i++)
		pdf[i] = M1[i] + M1[SIZE_COM ^ i];
}
void ComputeAdditionBlock_naive(std::vector<uint8_t> u, std::vector<uint8_t> wa, std::vector<uint8_t> wb, double pdf[SIZE_COM])
{
	uint8_t xv[BLOCK_COM] = { 0 }, zv[BLOCK_COM] = { 0 };
	for (uint32_t x = 0; x < (1 << (SCAL_COM * BLOCK_COM)); x++)
		for (uint32_t z = 0; z < (1 << (SCAL_COM * BLOCK_COM)); z++)
		{
			for (uint8_t i = 0; i < BLOCK_COM; i++)
			{
				xv[i] = ((x >> (i * SCAL_COM)) & MODU_COM);
				zv[i] = ((z >> (i * SCAL_COM)) & MODU_COM);
			}
			uint8_t bi = 0, c = 0, c_nxt = 0;
			for (uint8_t i = 0; i < BLOCK_COM; i++)
			{
				bi ^= (MUL_GF[(LINV[0][i] << SCAL_COM) ^ ((xv[i] + zv[i] + c) & MODU_COM)] ^ MUL_GF[(LINV[0][i] << SCAL_COM) ^ xv[i]] ^ MUL_GF[(LINV[0][i] << SCAL_COM) ^ zv[i]]);
				c_nxt = ((xv[i] + zv[i] + c) >> SCAL_COM);
				c = c_nxt;
			}
			pdf[bi] += (double)(1 << (SCAL_COM * BLOCK_COM));
		}
	for (uint32_t i = 0; i < SIZE_COM; i++)
		pdf[i] /= (double)((1 << (SCAL_COM * BLOCK_COM)));
}
//A binary version could be found in strategy 2
void Independency(double pdf1[SIZE_COM], double pdf2[SIZE_COM], double pdf_u[SIZE_COM * SIZE_COM])
{
	//L
	//GF(4)
	//rank 2:L=[[1,2],[2,1]], L^-1 [2,1,1,2]
	//rank 3:L:[2,1,1, 1,2,1, 1,1,2] L^-1:[]
	//GF(16)
	//rank 2:
	//rank 3:
	//rank 4:L:[1,1,1,2, 1,2,d,1, 2,d,1,1, d,1,2,1] L^-1: [3,15,3,10, 3,3,10,15, 3,10,15,3, 1,3,3,3]
	//(1) U*(S^-1(y)+T1)^Wa*y^Wb*T1
	//(2) A=L*Wa
	//(3) A*((x0,x1)+(z0,z1))^A*(x0,x1)^A*(z0,z1)
	//pdf1 1*(S^-1(y)+T1)^ 1*y ^ 1*T1 input and output mask to be 1
	for (uint32_t y = 0; y < SIZE_COM; y++)
		for (uint32_t t = 0; t < SIZE_COM; t++)
			pdf1[((SBOX[y] + t) & MODU_COM) ^ y ^ t] += 1;
	//normalize
	for (uint32_t i = 0; i < SIZE_COM; i++)
		pdf1[i] /= (double)(SIZE_COM * SIZE_COM);
	//pdf2(block by block)
	std::vector<uint8_t> u;//first row of L^-1
	for (uint32_t i = 0; i < BLOCK_COM; i++)
		u.push_back(LINV[0][i]);
	ComputeAdditionBlock(u, u, u, pdf2);
	printf("start union");
	//pdfu(naive)
	std::array<uint8_t, BLOCK_COM> xv = { 0 }, zv = { 0 };
#pragma omp parallel for
	for (int32_t x = 0; x < (1 << (SCAL_COM * BLOCK_COM)); x++)
	{
		for (uint8_t k = 0; k < BLOCK_COM; k++)
			xv[k] = Cut(x >> (k * SCAL_COM));

		uint8_t x0 = 0;
		for (uint8_t i = 0; i < BLOCK_COM; i++)
			x0 ^= MUL_GF[Up(LINV[0][i]) ^ xv[i]];

		for (uint32_t z = 0; z < (1 << (SCAL_COM * BLOCK_COM)); z++)
		{
			for (uint8_t k = 0; k < BLOCK_COM; k++)
				zv[k] = ((z >> (k * SCAL_COM)) & MODU_COM);
			//two
			uint8_t bi = 0, c = 0, c_nxt = 0;
			for (uint8_t i = 0; i < BLOCK_COM; i++)
			{
				bi ^= (MUL_GF[Up(LINV[0][i]) ^ Cut(xv[i] + zv[i] + c)] ^ MUL_GF[Up(LINV[0][i]) ^ xv[i]] ^ MUL_GF[Up(LINV[0][i]) ^ zv[i]]);
				c_nxt = ((xv[i] + zv[i] + c) >> SCAL_COM);
				c = c_nxt;
			}
			for (uint32_t t = 0; t < SIZE_COM; t++)
				pdf_u[Up(Cut(SBOX[x0] + t) ^ x0 ^ t) ^ bi] += 1 / (double)(1 << (SCAL_COM * BLOCK_COM));
		}
	}
	printf("end union");
	double sum = 0;
	for (uint32_t i = 0; i < SIZE_COM * SIZE_COM; i++)
		pdf_u[i] /= (double)((1 << (SCAL_COM * BLOCK_COM)) * SIZE_COM);
}

//This function is used to generate connection matrices for algorithm 2
void GenerateMatrixForSigmaAddition(double A[16][4][4])
{
	//column carry + row carry= three addtion carry
	std::array<double, 2*2*2> cor = { 0 };
	for (uint8_t z = 0; z < 16; z++)//z=u*8+wa*4+wb*2+wc
	{
		//for each possible carry pair (row ,col),run over all 8 possible values of the input
		for (uint8_t cr = 0; cr < 2; cr++)//input column carry
			for (uint8_t cc = 0; cc < 2; cc++)//input row carry
			{
				cor.fill(0);
				for (uint8_t x = 0; x < 8; x++)//data of three addition: slice of each bit
				{
					uint8_t rowsum = ((x >> 1) & 1) + (x & 1) + cr;//row value
					uint8_t dr = (rowsum >> 1);//row carry new
					uint8_t colsum = ((x >> 2) & 1) + (rowsum & 1) + cc;//col value,i.e. the summation
					uint8_t dc = (colsum >> 1);//col carry new
					uint8_t lp = (((z >> 3) & colsum & 1) ^ (((z & x) >> 2) & 1) ^ (((z & x) >> 1) & 1) ^ ((z & x) & 1));//linear approximation
					cor[(dr * 2 + dc) * 2 + lp] += 1;//count the occurence of 0,1 of lp
				}
				for (uint8_t i = 0; i < 2; i++)//i:dr next row carry
					for (uint8_t j = 0; j < 2; j++)//j: next col carry
						A[z][i * 2 + j][cr * 2 + cc] = cor[(i * 2 + j)*2] - cor[(i * 2 + j)*2 + 1];
			}
	}
}
//input four 16 byte masks: U,WX,WY,WZ, tranform them into bitslice mask
//i.e., 16*8 U_i||WX_i||Wy_i||WZ_i
inline void SliceFourMask(uint8_t* u, uint8_t* wx, uint8_t* wy, uint8_t* wz, uint8_t edgelen, std::array<std::array<uint8_t, CELLLEN>, 16> &z)
{
	//construct w
	for (uint8_t k = 0; k < edgelen * edgelen; k++)
		for (uint8_t i = 0; i < CELLLEN; i++)//byte size
			z[k][i] = (((u[k] >> i) & 0x1) << 3) + (((wx[k] >> i) & 0x1) << 2) + (((wy[k] >> i) & 0x1) << 1) + ((wz[k] >> i) & 0x1);
}
//32 bitslice mask U_i||X_i||Y_i to 3 integers U, X，Y
inline void ThreeMaskSliceToInt(std::vector<uint8_t> z, std::array<uint32_t,3> &uxy)
{
	std::array<uint32_t, 32> tmpu = { 0 };
	std::array<uint32_t, 32> tmpx = { 0 };
	std::array<uint32_t, 32> tmpy = { 0 };
	for (int i = 0; i < 32; i++)
	{
		tmpu[i] = ((z[31 - i] >> 2) & 1);
		tmpx[i] = ((z[31 - i] >> 1) & 1);
		tmpy[i] = ((z[31 - i]) & 1);
	}
	uxy.fill(0);
	for (int i = 0; i < 32; i++)
	{
		uxy[0] ^= (tmpu[i] << i);
		uxy[1] ^= (tmpx[i] << i);
		uxy[2] ^= (tmpy[i] << i);
	}
}

//random samples for algorithm 2
//U*(X+sigma(Y+Z))^WX*X+WY*Y+WZ*Z
//WY,WZ by Algorithm 2 <---transposition---> WY,WZ input here...
//Here: WY[0]*Y[0],WY[1]*Y[1],....
//Alg2: WY[0]*Y[0],WY[4]*Y[1],....
double SampleAlg2(uint8_t U[16], uint8_t WX[16], uint8_t WY[16], uint8_t WZ[16])
{
	double cor = 0;
	//samples by AES
	//Using AES NI
	STATIC_CACHE_ALIGN_AVX2 uint8_t aes_key[16 * 11] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 uint8_t X[16] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 uint8_t Y[16] = { 0 };
	STATIC_CACHE_ALIGN_AVX2 uint8_t Z[16] = { 0 };

	//aes key
	srand((uint32_t)time(NULL));
	for (int i = 0; i < 16 * 11; i++)
		aes_key[i] = rand() & 0xFF;
	//sample size
	uint64_t cap = (1 << 24);
	//main loop
	uint32_t tmpcol[4] = { 0 };
	uint8_t tmpbyte[16] = { 0 };


	int64_t bernuli[2] = { 0,0 };
	for (uint64_t ctr = 0; ctr < cap * 3; ctr += 3)
	{
		__m128i txtx = _mm_set_epi64x(0, ctr);
		__m128i txty = _mm_set_epi64x(0, ctr + 1);
		__m128i txtz = _mm_set_epi64x(0, ctr + 2);

		__m128i key;
		for (uint8_t i = 0; i < 10; i++)
		{
			key = _mm_loadu_si128((const __m128i*)(aes_key + (i << 4)));
			txtx = _mm_aesenc_si128(txtx, key);
			txty = _mm_aesenc_si128(txty, key);
			txtz = _mm_aesenc_si128(txtz, key);
		}
		_mm_storeu_si128((__m128i*)X, txtx);
		_mm_storeu_si128((__m128i*)Y, txty);
		_mm_storeu_si128((__m128i*)Z, txtz);

		//input parity
		////x,y,z
		uint8_t p = 0;
		for (uint8_t i = 0; i < 16; i++)
		{
			//（i*i）
			p ^= (Parity[X[i] & WX[i]] ^ Parity[Y[i] & WY[i]] ^ Parity[Z[i] & WZ[i]]);
		}
		//output parity
		//Y+Z=tmpcol
		for (uint8_t i = 0; i < 4; i++)
		{
			//(y0,y1,y2,y3)+(z0,z1,z2,z3)
			tmpcol[i] = ByteToInt(Y[i << 2], Y[(i << 2) + 1], Y[(i << 2) + 2], Y[(i << 2) + 3]) + ByteToInt(Z[i << 2], Z[(i << 2) + 1], Z[(i << 2) + 2], Z[(i << 2) + 3]);
		}
		//tmpcol->tmpbyte
		for (uint8_t i = 0; i < 4; i++)
		{
			tmpbyte[i] = IntToByte(tmpcol[i], 0);
			tmpbyte[i + 4] = IntToByte(tmpcol[i], 1);
			tmpbyte[i + 8] = IntToByte(tmpcol[i], 2);
			tmpbyte[i + 12] = IntToByte(tmpcol[i], 3);
		}
		//X+tmpbyte->tmpcol
		for (uint8_t i = 0; i < 4; i++)
		{
			tmpcol[i] = ByteToInt(X[i << 2], X[(i << 2) + 1], X[(i << 2) + 2], X[(i << 2) + 3]) + ByteToInt(tmpbyte[i << 2], tmpbyte[(i << 2) + 1], tmpbyte[(i << 2) + 2], tmpbyte[(i << 2) + 3]);
		}
		//tmpcol-tmpbyte
		for (uint8_t i = 0; i < 4; i++)
		{
			tmpbyte[i << 2] = IntToByte(tmpcol[i], 0);
			tmpbyte[(i << 2) + 1] = IntToByte(tmpcol[i], 1);
			tmpbyte[(i << 2) + 2] = IntToByte(tmpcol[i], 2);
			tmpbyte[(i << 2) + 3] = IntToByte(tmpcol[i], 3);
		}
		for (uint8_t i = 0; i < 16; i++)
		{
			p ^= (Parity[U[i] & tmpbyte[i]]);
		}
		bernuli[p]++;
	}
	cor = log2(abs((double)(bernuli[0] - bernuli[1]) / cap));
	return cor;
}