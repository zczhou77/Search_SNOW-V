#pragma once
#include<inttypes.h>
#include<exception>
#include<iostream>
//element type 1~8 bit, i.e. the base field of matrix elements can be GF(2)~GF(2^8)
template<typename T> class iMatrix {
protected:
    uint32_t row;
    uint32_t col;
    T* e;
public:
    iMatrix();
    iMatrix(const iMatrix& A);
    iMatrix(uint32_t r, uint32_t c, T e);
    iMatrix(uint32_t r, uint32_t c, T* el);
    virtual ~iMatrix();
    iMatrix<T>& Transpose();

    static iMatrix<T> Identity(uint32_t r);
    static iMatrix<T> Zero(uint32_t r);

    iMatrix<T>& Inverse();
    iMatrix<T>& GElimination();
    uint32_t Rank();
    inline void RowSwap(uint32_t r1, uint32_t r2);
    inline void RowAdd(uint32_t r1, uint32_t r2);

    inline iMatrix<T>& operator=(const iMatrix<T>&);
    iMatrix<T> operator*(const iMatrix<T>& A)const;
    iMatrix<T> operator+(const iMatrix<T>& A)const;
    iMatrix<T> operator^(uint32_t d)const;
    iMatrix<T>& operator+=(const iMatrix<T>& A)const;
    inline T* operator[](uint32_t r);

    bool Is_Zero();
    bool Is_Identity();
    T ColMatrixToInt();//T must be unsigned int
    static iMatrix<T> IntToColMatrix(uint32_t cols, T seq);
    void print(const char txt[]);
};
template<typename T> iMatrix<T>::iMatrix() :row(0), col(0), e(nullptr)
{
    NULL;
}
template<typename T> iMatrix<T>::iMatrix(const iMatrix& A)
{
    this->col = A.col;
    this->row = A.row;
    this->e = new T[col * row]();
    for (uint32_t i = 0; i < this->col * this->row; i++)
        this->e[i] = A.e[i];
}
template<typename T> iMatrix<T>::iMatrix(uint32_t r, uint32_t c, T e) {
    if (r * c != 0) {
        this->row = r;
        this->col = c;
        this->e = new T[r * c]();
        for (uint32_t i = 0; i < r * c; i++)
            this->e[i] = e;
    }
}
template<typename T> iMatrix<T>::iMatrix(uint32_t r, uint32_t c, T* el) {
    if (r * c != 0) {
        this->row = r;
        this->col = c;
        this->e = new T[r * c]();
        for (uint32_t i = 0; i < r * c; i++)
            this->e[i] = el[i];
    }
}
template<typename T> iMatrix<T>::~iMatrix() {
    this->row = 0;
    this->col = 0;
    if (this->e != NULL)
        delete[] this->e;
}
template<typename T> iMatrix<T>& iMatrix<T>::Transpose() {
    iMatrix A(this->col, this->row, (T)0);
    for (uint32_t i = 0; i < A.row; i++)
        for (uint32_t j = 0; j < A.col; j++)
            A.e[i * A.col + j] = this->e[j * this->col + i];

    return A;
}
template<typename T> iMatrix<T> iMatrix<T>::Identity(uint32_t r) {
    iMatrix A(r, r, (T)0);
    for (uint32_t i = 0; i < r; i++)
        A.e[i * r + i] = (T)1;
    return A;
}
template<typename T> iMatrix<T> iMatrix<T>::Zero(uint32_t r) {
    iMatrix A(r, r, (T)0);
    return A;
}
template<typename T> inline iMatrix<T>& iMatrix<T>::operator=(const iMatrix<T>& A) {
    if (this == &A) {
        return *this;
    }
    if (this->row * this->col == A.row * A.col) {
        for (uint32_t i = 0; i < A.row * A.col; i++)
            this->e[i] = A.e[i];
        this->row = A.row;
        this->col = A.col;
    }
    else
    {
        if (this->e != nullptr)
            delete[] this->e;
        this->e = new T[A.row * A.col]();
        for (uint32_t i = 0; i < A.row * A.col; i++)
            this->e[i] = A.e[i];
        this->row = A.row;
        this->col = A.col;
    }
    return *this;
}
template<typename T> iMatrix<T> iMatrix<T>::operator*(const iMatrix<T>& A)const {
    iMatrix B(this->row, A.col, (T)0);
    try {
        if (this->col == A.row) {
            for (uint32_t i = 0; i < B.row; i++)
                for (uint32_t j = 0; j < B.col; j++)
                {
                    for (uint32_t k = 0; k < this->col; k++)
                        B.e[i * A.col + j] += (this->e[i * this->col + k] * A.e[k * A.col + j]);
                }
        }
        else
        {
            throw std::runtime_error("This two matrix can't be multiplied!");
        }
    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
    return B;
}
template<typename T> iMatrix<T>& iMatrix<T>::operator+=(const iMatrix<T>& A)const {
    try {
        if (this->col == A.col && this->row == A.row)
            for (uint32_t i = 0; i < row; i++)
                for (uint32_t j = 0; j < col; j++)
                    e[i * col + j] += A.e[i * col + j];
        else
        {
            throw std::runtime_error("This two matrix can't be added");
        }
    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
    return (*this);
}
template<typename T> iMatrix<T> iMatrix<T>::operator+(const iMatrix<T>& A)const {
    try {
        if (this->col == A.col && this->row == A.row) {
            iMatrix B(row, col, (T)0);
            for (uint32_t i = 0; i < row; i++)
                for (uint32_t j = 0; j < col; j++)
                    B.e[i * col + j] = (this->e[i * col + j] + A.e[i * col + j]);
            return B;
        }
        else
        {
            throw std::runtime_error("This two matrix can't be added!");
        }
    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
}
template<typename T> iMatrix<T> iMatrix<T>::operator^(uint32_t d)const {
    try
    {
        if (this->row == this->col)
        {
            //iMatrix<T> B = iMatrix<T>::Identity(this->row);
            if (d > 0)
            {
                iMatrix<T> B(*this);
                //B = (*this);
                for (uint32_t i = 1; i < d; i++)
                    B = B * (*this);
                return B;
            }
        }
        else
        {
            throw std::runtime_error("The matrix must be square");
        }
    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
    iMatrix B;
    return B;

}
template<typename T> inline T* iMatrix<T>::operator[](uint32_t r) {
    try
    {
        if (r > this->row)
            throw std::runtime_error("Row index over range");
        else
        {
            return e + (r * this->col);
        }
    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
    return NULL;
}
template<typename T> inline void iMatrix<T>::RowSwap(uint32_t r1, uint32_t r2) {
    T tmp;
    for (uint32_t i = 0; i < col; i++)
    {
        tmp = e[r1 * col + i];
        e[r1 * col + i] = e[r2 * col + i];
        e[r2 * col + i] = tmp;
    }
}
template<typename T> inline void iMatrix<T>::RowAdd(uint32_t r1, uint32_t r2) {
    for (uint32_t i = 0; i < col; i++)
        e[r2 * col + i] += e[r1 * col + i];
}
template<typename T> iMatrix<T>& iMatrix<T>::Inverse() {
    try {
        iMatrix<T> A = this->Identity(this->row);
        iMatrix<T> B(*this);
        if (this->col != this->row || this->col == 0 || this->row == 0)
            throw std::runtime_error("The matrix must be nozero square");
        else
        {
            for (uint32_t r = 0; r < B.col; r++)
            {
                if (B.e[r * B.col + r] == (T)0)
                {
                    for (uint32_t i = r; i < B.row; i++)
                    {
                        if (B.e[i * B.col + r] != (T)0)
                        {
                            A.RowSwap(r, i);
                            B.RowSwap(r, i);
                            break;
                        }
                        else if (i == B.row - 1)
                            throw("Matrix is not inversable");
                    }
                }
                for (uint32_t i = r + 1; i < B.row; i++)
                {
                    if (B.e[i * B.col + r] != (T)0)
                    {
                        B.RowAdd(r, i);
                        A.RowAdd(r, i);
                    }
                }
            }
            for (int r = B.row - 1; r > 0; r--)
            {
                for (int i = r - 1; i >= 0; i--)
                {
                    if (B.e[i * B.col + r] != (T)0)
                    {
                        B.RowAdd(r, i);
                        A.RowAdd(r, i);
                    }
                }
            }
            return A;
        }
    }
    catch (std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    iMatrix B;
    return B;
}
template<typename T> iMatrix<T>& iMatrix<T>::GElimination() {
    iMatrix<T> B(*this);
    try
    {
        if (this->col == 0 || this->row == 0)
            throw std::runtime_error("The matrix must be nozero square");
        else
        {
            for (uint32_t r = 0; r < B.row; r++)//row 0..R-1
            {
                if (B.e[r * B.col + r] == (T)0)
                {
                    for (uint32_t i = r; i < B.row; i++)
                    {
                        if (B.e[i * B.col + r] != (T)0)
                        {
                            B.RowSwap(r, i);
                            break;
                        }
                    }
                }
                for (uint32_t i = r + 1; i < B.row; i++)
                {
                    if (B.e[i * B.col + r] != 0)
                    {
                        B.RowAdd(r, i);
                    }
                }
            }
        }

    }
    catch (std::runtime_error er)
    {
        std::cerr << er.what() << '\n';
    }
    return B;
}
template<typename T> uint32_t iMatrix<T>::Rank() {
    uint32_t rank = 0;
    try
    {
        iMatrix B;
        if (this->row >= this->col)
        {
            rank = this->col;
            B = (*this);
        }
        else
        {
            rank = this->row;
            B = (this->Transpose());
        }

        if (this->col == 0 || this->row == 0)
            throw std::runtime_error("The matrix must be nozero square");
        else
        {
            for (uint32_t r = 0; r < B.col; r++)//row 0..R-1
            {
                if (B.e[r * B.col + r] == (T)0)
                {
                    for (uint32_t i = r; i < B.row; i++)
                    {
                        if (B.e[i * B.col + r] != (T)0)
                        {
                            B.RowSwap(r, i);
                            break;
                        }
                        else if (i == B.row - 1)
                        {
                            rank--;
                            r++;
                        }
                    }
                }
                for (uint32_t i = r + 1; i < B.row; i++)
                {
                    if (B.e[i * B.col + r] != (T)0)
                    {
                        B.RowAdd(r, i);
                    }
                }
            }
        }
    }
    catch (std::runtime_error e)
    {
        std::cerr << e.what() << '\n';
    }
    return rank;
}
template<typename T> void iMatrix<T>::print(const char txt[])
{
    printf("%s\n", txt);
    for (uint32_t i = 0; i < row; i++)
    {
        for (uint32_t j = 0; j < col; j++)
        {
            std::cout << (int)e[i * col + j] << " ";
        }
        std::cout << std::endl;
    }
}
template<typename T> bool iMatrix<T>::Is_Zero()
{
    for (uint32_t i = 0; i < row; i++)
        for (uint32_t j = 0; j < col; j++)
            if ((*this)[i][j] != 0)
                return false;
    return true;
}
template<typename T> bool iMatrix<T>::Is_Identity()
{
    if (row != col)
        return false;
    else
    {
        for (uint32_t i = 0; i < row; i++)
            if (*this[i][i] != 1)
                return false;
    }
    return true;
}
template<typename T> iMatrix<T> iMatrix<T>::IntToColMatrix(uint32_t cols, T seq)
{
    T* s = new T[cols]();
    for (uint32_t i = 0; i < cols; i++)
    {
        s[i] = (seq >> (cols - i - 1) & 0x1);
    }

    iMatrix A(cols, 1, s);
    delete[] s;
    return A;
}
template<typename T> T iMatrix<T>::ColMatrixToInt()
{
    T t = 0;
    for (uint8_t i = 0; i < row; i++)
    {
        t ^= ((T)e[i] << (row - 1 - i));
    }
        //t ^= ((T)(*this)[i][0] << i);
    return t;
}

