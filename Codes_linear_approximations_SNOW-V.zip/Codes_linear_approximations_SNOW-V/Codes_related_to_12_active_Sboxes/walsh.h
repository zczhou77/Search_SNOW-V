#pragma once
#include<stdlib.h>
#include<Windows.h>
#include<inttypes.h>
#include<vector>
#include<array>
#include<math.h>
#include<algorithm>
inline void OptimalFWHT(char dir, double *p, double *spec,uint32_t size)
{
	//prettyprint(spec, 8, "input");
	memcpy(spec, p, size * sizeof(double));
	int h = 1;
	double x = 0, y = 0;
	while (h < size)
	{
		for (int i = 0; i < size; i += (h << 1))
			for (int j = i; j < (i + h); j++)
			{
				x = spec[j];
				y = spec[j + h];
				spec[j] = x + y;
				spec[j + h] = x - y;
			}
		h = (h << 1);
	}
	if (dir == -1)
	{
		for (int i = 0; i < size; i++)
			spec[i] /= size;
	}
};
inline void OptimalFWHT(char dir, double *spec,uint32_t size)
{
	//prettyprint(spec, 8, "input");
	int h = 1;
	double x = 0, y = 0;
	while (h < size)
	{
		for (int i = 0; i < size; i += (h << 1))
			for (int j = i; j < (i + h); j++)
			{
				x = spec[j];
				y = spec[j + h];
				spec[j] = x + y;
				spec[j + h] = x - y;
			}
		h = (h << 1);
	}
	if (dir == -1)
	{
		for (int i = 0; i < size; i++)
			spec[i] /= size;
	}
};
/*
This computes an in-place complex-to-complex FFT
x and y are the real and imaginary arrays of 2^m points.
dir =  1 gives forward transform
dir = -1 gives reverse transform
ouput: x and y
*/
void FFT(char dir, uint8_t dim, double* p_real, double* p_img, double* x, double* y)
{
	uint32_t n, i, i1, j, k, i2, l, l1, l2;
	double c1, c2, tx, ty, t1, t2, u1, u2, z;

	/*copy the value*/
	for (i = 0; i < (uint32_t)(1 << dim); i++)
	{
		x[i] = p_real[i];
		y[i] = p_img[i];
	}
	/* Calculate the number of points */
	n = 1;
	for (i = 0; i < dim; i++)
		n *= 2;

	/* Do the bit reversal */
	i2 = n >> 1;
	j = 0;
	for (i = 0; i < n - 1; i++) {
		if (i < j) {
			tx = x[i];
			ty = y[i];
			x[i] = x[j];
			y[i] = y[j];
			x[j] = tx;
			y[j] = ty;
		}
		k = i2;
		while (k <= j) {
			j -= k;
			k >>= 1;
		}
		j += k;
	}

	/* Compute the FFT */
	c1 = -1.0;
	c2 = 0.0;
	l2 = 1;
	for (l = 0; l < dim; l++) {
		l1 = l2;
		l2 <<= 1;
		u1 = 1.0;
		u2 = 0.0;
		for (j = 0; j < l1; j++) {
			for (i = j; i < n; i += l2) {
				i1 = i + l1;
				t1 = u1 * x[i1] - u2 * y[i1];
				t2 = u1 * y[i1] + u2 * x[i1];
				x[i1] = x[i] - t1;
				y[i1] = y[i] - t2;
				x[i] += t1;
				y[i] += t2;
			}
			z = u1 * c1 - u2 * c2;
			u2 = u1 * c2 + u2 * c1;
			u1 = z;
		}
		c2 = sqrt((1.0 - c1) / 2.0);
		if (dir == 1)
			c2 = -c2;
		c1 = sqrt((1.0 + c1) / 2.0);
	}

	/* Scaling for forward transform */
	if (dir == 1) {
		for (i = 0; i < n; i++) {
			x[i] /= n;
			y[i] /= n;
		}
	}
}
inline int16_t Weight(int16_t x)
{
	int16_t s = 0;
	for (int i = 0; i < 8; i++)
	{
		s += ((x >> i) & 0x01);
	}
	return s;
};
bool cmptuple(std::array<int16_t, 3> a, std::array<int16_t, 3> b)
{
	 return (Weight(a[0]) + Weight(a[1])) < (Weight(b[0]) + Weight(b[1]));
}
void OrderMask(int16_t lat[256][256], std::vector<std::vector<std::array<int16_t, 3> > > &orderlat)
{
	for (int16_t i = 1; i < 256; i++)
		for (int16_t j = 1; j < 256; j++)
		{
			if(lat[i][j] > 0)
				orderlat[(lat[i][j] >> 1) - 1].push_back(std::array<int16_t, 3>{i, j, lat[i][j]});
			else if (lat[i][j] < 0)
				orderlat[((-lat[i][j]) >> 1) - 1].push_back(std::array<int16_t, 3>{i, j, lat[i][j]});
		}
	for(auto e : orderlat)
	{
		std::sort(e.begin(), e.end(), cmptuple);
	}
}
void TwoConvolution(double* pdfx, double* pdfy, double* conv,uint32_t size)
{
	double tmpx[256] = { 0 };
	double tmpy[256] = { 0 };

	memcpy(tmpx, pdfx, size * sizeof(double));
	memcpy(tmpy, pdfx, size * sizeof(double));

	OptimalFWHT(1, tmpx, size);
	OptimalFWHT(1, tmpy, size);


	//multiply in complex field
	for (int i = 0; i < size; i++)
		conv[i]= tmpx[i]*tmpy[i];

	OptimalFWHT(-1, conv,size);
}