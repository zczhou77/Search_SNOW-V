#include<stdio.h>
#include<array>
#include<vector>
#include<math.h>
#include<inttypes.h>
#include<set>
#include<algorithm>
#include"lat.h"
#include"addition.h"
#include"mask.h"
double pdf1[SIZE_COM] = { 0 }, pdf2[SIZE_COM] = { 0 },pdf_u[SIZE_COM*SIZE_COM] = { 0 },pdfa[SIZE_COM*SIZE_COM] = { 0 };
#define HUGE_CELL_SIZE 256
#define GROUPS_LOWCOR 102

int main()
{
	//[[1, 1, 0, 0]0, [1, 0, 1, 0]1, [0, 1, 1, 0]2, [1, 0, 0, 1]3,[0, 1, 0, 1]4,[0, 0, 1, 1]5]
	//[[0, 0, 0, 0]0, [1, 1, 1, 0]1, [1, 1, 0, 1]2, [1, 0, 1, 1]3, [0, 1, 1, 1]4]
	//SigmaAdditionBinaryApproximation_222(6);
	//SigmaAdditionBinaryApproximation_322(7);

	//ComputeNoisesCorrelation();

	////verify data
	//uint8_t gamma[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0x80,0x5a,0xec,0x81};//u
	//uint8_t nxord[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0x00,0x5a,0xec,0x81};//wx
	//
	//uint8_t betaxorb[16] = { 0,0,0,0x00,0,0,0,0x5a,0,0,0,0xec,0,0,0,0x81};//wy
	//uint8_t hxord[16] = { 0,0,0,0x80,0,0,0,0x5a,0,0,0,0xec,0,0,0,0x81};//wz
	//0x411af7c0
	uint8_t gamma[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0xc0,0xf7,0x1a,0x41};//u
	uint8_t nxord[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0x80,0xf7,0x1a,0x41};//wx
	
	uint8_t betaxorb[16] = { 0,0,0,0x80,0,0,0,0xf7,0,0,0,0x1a,0,0,0,0x41};//wy
	uint8_t hxord[16] = { 0,0,0,0xc0,0,0,0,0xf7,0,0,0,0x1a,0,0,0,0x41};//wz
	//2,3 columns are active
	//uint8_t gamma[16] = { 0,0,0,0,0,0,0,0,0x80,0x5a,0xec,0x81,0x80,0x5a,0xec,0x81 };//u
	//uint8_t nxord[16] = { 0,0,0,0,0,0,0,0,0x80,0x5a,0xec,0x81,0x00,0x5a,0xec,0x81 };//wx

	//uint8_t betaxorb[16] = { 0,0,0x00,0x00,0,0,0x5a,0x5a,0,0,0xec,0xec,0,0,0x81,0x81 };//wy
	//uint8_t hxord[16] = { 0,0,0x80,0x80,0,0,0x5a,0x5a,0,0,0xec,0xec,0,0,0x81,0x81 };//wz

	//uint8_t betaxorb[16] = { 0,0,0,0, 0,0,0,0, 0,0,0,0,0x00,0x5a,0xec,0x81};//wy
	//uint8_t hxord[16] = { 0,0,0,0, 0,0,0,0, 0,0,0,0, 0x80,0x5a,0xec,0x81};//wz

	////verify data
	//uint8_t gamma[16] = { 0x81,0xec,0x5a,0x80,0,0,0,0,0,0,0,0,0,0,0,0 };//u
	//uint8_t nxord[16] = { 0x81,0xec,0x5a,0x00,0,0,0,0,0,0,0,0,0,0,0,0 };//wx
	////
	//uint8_t betaxorb[16] = { 0x81,0,0,0,0xec,0,0,0,0x5a,0,0,0,0x00,0,0,0};//wy
	//uint8_t hxord[16] = { 0x81,0,0,0,0xec,0,0,0,0x5a,0,0,0,0x80,0,0,0 };//wz

	//uint8_t betaxorb[16] = { 0x81,0xec,0x5a,0x00, 0,0,0,0, 0,0,0,0, 0,0,0,0, };//wy
	//uint8_t hxord[16] = { 0x81,0xec,0x5a,0x80,0,0,0,0, 0,0,0,0, 0,0,0,0, };//wz


	std::array<std::array<uint8_t, CELLLEN>, 16> z = { 0 };
	SliceFourMask(gamma, nxord, betaxorb, hxord, 4, z);
	//Algorithm 2
	double cor = ComputeThreeAdditionDistributionWithSigma_Binary(z, 4);

	printf("%f\n", log2(abs(cor)));

	//verify data2
	uint8_t U[16] = { 0xc1,0x01,0x80,0x00, 0x01,0x00,0x80,0x00, 0x80,0x80,0x80,0x00, 0x00,0x00,0x00,0x00 };//u
	uint8_t V[16] = { 0xc1,0x01,0x80,0x00, 0x01,0x00,0x80,0x00, 0x80,0x80,0x80,0x00, 0x00,0x00,0x00,0x00 };//u
	uint8_t W[16] = { 0xc1,0x01,0x80,0x00, 0x01,0x00,0x80,0x00, 0x80,0x80,0x80,0x00, 0x00,0x00,0x00,0x00 };//u
	uint8_t T[16] = { 0xc1,0x01,0x80,0x00, 0x01,0x00,0x80,0x00, 0x80,0x80,0x80,0x00, 0x00,0x00,0x00,0x00 };//u

	std::array<std::array<uint8_t, CELLLEN>, 16> zz = { 0 };
	SliceFourMask(U, V, W, T, 4, zz);
	cor = ComputeThreeAdditionDistributionWithSigma_Binary(zz, 4);

	printf("%f\n", log2(abs(cor)));

	//for (int i = 0; i < 256; i++)
	//	if (NDBE[i] == 0x81ec5a80)
	//		printf("0x%2.2x", i);
	double* AS = (double*)_mm_malloc((1 << 26) * sizeof(double), 16);
	FILE* fptr = fopen("SBox addition connection matrix.dat", "rb");
	//uint8_t umask1[4] = { 0x1,0,0,0 };
	//uint8_t xmask1[4] = { 0x1,0,0,0 };
	////uint8_t ymask1[4] = { 0xb7,0,0,0 } ;
	//uint8_t ymask1[4] = { 0x6c,0,0,0 };

	uint8_t umask1[4] = { 0x01,0x80,0x01,0 };
	uint8_t xmask1[4] = { 0x01,0x80,0x01,0 };
	//uint8_t ymask1[4] = { 0xb7,0,0,0 } ;
	uint8_t ymask1[4] = { 0x01,0xc0,0x41,0};

	//uint8_t umask2[4] = { 0x80,0,0,0 };
	//uint8_t xmask2[4] = { 0x80,0,0,0 };
	//uint8_t ymask2[4] = { 0xb7,0,0,0 };

	uint8_t umask2[4] = { 0x40,0,0,0 };
	uint8_t xmask2[4] = { 0x40,0,0,0 };
	uint8_t ymask2[4] = { 0x6c,0,0,0 };

	//[2] paper
	uint8_t umask3[4] = { 0xc,0,0,0 };
	uint8_t xmask3[4] = { 0xc,0,0,0 };
	uint8_t ymask3[4] = { 0xb7,0,0,0 } ;

	uint8_t umask4[4] = { 0x80,0,0,0 };
	uint8_t xmask4[4] = { 0x80,0,0,0 };
	uint8_t ymask4[4] = { 0xb7,0,0,0 } ;

	double cor1 = 0, cor2 = 0, cor3 = 0, cor4 = 0, maxcor = -100, sboxcor = 0, comcor = 0;
	uint16_t goodx = 0;
	uint16_t goody = 0;

	//if (fptr != NULL && AS != NULL)
	//{
	//	fread(AS, sizeof(double), 1 << 26, fptr);
	//	for (int16_t i = 0; i < 256; i++)
	//	{
	//		//cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
	//		xmask2[0] = (i&0xFF);
	//		cor2 = EvaluateSboxAdditionCorrelation(AS, umask2, xmask2, ymask2);
	//		if (log2(abs(cor2)) > maxcor)
	//		{
	//			maxcor = log2(abs(cor2));
	//			goodx = i;
	//		}
	//	}
	//	printf("%f,%2.2x\n", maxcor,goodx);

	//	//cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
	//	//cor2 = EvaluateSboxAdditionCorrelation(AS, umask2, xmask2, ymask2);
	//	//cor3 = EvaluateSboxAdditionCorrelation(AS, umask3, xmask3, ymask3);
	//	//cor4 = EvaluateSboxAdditionCorrelation(AS, umask4, xmask4, ymask4);

	//	fclose(fptr);
	//}
	if (fptr != NULL && AS != NULL)
	{
		fread(AS, sizeof(double), 1 << 26, fptr);
		cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
		cor2 = EvaluateSboxAdditionCorrelation(AS, umask2, xmask2, ymask2);

		//cor3 = EvaluateSboxAdditionCorrelation(AS, umask3, xmask3, ymask3);
		//cor4 = EvaluateSboxAdditionCorrelation(AS, umask4, xmask4, ymask4);
		printf("cor1:%f,%f\n", log2(abs(cor1)), log2(abs(cor2)));
        //printf("%f,%f\n", log2(abs(cor3)), log2(abs(cor4)));
		for (int16_t i = 1; i < 256; i++)
			for (int16_t j = 1; j < 256; j++)
			{
				xmask1[0] = (i & 0xFF);
				umask1[0] = (j & 0xFF);
				cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
				//if (log2(abs(cor1)) + AES_SBOX_LAT[j][0xb7] > maxcor)
				if (log2(abs(cor1)) + AES_SBOX_LAT[j][0x6c] > maxcor)
				{
					//maxcor = log2(abs(cor1)) + AES_SBOX_LAT[j][0xb7];
					maxcor = log2(abs(cor1)) + AES_SBOX_LAT[j][0x6c];
					comcor = log2(abs(cor1));
					//sboxcor = AES_SBOX_LAT[j][0xb7];
					sboxcor = AES_SBOX_LAT[j][0x6c];

					goodx = i;//x
					goody = j;//u
				}
			}
		printf("2-%f,%f,%f,%2.2x,%2.2x\n", maxcor,comcor,sboxcor, goodx, goody);

		//cor1 = EvaluateSboxAdditionCorrelation(AS, umask1, xmask1, ymask1);
		//cor2 = EvaluateSboxAdditionCorrelation(AS, umask2, xmask2, ymask2);
		//cor3 = EvaluateSboxAdditionCorrelation(AS, umask3, xmask3, ymask3);
		//cor4 = EvaluateSboxAdditionCorrelation(AS, umask4, xmask4, ymask4);

		fclose(fptr);
	}

	//printf("%f,%2.2x\n", log2(abs(cor2)), goodx);
	//printf("%f,%f", log2(abs(cor1)), log2(abs(cor2)));
	//printf("%f,%f", log2(abs(cor3)), log2(abs(cor4)));

	//printf("%f,", AES_SBOX_LAT[1][0xb7]);
	//printf("%f\n", AES_SBOX_LAT[0xc][0xb7]);
	printf("%f,", AES_SBOX_LAT[1][0x6d]);
	printf("%f\n", AES_SBOX_LAT[0xc][0x6d]);

	_mm_free(AS);

	return 0;
}